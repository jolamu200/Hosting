// Cache name changes on every deploy (Vite injects the build time via
// __BUILD_TIME__, replaced at build time — see vite.config.ts). This is
// what makes updates actually reach people: the activate handler below
// deletes every cache that doesn't match today's name.
const CACHE_NAME = "bmb-tech-__BUILD_TIME__";

const STATIC_ASSETS = [
  "/favicon.png",
  "/favicon-192.png",
  "/favicon-badge.png",
  "/favicon.ico",
  "/manifest.json",
];

// Install — cache static assets, then take over immediately instead of
// waiting for old tabs to close.
self.addEventListener("install", (event) => {
  event.waitUntil(
    caches.open(CACHE_NAME).then((cache) => cache.addAll(STATIC_ASSETS))
  );
  self.skipWaiting();
});

// Activate — remove every cache from a previous deploy, and start
// controlling already-open tabs right away.
self.addEventListener("activate", (event) => {
  event.waitUntil(
    caches.keys().then((keys) =>
      Promise.all(
        keys.filter((key) => key !== CACHE_NAME).map((key) => caches.delete(key))
      )
    ).then(() => self.clients.claim())
  );
});

// Fetch — always go to the network first so a new deploy is picked up
// immediately. HTML/navigation requests are never served from cache (that
// was the source of people being stuck on an old build) — they either come
// from the network or, if fully offline, fall back to the cached shell.
// Other static assets still get a cache fallback for offline support.
self.addEventListener("fetch", (event) => {
  if (event.request.method !== "GET") return;
  if (!event.request.url.startsWith(self.location.origin)) return;

  const isNavigation = event.request.mode === "navigate";

  if (isNavigation) {
    event.respondWith(
      fetch(event.request).catch(() => caches.match("/index.html"))
    );
    return;
  }

  event.respondWith(
    fetch(event.request)
      .then((response) => {
        const responseClone = response.clone();
        caches.open(CACHE_NAME).then((cache) => {
          cache.put(event.request, responseClone);
        });
        return response;
      })
      .catch(() => caches.match(event.request))
  );
});

// Let the page tell a waiting service worker to activate immediately
// (used by main.tsx's update-detection flow below).
self.addEventListener("message", (event) => {
  if (event.data === "SKIP_WAITING") {
    self.skipWaiting();
  }
});

// Push — show the notification the server sent. Payload shape:
// { title, body, url }
self.addEventListener("push", (event) => {
  if (!event.data) return;

  let payload;
  try {
    payload = event.data.json();
  } catch {
    payload = { title: "Bmb Tech", body: event.data.text() };
  }

  const { title, body, url } = payload;

  event.waitUntil(
    self.registration.showNotification(title || "Bmb Tech", {
      body: body || "",
      // The large icon shown in the expanded notification — our full
      // colour logo.
      icon: "/favicon-192.png",
      // The small status-bar badge. This MUST be a lightweight, mostly
      // transparent silhouette — Android masks it into a monochrome shape
      // regardless, and feeding it a heavy full-colour PNG (like icon
      // above) makes Chrome give up and fall back to its own generic bell
      // icon instead of ours.
      badge: "/favicon-badge.png",
      data: { url: url || "/" },
    })
  );
});

// Notification click — focus an existing tab on this origin if one is
// open, navigating it to the target URL; otherwise open a new tab.
self.addEventListener("notificationclick", (event) => {
  event.notification.close();
  const targetUrl = event.notification.data?.url || "/";

  event.waitUntil(
    self.clients.matchAll({ type: "window", includeUncontrolled: true }).then((clientList) => {
      for (const client of clientList) {
        if (client.url.startsWith(self.location.origin) && "focus" in client) {
          client.navigate(targetUrl);
          return client.focus();
        }
      }
      return self.clients.openWindow(targetUrl);
    })
  );
});
