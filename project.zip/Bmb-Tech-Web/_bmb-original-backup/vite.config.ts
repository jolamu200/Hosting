import { defineConfig } from "vite";
import react from "@vitejs/plugin-react-swc";
import path from "path";
import fs from "fs";
import { componentTagger } from "lovable-tagger";

// Stamps public/sw.js's cache name with a unique value on every build, so
// each deploy invalidates the previous one's service-worker cache instead
// of everyone staying stuck on whatever was cached first.
const stampServiceWorker = () => ({
  name: "stamp-service-worker",
  writeBundle() {
    const swPath = path.resolve(__dirname, "dist/sw.js");
    if (!fs.existsSync(swPath)) return;
    const buildTime = String(Date.now());
    const contents = fs.readFileSync(swPath, "utf-8").replace(/__BUILD_TIME__/g, buildTime);
    fs.writeFileSync(swPath, contents);
  },
});

// https://vitejs.dev/config/
export default defineConfig(({ mode }) => ({
  server: {
    host: "::",
    port: 8080,
  },
  plugins: [react(), stampServiceWorker(), mode === "development" && componentTagger()].filter(Boolean),
  resolve: {
    alias: {
      "@": path.resolve(__dirname, "./src"),
    },
  },
}));
