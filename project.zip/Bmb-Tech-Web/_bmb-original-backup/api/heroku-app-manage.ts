// POST /api/heroku-app-manage
// Body: { action: 'rename', currentName, newName }
// Body: { action: 'delete', appName }
//
// Merged rename + delete into one file (each was tiny on its own) to stay
// under Vercel's Hobby-plan 12 Serverless Function limit.

const HEROKU_API = 'https://api.heroku.com';

export default async function handler(req: any, res: any) {
  if (req.method !== 'POST') {
    return res.status(405).json({ error: 'Method not allowed' });
  }

  const apiKey = process.env.HEROKU_API_KEY;
  if (!apiKey) {
    return res.status(500).json({ error: 'Server is missing HEROKU_API_KEY' });
  }

  const { action } = req.body || {};

  if (action === 'rename') {
    const { currentName, newName } = req.body || {};

    if (!currentName || !newName) {
      return res.status(400).json({ error: 'currentName and newName are required' });
    }
    if (!/^[a-z][a-z0-9-]{2,28}[a-z0-9]$/.test(newName)) {
      return res.status(400).json({
        error: 'Invalid new name. Use lowercase letters, numbers, hyphens (3-30 chars).',
      });
    }

    try {
      const renameRes = await fetch(`${HEROKU_API}/apps/${currentName}`, {
        method: 'PATCH',
        headers: {
          Authorization: `Bearer ${apiKey}`,
          Accept: 'application/vnd.heroku+json; version=3',
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ name: newName }),
      });
      const data = await renameRes.json();

      if (!renameRes.ok) {
        return res.status(renameRes.status).json({ error: data.message || 'Failed to rename app' });
      }

      return res.status(200).json({ name: data.name, appUrl: data.web_url });
    } catch (err: any) {
      return res.status(500).json({ error: err.message || 'Unexpected error renaming app' });
    }
  }

  if (action === 'delete') {
    const { appName } = req.body || {};
    if (!appName) {
      return res.status(400).json({ error: 'appName is required' });
    }

    try {
      const deleteRes = await fetch(`${HEROKU_API}/apps/${appName}`, {
        method: 'DELETE',
        headers: {
          Authorization: `Bearer ${apiKey}`,
          Accept: 'application/vnd.heroku+json; version=3',
        },
      });

      if (!deleteRes.ok) {
        const deleteData = await deleteRes.json().catch(() => ({}));

        // The app is already gone from Heroku (deleted directly there, a
        // stale/renamed record, etc). The end goal — "this app no longer
        // exists on Heroku" — is already true, so let this through as a
        // success instead of leaving the person stuck with a database row
        // they can never clear from the UI.
        if (deleteRes.status === 404) {
          return res.status(200).json({ success: true, alreadyGone: true });
        }

        return res.status(deleteRes.status).json({ error: deleteData.message || 'Failed to delete app' });
      }

      return res.status(200).json({ success: true });
    } catch (err: any) {
      return res.status(500).json({ error: err.message || 'Unexpected error deleting app' });
    }
  }

  return res.status(400).json({ error: "action must be 'rename' or 'delete'" });
}
