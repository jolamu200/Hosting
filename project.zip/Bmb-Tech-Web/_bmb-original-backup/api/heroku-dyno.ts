// GET  /api/heroku-dyno?appName=xxx        -> { state: 'up' | 'down' | 'unknown' }
// GET  /api/heroku-dyno?scope=all-status    -> { apps: [{ id, heroku_app_name, state }] }
//      Admin-only bulk status check: looks up every non-deleted deployed_apps
//      row's actual Heroku dyno state, so the admin Bot Deployments view can
//      show which bots are really running vs offline (rather than trusting
//      whatever status happens to be cached in the database).
// POST /api/heroku-dyno  { appName, action: 'pause' | 'resume' | 'restart' }
// POST /api/heroku-dyno  { action: 'bulk-delete', appNames: string[] }
//      Deletes each Heroku app AND its deployed_apps row entirely (hard
//      delete, not a status flag) — used by the admin Bot Deployments view
//      to clean up bots that are offline/no longer running.
//
// Pausing scales the web dyno to 0 (app stops, no charges/activity but the
// app itself and its config are untouched). Resuming scales it back to 1.
// Restarting kills and restarts all running dynos without changing the
// scale — the same as Heroku dashboard's "Restart all dynos".

import { createClient } from '@supabase/supabase-js';

const HEROKU_API = 'https://api.heroku.com';

function herokuHeaders(apiKey: string) {
  return {
    Authorization: `Bearer ${apiKey}`,
    Accept: 'application/vnd.heroku+json; version=3',
    'Content-Type': 'application/json',
  };
}

async function getDynoState(appName: string, apiKey: string): Promise<'up' | 'down' | 'unknown'> {
  try {
    const dynoRes = await fetch(`${HEROKU_API}/apps/${appName}/formation`, { headers: herokuHeaders(apiKey) });
    if (!dynoRes.ok) return 'unknown';
    const dynoData = await dynoRes.json();
    const webFormation = Array.isArray(dynoData) ? dynoData.find((f: any) => f.type === 'web') : null;
    return webFormation ? (webFormation.quantity > 0 ? 'up' : 'down') : 'unknown';
  } catch {
    return 'unknown';
  }
}

export default async function handler(req: any, res: any) {
  const apiKey = process.env.HEROKU_API_KEY;
  if (!apiKey) {
    return res.status(500).json({ error: 'Server is missing HEROKU_API_KEY' });
  }

  if (req.method === 'GET') {
    const { appName, scope } = req.query;

    if (scope === 'all-status') {
      // Returns the deployed_apps list only — fast, no per-app Heroku calls,
      // since doing that for ~100 apps in one request blows past Vercel's
      // serverless timeout. The frontend fetches live dyno state separately,
      // in small batches, via scope=status-batch below.
      const supabaseUrl = process.env.VITE_SUPABASE_URL;
      const serviceRoleKey = process.env.SUPABASE_SERVICE_ROLE_KEY;
      if (!supabaseUrl || !serviceRoleKey) {
        return res.status(500).json({ error: 'Server is missing Supabase service credentials' });
      }
      const supabase = createClient(supabaseUrl, serviceRoleKey);

      const { data: apps, error } = await supabase
        .from('deployed_apps')
        .select('id, heroku_app_name, bot_name, user_id, status, created_at')
        .neq('status', 'deleted')
        .order('created_at', { ascending: false });

      if (error) return res.status(500).json({ error: error.message });

      return res.status(200).json({ apps: (apps || []).map((app) => ({ ...app, state: 'unknown' as const })) });
    }

    if (scope === 'status-batch') {
      // ?names=app1,app2,app3 — checks a small batch of apps' live dyno
      // state in parallel. Called repeatedly by the frontend with ~10 names
      // at a time so the whole ~100-bot list finishes without any single
      // request timing out.
      const namesParam = String(req.query.names || '');
      const names = namesParam.split(',').map((n) => n.trim()).filter(Boolean).slice(0, 15);

      if (names.length === 0) {
        return res.status(400).json({ error: 'names is required' });
      }

      const states = await Promise.all(
        names.map(async (name) => ({ heroku_app_name: name, state: await getDynoState(name, apiKey) }))
      );

      return res.status(200).json({ states });
    }

    if (!appName) {
      return res.status(400).json({ error: 'appName is required' });
    }

    try {
      const state = await getDynoState(appName, apiKey);
      if (state === 'unknown') {
        // Distinguish "couldn't tell" from "app genuinely has no web formation"
        // by re-checking directly so the single-app error path still works.
        const dynoRes = await fetch(`${HEROKU_API}/apps/${appName}/formation`, { headers: herokuHeaders(apiKey) });
        if (!dynoRes.ok) {
          const dynoData = await dynoRes.json().catch(() => ({}));
          return res.status(dynoRes.status).json({ error: dynoData.message || 'Failed to fetch dyno state' });
        }
      }
      return res.status(200).json({ state });
    } catch (err: any) {
      return res.status(500).json({ error: err.message || 'Unexpected error fetching dyno state' });
    }
  }

  if (req.method === 'POST') {
    const { appName, action, appNames } = req.body || {};

    if (action === 'bulk-delete') {
      if (!Array.isArray(appNames) || appNames.length === 0) {
        return res.status(400).json({ error: 'appNames array is required' });
      }

      const supabaseUrl = process.env.VITE_SUPABASE_URL;
      const serviceRoleKey = process.env.SUPABASE_SERVICE_ROLE_KEY;
      if (!supabaseUrl || !serviceRoleKey) {
        return res.status(500).json({ error: 'Server is missing Supabase service credentials' });
      }
      const supabase = createClient(supabaseUrl, serviceRoleKey);

      const results: any[] = [];

      for (const name of appNames) {
        try {
          const delRes = await fetch(`${HEROKU_API}/apps/${name}`, {
            method: 'DELETE',
            headers: herokuHeaders(apiKey),
          });
          // 404 is fine here — app may already be gone from Heroku but still
          // have a leftover row in our database.
          if (!delRes.ok && delRes.status !== 404) {
            const delData = await delRes.json().catch(() => ({}));
            results.push({ appName: name, ok: false, error: delData.message });
            continue;
          }

          // Hard delete — not a status flag — per the admin cleanup flow.
          const { error: dbError } = await supabase.from('deployed_apps').delete().eq('heroku_app_name', name);
          if (dbError) {
            results.push({ appName: name, ok: false, error: dbError.message });
            continue;
          }

          results.push({ appName: name, ok: true });
        } catch (err: any) {
          results.push({ appName: name, ok: false, error: err.message });
        }
      }

      return res.status(200).json({ results });
    }

    if (!appName || !['pause', 'resume', 'restart'].includes(action)) {
      return res.status(400).json({ error: 'appName and a valid action (pause|resume|restart) are required' });
    }

    if (action === 'restart') {
      try {
        const restartRes = await fetch(`${HEROKU_API}/apps/${appName}/dynos`, {
          method: 'DELETE',
          headers: herokuHeaders(apiKey),
        });

        if (!restartRes.ok) {
          const restartData = await restartRes.json().catch(() => ({}));
          return res.status(restartRes.status).json({ error: restartData.message || 'Failed to restart app' });
        }

        return res.status(200).json({ state: 'up' });
      } catch (err: any) {
        return res.status(500).json({ error: err.message || 'Unexpected error trying to restart app' });
      }
    }

    const quantity = action === 'pause' ? 0 : 1;

    try {
      const scaleRes = await fetch(`${HEROKU_API}/apps/${appName}/formation/web`, {
        method: 'PATCH',
        headers: herokuHeaders(apiKey),
        body: JSON.stringify({ quantity }),
      });
      const scaleData = await scaleRes.json();

      if (!scaleRes.ok) {
        return res.status(scaleRes.status).json({ error: scaleData.message || `Failed to ${action} app` });
      }

      return res.status(200).json({ state: quantity > 0 ? 'up' : 'down' });
    } catch (err: any) {
      return res.status(500).json({ error: err.message || `Unexpected error trying to ${action} app` });
    }
  }

  return res.status(405).json({ error: 'Method not allowed' });
}
