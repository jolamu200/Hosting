// POST /api/heroku-create-app
// Body: { appName: string, repoFullName: string, branch: string, envVars: Record<string,string> }
//
// Creates a Heroku app under a Team, sets config vars, and triggers a build
// from the GitHub repo's tarball. Requires two Vercel env vars:
//   HEROKU_API_KEY  — the personal API key of a member of the Team
//   HEROKU_TEAM     — the Team's name (was hardcoded to 'hostings' before —
//                      that's why switching to a new Heroku team via just
//                      the API key alone didn't work: this constant was
//                      still silently pointing every new app at the old,
//                      maxed-out team no matter which key was used).

const HEROKU_API = 'https://api.heroku.com';

function herokuHeaders(apiKey: string) {
  return {
    Authorization: `Bearer ${apiKey}`,
    Accept: 'application/vnd.heroku+json; version=3',
    'Content-Type': 'application/json',
  };
}

// Heroku's API always returns JSON on its own error responses, but a
// timeout, gateway error, or Vercel's own platform-level failure can hand
// back HTML/plain-text instead — parsing that with res.json() throws a raw,
// confusing error. This reads the body safely either way.
async function safeHerokuJson(res: Response): Promise<any> {
  const contentType = res.headers.get('content-type') || '';
  if (!contentType.includes('json')) {
    const text = await res.text().catch(() => '');
    return { message: text ? text.slice(0, 200) : `Heroku returned ${res.status} with no readable body` };
  }
  try {
    return await res.json();
  } catch {
    return { message: `Heroku returned an unreadable response (status ${res.status})` };
  }
}

export default async function handler(req: any, res: any) {
  if (req.method !== 'POST') {
    return res.status(405).json({ error: 'Method not allowed' });
  }

  const apiKey = process.env.HEROKU_API_KEY;
  if (!apiKey) {
    return res.status(500).json({ error: 'Server is missing HEROKU_API_KEY' });
  }
  const HEROKU_TEAM = process.env.HEROKU_TEAM;
  if (!HEROKU_TEAM) {
    return res.status(500).json({ error: 'Server is missing HEROKU_TEAM' });
  }

  const { appName, repoFullName, branch, envVars } = req.body || {};

  if (!appName || !/^[a-z][a-z0-9-]{2,28}[a-z0-9]$/.test(appName)) {
    return res.status(400).json({
      error: 'Invalid app name. Use lowercase letters, numbers, hyphens (3-30 chars).',
    });
  }
  if (!repoFullName) {
    return res.status(400).json({ error: 'repoFullName is required' });
  }

  try {
    // 1. Create the Heroku app under the Team (billing/verification lives on the Team)
    const createRes = await fetch(`${HEROKU_API}/teams/apps`, {
      method: 'POST',
      headers: herokuHeaders(apiKey),
      body: JSON.stringify({ name: appName, team: HEROKU_TEAM }),
    });
    const createData = await safeHerokuJson(createRes);

    if (!createRes.ok) {
      return res.status(createRes.status).json({
        error: createData.message || 'Failed to create Heroku app',
      });
    }

    // 2. Set config vars (env), if any were provided
    if (envVars && Object.keys(envVars).length > 0) {
      const configRes = await fetch(`${HEROKU_API}/apps/${appName}/config-vars`, {
        method: 'PATCH',
        headers: herokuHeaders(apiKey),
        body: JSON.stringify(envVars),
      });
      if (!configRes.ok) {
        const configData = await safeHerokuJson(configRes);
        return res.status(configRes.status).json({
          error: configData.message || 'Failed to set config vars',
          appName, // app was created even though config failed; let the client know
        });
      }
    }

    // 3. Trigger a build from the GitHub repo tarball
    const tarballUrl = `https://github.com/${repoFullName}/tarball/${branch || 'main'}`;
    const buildRes = await fetch(`${HEROKU_API}/apps/${appName}/builds`, {
      method: 'POST',
      headers: herokuHeaders(apiKey),
      body: JSON.stringify({
        source_blob: { url: tarballUrl },
      }),
    });
    const buildData = await safeHerokuJson(buildRes);

    if (!buildRes.ok) {
      return res.status(buildRes.status).json({
        error: buildData.message || 'Failed to start build',
        appName,
      });
    }

    return res.status(200).json({
      appName,
      appId: createData.id,
      appUrl: createData.web_url,
      buildId: buildData.id,
      buildStatus: buildData.status,
    });
  } catch (err: any) {
    return res.status(500).json({ error: err.message || 'Unexpected error creating app' });
  }
}
