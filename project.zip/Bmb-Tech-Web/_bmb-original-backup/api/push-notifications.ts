// POST /api/push-notifications?step=subscribe
//   body: { userId, subscription: { endpoint, keys: { p256dh, auth } } }
//   -> { ok: true }
//
// POST /api/push-notifications?step=unsubscribe
//   body: { endpoint }
//   -> { ok: true }
//
// POST /api/push-notifications?step=send
//   body: { title, body, url?, excludeUserId? }
//   -> { sent, failed }
//   Sends a push to every subscribed user (optionally skipping one, e.g.
//   the sender of a community message so they don't get pinged for their
//   own message). Called from the browser (Community Chat, Admin
//   Notifications) — there's no separate server-to-server secret gating
//   this, since a secret shipped to the browser wouldn't add real
//   protection anyway. It just fires a push to everyone subscribed.
//
// POST /api/push-notifications?step=topup-initiate
//   body: { userId, country, coins, amount, currency, phone, firstName, lastName, email }
//   -> { ok: true, reference }
//   Starts a Speedpesa mobile-money (USSD push) charge for a coin top-up.
//   Confirmed against the Speedpesa Sandbox docs (Auth + Mobile Money tabs):
//     1) POST {SPEEDPESA_BASE_URL}/api/v1/auth/token
//        body: { api_key, api_secret } -> { access_token, expires_in }
//     2) POST {SPEEDPESA_BASE_URL}/api/v1/collections/ussd-push
//        headers: Authorization: Bearer <access_token>, X-Merchant-Id
//        body: { msisdn, amount, currency, channel: "MPESA", reference, callback_url }
//        -> { success, transaction_id, reference, status, message }
//   "status": "SUCCESS" here only means the USSD prompt was sent to the
//   phone — it is NOT payment confirmation. That only comes later, async,
//   via the topup-webhook step below.
//
// POST /api/push-notifications?step=topup-webhook
//   Called by Speedpesa when a payment succeeds/fails/is cancelled.
//   Set this exact URL as the Speedpesa "Callback URL":
//     https://<your-domain>/api/push-notifications?step=topup-webhook
//   ⚠️ The sandbox docs screenshots covered Auth + USSD-push request/response
//   shapes, but not the async webhook payload itself. The field names read
//   below (status/reference/transaction_id) are a best guess at the common
//   pattern — confirm against Speedpesa's webhook payload docs and adjust
//   the `body.xxx` reads in handleTopupWebhook() if they differ.
//
// NOTE: the topup-initiate / topup-webhook steps live in this file (instead
// of their own api/topup-initiate.ts + api/topup-webhook.ts files) because
// Vercel's Hobby plan caps a project at 12 Serverless Functions, and this
// project's /api folder was already at that cap. Folding them in here adds
// zero new functions to the deployment.

import { createClient } from '@supabase/supabase-js';
import webpush from 'web-push';

function getSupabase() {
  const supabaseUrl = process.env.VITE_SUPABASE_URL;
  const serviceRoleKey = process.env.SUPABASE_SERVICE_ROLE_KEY;
  if (!supabaseUrl || !serviceRoleKey) return null;
  return createClient(supabaseUrl, serviceRoleKey);
}

function configureWebPush() {
  const publicKey = process.env.VAPID_PUBLIC_KEY;
  const privateKey = process.env.VAPID_PRIVATE_KEY;
  if (!publicKey || !privateKey) return false;
  webpush.setVapidDetails('mailto:bmbxmd@gmail.com', publicKey, privateKey);
  return true;
}

async function handleSubscribe(req: any, res: any) {
  const supabase = getSupabase();
  if (!supabase) return res.status(500).json({ error: 'Server is missing Supabase service credentials' });

  const { userId, subscription } = req.body || {};
  if (!userId || !subscription?.endpoint || !subscription?.keys) {
    return res.status(400).json({ error: 'userId and a valid subscription are required' });
  }

  const { error } = await supabase.from('push_subscriptions').upsert(
    {
      user_id: userId,
      endpoint: subscription.endpoint,
      p256dh: subscription.keys.p256dh,
      auth: subscription.keys.auth,
    },
    { onConflict: 'endpoint' }
  );

  if (error) return res.status(500).json({ error: error.message });
  return res.status(200).json({ ok: true });
}

async function handleUnsubscribe(req: any, res: any) {
  const supabase = getSupabase();
  if (!supabase) return res.status(500).json({ error: 'Server is missing Supabase service credentials' });

  const { endpoint } = req.body || {};
  if (!endpoint) return res.status(400).json({ error: 'endpoint is required' });

  await supabase.from('push_subscriptions').delete().eq('endpoint', endpoint);
  return res.status(200).json({ ok: true });
}

async function handleSend(req: any, res: any) {
  const supabase = getSupabase();
  if (!supabase) return res.status(500).json({ error: 'Server is missing Supabase service credentials' });
  if (!configureWebPush()) return res.status(500).json({ error: 'Server is missing VAPID keys' });

  const { title, body, url, excludeUserId } = req.body || {};
  if (!title || !body) return res.status(400).json({ error: 'title and body are required' });

  let query = supabase.from('push_subscriptions').select('id, user_id, endpoint, p256dh, auth');
  if (excludeUserId) query = query.neq('user_id', excludeUserId);

  const { data: subs, error } = await query;
  if (error) return res.status(500).json({ error: error.message });
  if (!subs || subs.length === 0) return res.status(200).json({ sent: 0, failed: 0 });

  const payload = JSON.stringify({ title, body, url: url || '/' });

  let sent = 0;
  let failed = 0;
  const deadIds: string[] = [];

  await Promise.all(
    subs.map(async (sub) => {
      try {
        await webpush.sendNotification(
          { endpoint: sub.endpoint, keys: { p256dh: sub.p256dh, auth: sub.auth } },
          payload
        );
        sent++;
      } catch (err: any) {
        failed++;
        console.error('Push send failed for', sub.endpoint.slice(0, 60), '—', err?.statusCode, err?.body || err?.message);
        // 404/410 means the subscription is gone (browser data cleared,
        // uninstalled, etc) — clean those up so we stop trying them.
        if (err?.statusCode === 404 || err?.statusCode === 410) deadIds.push(sub.id);
      }
    })
  );

  if (deadIds.length > 0) {
    await supabase.from('push_subscriptions').delete().in('id', deadIds);
  }

  return res.status(200).json({ sent, failed });
}

// ------------------------------------------------------------------
// Top Up Coins — Speedpesa mobile-money (USSD push), Tanzania only
// ------------------------------------------------------------------

async function getSpeedpesaToken(baseUrl: string, apiKey: string, apiSecret: string) {
  const res = await fetch(`${baseUrl}/api/v1/auth/token`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ api_key: apiKey, api_secret: apiSecret }),
  });
  const data = await res.json().catch(() => ({}));
  if (!res.ok || !data?.access_token) {
    throw new Error(data?.message || 'Could not authenticate with Speedpesa');
  }
  return data.access_token as string;
}

async function handleTopupInitiate(req: any, res: any) {
  const supabase = getSupabase();
  if (!supabase) return res.status(500).json({ error: 'Server is missing Supabase service credentials' });

  const { userId, country, coins, amount, currency, phone, firstName, lastName, email } = req.body || {};

  if (!userId || !country || !coins || !amount || !phone) {
    return res.status(400).json({ error: 'userId, country, coins, amount and phone are required' });
  }

  // Only Tanzania (via Speedpesa) is wired up right now.
  if (country !== 'tanzania') {
    return res.status(400).json({ error: `Payments for "${country}" are not available yet.` });
  }

  const baseUrl = process.env.SPEEDPESA_BASE_URL;
  const merchantId = process.env.SPEEDPESA_MERCHANT_ID;
  const apiKey = process.env.SPEEDPESA_API_KEY;
  const apiSecret = process.env.SPEEDPESA_API_SECRET;

  if (!baseUrl || !merchantId || !apiKey || !apiSecret) {
    return res.status(500).json({ error: 'Server is missing Speedpesa credentials' });
  }

  // 1) Record the attempt as "pending" first, so it shows up in Admin →
  //    Payments even if the provider call below fails.
  const { data: topup, error: insertError } = await supabase
    .from('coin_topups')
    .insert({
      user_id: userId,
      country,
      method: 'mpesa',
      coins,
      amount,
      currency: currency || 'TZS',
      phone,
      first_name: firstName || null,
      last_name: lastName || null,
      email: email || null,
      status: 'pending',
      provider: 'speedpesa',
    })
    .select('id')
    .single();

  if (insertError || !topup) {
    return res.status(500).json({ error: insertError?.message || 'Could not record the transaction' });
  }

  try {
    // 2) Get a fresh Bearer token (valid 60 min — simplest to just fetch
    //    one per request rather than cache it across cold serverless starts).
    const accessToken = await getSpeedpesaToken(baseUrl, apiKey, apiSecret);

    // 3) Push the USSD prompt to the customer's phone.
    const appUrl = process.env.VITE_APP_URL || `https://${req.headers.host}`;
    const providerRes = await fetch(`${baseUrl}/api/v1/collections/ussd-push`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        Authorization: `Bearer ${accessToken}`,
        'X-Merchant-Id': merchantId,
      },
      body: JSON.stringify({
        msisdn: phone,
        amount,
        currency: currency || 'TZS',
        channel: 'MPESA',
        reference: topup.id,
        callback_url: `${appUrl}/api/push-notifications?step=topup-webhook`,
      }),
    });

    const providerData = await providerRes.json().catch(() => ({}));

    if (!providerRes.ok || providerData?.success === false) {
      await supabase.from('coin_topups').update({ status: 'failed', updated_at: new Date().toISOString() }).eq('id', topup.id);
      return res.status(502).json({ error: providerData?.message || 'Speedpesa rejected the payment request' });
    }

    // Store the transaction id Speedpesa returned, so the webhook can
    // match it back to this row even if it only sends transaction_id.
    await supabase
      .from('coin_topups')
      .update({ provider_ref: providerData?.transaction_id || null, updated_at: new Date().toISOString() })
      .eq('id', topup.id);

    return res.status(200).json({ ok: true, reference: topup.id });
  } catch (err: any) {
    await supabase.from('coin_topups').update({ status: 'failed', updated_at: new Date().toISOString() }).eq('id', topup.id);
    return res.status(502).json({ error: err?.message || 'Could not reach the payment provider. Please try again.' });
  }
}

async function handleTopupWebhook(req: any, res: any) {
  // ⚠️ Header name not confirmed against real Speedpesa webhook docs —
  // adjust to match if theirs differs (e.g. a signature instead of a
  // plain shared secret).
  const webhookSecret = process.env.SPEEDPESA_WEBHOOK_SECRET;
  if (webhookSecret && req.headers['x-speedpesa-signature'] !== webhookSecret) {
    return res.status(403).json({ error: 'Forbidden' });
  }

  const supabase = getSupabase();
  if (!supabase) return res.status(500).json({ error: 'Server is missing Supabase service credentials' });

  const body = req.body || {};
  // "reference" is the coin_topups.id we sent Speedpesa when initiating —
  // it should be echoed back on the webhook so we know which row to update.
  const reference = body.reference || body.our_reference;
  const providerRef = body.transaction_id || body.checkout_id || body.id;
  const status = (body.status || '').toLowerCase(); // expect something like "success" / "failed"

  if (!reference && !providerRef) {
    return res.status(400).json({ error: 'Missing reference/transaction id' });
  }

  const { data: topup, error: findError } = await supabase
    .from('coin_topups')
    .select('id, user_id, coins, status')
    .eq(reference ? 'id' : 'provider_ref', reference || providerRef)
    .maybeSingle();

  if (findError || !topup) {
    return res.status(404).json({ error: 'Transaction not found' });
  }

  // Already processed — Speedpesa may retry webhooks, so this must be safe
  // to receive more than once without crediting coins twice.
  if (topup.status === 'completed') {
    return res.status(200).json({ ok: true, alreadyProcessed: true });
  }

  const isSuccess = status === 'success' || status === 'completed' || status === 'paid';

  if (!isSuccess) {
    await supabase
      .from('coin_topups')
      .update({ status: 'failed', provider_ref: providerRef || null, updated_at: new Date().toISOString() })
      .eq('id', topup.id);
    return res.status(200).json({ ok: true });
  }

  // Credit the coins to the user's wallet.
  const { data: profile } = await supabase
    .from('profiles')
    .select('ph_balance')
    .eq('id', topup.user_id)
    .single();

  const newBalance = (profile?.ph_balance || 0) + topup.coins;

  const { error: creditError } = await supabase
    .from('profiles')
    .update({ ph_balance: newBalance })
    .eq('id', topup.user_id);

  if (creditError) {
    return res.status(500).json({ error: 'Payment confirmed but crediting coins failed: ' + creditError.message });
  }

  await supabase
    .from('coin_topups')
    .update({ status: 'completed', provider_ref: providerRef || null, updated_at: new Date().toISOString() })
    .eq('id', topup.id);

  return res.status(200).json({ ok: true });
}

export default async function handler(req: any, res: any) {
  if (req.method !== 'POST') {
    res.setHeader('Allow', ['POST']);
    return res.status(405).json({ error: 'Method not allowed' });
  }

  const step = req.query?.step;

  if (step === 'subscribe') return handleSubscribe(req, res);
  if (step === 'unsubscribe') return handleUnsubscribe(req, res);
  if (step === 'send') return handleSend(req, res);
  if (step === 'topup-initiate') return handleTopupInitiate(req, res);
  if (step === 'topup-webhook') return handleTopupWebhook(req, res);

  return res.status(400).json({ error: 'Unknown or missing ?step parameter' });
}
