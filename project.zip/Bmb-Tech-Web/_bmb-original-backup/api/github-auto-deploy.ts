// Consolidated endpoint for the whole "Connect to GitHub" auto-deploy flow —
// merged into one file to stay under Vercel's Hobby-plan 12 Serverless
// Function limit. Routed by ?step=... (or, for the webhook, by the
// x-github-event header, since GitHub can't be told to add a query param).
//
//   GET  /api/github-auto-deploy?step=start&userId=xxx
//        -> 302 redirect to GitHub's OAuth authorize page
//
//   GET  /api/github-auto-deploy?step=callback&code=xxx&state=xxx
//        -> 302 redirect back into the app
//
//   GET  /api/github-auto-deploy?step=repos&userId=xxx&q=search-term
//        -> { repos, githubLogin }
//
//   GET  /api/github-auto-deploy?step=status&userId=xxx
//        -> { connected: boolean, githubLogin: string | null }
//        Cheap DB-only check (no GitHub API call) for whether this user has
//        an Auto Deploy GitHub connection — used by the Profile/Security
//        page, which only needs to know yes/no + the username, not the
//        full repo list `repos` above fetches.
//
//   POST /api/github-auto-deploy?step=connect
//        body: { userId, appId, repoFullName, branch }
//        -> { connected: true, branch }
//
//   DELETE /api/github-auto-deploy?step=connect
//        body: { userId, appId }
//        -> { connected: false }
//
//   POST /api/github-auto-deploy   (no ?step — this is what GitHub itself
//        calls; identified by the x-github-event header)
//        -> triggers a Heroku rebuild for any bot with auto-deploy enabled
//           on the pushed repo/branch

import { createClient } from '@supabase/supabase-js';
import crypto from 'crypto';

const HEROKU_API = 'https://api.heroku.com';

function getSupabase() {
  const supabaseUrl = process.env.VITE_SUPABASE_URL;
  const serviceRoleKey = process.env.SUPABASE_SERVICE_ROLE_KEY;
  if (!supabaseUrl || !serviceRoleKey) return null;
  return createClient(supabaseUrl, serviceRoleKey);
}

function verifySignature(secret: string, payload: string, signatureHeader: string | undefined) {
  if (!signatureHeader) return false;
  const expected = 'sha256=' + crypto.createHmac('sha256', secret).update(payload).digest('hex');
  const a = Buffer.from(expected);
  const b = Buffer.from(signatureHeader);
  return a.length === b.length && crypto.timingSafeEqual(a, b);
}

// ---------------------------------------------------------------------
// Step: start — redirect the browser to GitHub's OAuth authorize page
// ---------------------------------------------------------------------
async function handleStart(req: any, res: any) {
  const { userId } = req.query;
  if (!userId) return res.status(400).json({ error: 'userId is required' });

  const clientId = process.env.GITHUB_OAUTH_CLIENT_ID;
  if (!clientId) return res.status(500).json({ error: 'Server is missing GITHUB_OAUTH_CLIENT_ID' });

  const supabase = getSupabase();
  if (!supabase) return res.status(500).json({ error: 'Server is missing Supabase service credentials' });

  const state = crypto.randomUUID();
  const { error } = await supabase.from('github_oauth_states').insert({ state, user_id: userId });
  if (error) return res.status(500).json({ error: 'Failed to start GitHub connection: ' + error.message });

  const origin = `https://${req.headers.host}`;
  const redirectUri = `${origin}/api/github-auto-deploy?step=callback`;

  const params = new URLSearchParams({
    client_id: clientId,
    redirect_uri: redirectUri,
    scope: 'repo admin:repo_hook',
    state,
    allow_signup: 'false',
  });

  res.writeHead(302, { Location: `https://github.com/login/oauth/authorize?${params.toString()}` });
  res.end();
}

// ---------------------------------------------------------------------
// Step: callback — GitHub redirects here after the user approves access
// ---------------------------------------------------------------------
async function handleCallback(req: any, res: any) {
  const { code, state, error: githubError } = req.query;
  const origin = `https://${req.headers.host}`;

  const redirectWithError = (message: string) => {
    res.writeHead(302, { Location: `${origin}/my-bots?github_error=${encodeURIComponent(message)}` });
    res.end();
  };

  if (githubError) return redirectWithError(String(githubError));
  if (!code || !state) return redirectWithError('Missing code or state from GitHub.');

  const clientId = process.env.GITHUB_OAUTH_CLIENT_ID;
  const clientSecret = process.env.GITHUB_OAUTH_CLIENT_SECRET;
  const supabase = getSupabase();

  if (!clientId || !clientSecret || !supabase) {
    return redirectWithError('Server is missing GitHub/Supabase credentials.');
  }

  const { data: stateRow, error: stateError } = await supabase
    .from('github_oauth_states')
    .select('user_id')
    .eq('state', state)
    .maybeSingle();

  if (stateError || !stateRow) {
    return redirectWithError('This GitHub connection request expired or is invalid. Please try again.');
  }

  await supabase.from('github_oauth_states').delete().eq('state', state);

  try {
    const redirectUri = `${origin}/api/github-auto-deploy?step=callback`;

    const tokenRes = await fetch('https://github.com/login/oauth/access_token', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', Accept: 'application/json' },
      body: JSON.stringify({ client_id: clientId, client_secret: clientSecret, code, redirect_uri: redirectUri }),
    });
    const tokenData = await tokenRes.json();

    if (!tokenRes.ok || !tokenData.access_token) {
      return redirectWithError(tokenData.error_description || 'Failed to get an access token from GitHub.');
    }

    const userRes = await fetch('https://api.github.com/user', {
      headers: { Authorization: `Bearer ${tokenData.access_token}`, Accept: 'application/vnd.github+json' },
    });
    const githubUser = await userRes.json();

    if (!userRes.ok || !githubUser.login) {
      return redirectWithError('Failed to read GitHub account details.');
    }

    const { error: upsertError } = await supabase.from('github_connections').upsert({
      user_id: stateRow.user_id,
      github_login: githubUser.login,
      access_token: tokenData.access_token,
      scope: tokenData.scope || null,
      connected_at: new Date().toISOString(),
    });

    if (upsertError) return redirectWithError('Failed to save the GitHub connection: ' + upsertError.message);

    res.writeHead(302, { Location: `${origin}/my-bots?github_connected=1` });
    res.end();
  } catch (err: any) {
    return redirectWithError(err.message || 'Unexpected error connecting to GitHub.');
  }
}

// ---------------------------------------------------------------------
// Step: status — cheap yes/no connection check, DB-only (no GitHub API
// call), used by the Profile/Security page.
// ---------------------------------------------------------------------
async function handleStatus(req: any, res: any) {
  const { userId } = req.query;
  if (!userId) return res.status(400).json({ error: 'userId is required' });

  const supabase = getSupabase();
  if (!supabase) return res.status(500).json({ error: 'Server is missing Supabase service credentials' });

  const { data: connection } = await supabase
    .from('github_connections')
    .select('github_login')
    .eq('user_id', userId)
    .maybeSingle();

  return res.status(200).json({
    connected: !!connection,
    githubLogin: connection?.github_login || null,
  });
}

// ---------------------------------------------------------------------
// Step: repos — list (optionally search) the connected user's GitHub repos
// ---------------------------------------------------------------------
async function handleRepos(req: any, res: any) {
  const { userId, q } = req.query;
  if (!userId) return res.status(400).json({ error: 'userId is required' });

  const supabase = getSupabase();
  if (!supabase) return res.status(500).json({ error: 'Server is missing Supabase service credentials' });

  const { data: connection, error: connError } = await supabase
    .from('github_connections')
    .select('access_token, github_login')
    .eq('user_id', userId)
    .maybeSingle();

  if (connError || !connection) return res.status(404).json({ error: 'not_connected' });

  try {
    const perPage = 100;
    const searchQuery = String(q || '').trim().toLowerCase();

    // Always list only repos this connected account can see (owned, or
    // collaborator/org access) — never GitHub's global search, which would
    // surface other people's public repos too.
    const reposRes = await fetch(
      `https://api.github.com/user/repos?per_page=${perPage}&sort=pushed&affiliation=owner,collaborator,organization_member`,
      { headers: { Authorization: `Bearer ${connection.access_token}`, Accept: 'application/vnd.github+json' } }
    );
    const reposData = await reposRes.json();

    if (!reposRes.ok) {
      return res.status(reposRes.status).json({ error: reposData.message || 'Failed to fetch repos from GitHub.' });
    }

    const rawList = searchQuery
      ? (reposData as any[]).filter((r) => r.name.toLowerCase().includes(searchQuery))
      : reposData;
    const repos = rawList.map((r: any) => ({ fullName: r.full_name, name: r.name, private: r.private }));

    return res.status(200).json({ repos, githubLogin: connection.github_login });
  } catch (err: any) {
    return res.status(500).json({ error: err.message || 'Unexpected error fetching repos.' });
  }
}

// ---------------------------------------------------------------------
// Step: connect (POST) — link the app to a repo and create a webhook
// Step: connect (DELETE) — remove the webhook and disable auto-deploy
// ---------------------------------------------------------------------
async function handleConnectPost(req: any, res: any) {
  const supabase = getSupabase();
  if (!supabase) return res.status(500).json({ error: 'Server is missing Supabase service credentials' });

  const { userId, appId, repoFullName, branch } = req.body || {};
  if (!userId || !appId || !repoFullName) {
    return res.status(400).json({ error: 'userId, appId, and repoFullName are required' });
  }
  const targetBranch = branch || 'main';

  const { data: connection, error: connError } = await supabase
    .from('github_connections')
    .select('access_token')
    .eq('user_id', userId)
    .maybeSingle();

  if (connError || !connection) return res.status(404).json({ error: 'GitHub is not connected for this account yet.' });

  const { data: app, error: appError } = await supabase
    .from('deployed_apps')
    .select('id, user_id, heroku_app_name')
    .eq('id', appId)
    .maybeSingle();

  if (appError || !app || app.user_id !== userId) return res.status(404).json({ error: 'Bot not found.' });

  const webhookSecret = crypto.randomBytes(24).toString('hex');

  try {
    const origin = `https://${req.headers.host}`;
    const hookRes = await fetch(`https://api.github.com/repos/${repoFullName}/hooks`, {
      method: 'POST',
      headers: {
        Authorization: `Bearer ${connection.access_token}`,
        Accept: 'application/vnd.github+json',
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        name: 'web',
        active: true,
        events: ['push'],
        config: { url: `${origin}/api/github-auto-deploy`, content_type: 'json', secret: webhookSecret },
      }),
    });
    const hookData = await hookRes.json();

    if (!hookRes.ok) {
      return res.status(hookRes.status).json({
        error: hookData.message || 'Failed to create the GitHub webhook. Make sure you have admin access to this repo.',
      });
    }

    const { error: updateError } = await supabase
      .from('deployed_apps')
      .update({
        repo_full_name: repoFullName,
        auto_deploy_enabled: true,
        auto_deploy_branch: targetBranch,
        github_webhook_id: hookData.id,
        github_webhook_secret: webhookSecret,
      })
      .eq('id', appId);

    if (updateError) {
      return res.status(500).json({ error: 'Webhook created, but failed to save the connection: ' + updateError.message });
    }

    return res.status(200).json({ connected: true, branch: targetBranch });
  } catch (err: any) {
    return res.status(500).json({ error: err.message || 'Unexpected error connecting the repo.' });
  }
}

async function handleConnectDelete(req: any, res: any) {
  const supabase = getSupabase();
  if (!supabase) return res.status(500).json({ error: 'Server is missing Supabase service credentials' });

  const { userId, appId } = req.body || {};
  if (!userId || !appId) return res.status(400).json({ error: 'userId and appId are required' });

  const { data: connection } = await supabase
    .from('github_connections')
    .select('access_token')
    .eq('user_id', userId)
    .maybeSingle();

  const { data: app, error: appError } = await supabase
    .from('deployed_apps')
    .select('id, user_id, repo_full_name, github_webhook_id')
    .eq('id', appId)
    .maybeSingle();

  if (appError || !app || app.user_id !== userId) return res.status(404).json({ error: 'Bot not found.' });

  if (connection && app.repo_full_name && app.github_webhook_id) {
    await fetch(`https://api.github.com/repos/${app.repo_full_name}/hooks/${app.github_webhook_id}`, {
      method: 'DELETE',
      headers: { Authorization: `Bearer ${connection.access_token}`, Accept: 'application/vnd.github+json' },
    }).catch(() => {});
  }

  await supabase
    .from('deployed_apps')
    .update({ auto_deploy_enabled: false, github_webhook_id: null, github_webhook_secret: null })
    .eq('id', appId);

  return res.status(200).json({ connected: false });
}

// ---------------------------------------------------------------------
// GitHub's own webhook call — no ?step, identified by x-github-event
// ---------------------------------------------------------------------
async function handleWebhook(req: any, res: any) {
  const event = req.headers['x-github-event'];
  if (event === 'ping') return res.status(200).json({ ok: true });
  if (event !== 'push') return res.status(200).json({ ok: true, skipped: 'not a push event' });

  const payload = req.body;
  const repoFullName = payload?.repository?.full_name;
  const pushedRef = payload?.ref as string | undefined;
  const pushedBranch = pushedRef?.replace('refs/heads/', '');

  if (!repoFullName || !pushedBranch) return res.status(400).json({ error: 'Malformed payload' });

  const supabase = getSupabase();
  const apiKey = process.env.HEROKU_API_KEY;
  if (!supabase || !apiKey) return res.status(500).json({ error: 'Server is missing required credentials' });

  const { data: apps, error } = await supabase
    .from('deployed_apps')
    .select('id, heroku_app_name, auto_deploy_branch, github_webhook_secret, status')
    .eq('repo_full_name', repoFullName)
    .eq('auto_deploy_enabled', true)
    .eq('auto_deploy_branch', pushedBranch)
    .neq('status', 'deleted');

  if (error) return res.status(500).json({ error: error.message });
  if (!apps || apps.length === 0) return res.status(200).json({ ok: true, skipped: 'no matching auto-deploy apps' });

  const rawBody = (req as any).rawBody ? (req as any).rawBody.toString() : JSON.stringify(payload);
  const signatureHeader = req.headers['x-hub-signature-256'];

  const results: any[] = [];

  for (const app of apps) {
    const validSignature = app.github_webhook_secret ? verifySignature(app.github_webhook_secret, rawBody, signatureHeader) : false;

    if (!validSignature) {
      results.push({ appName: app.heroku_app_name, ok: false, error: 'invalid signature' });
      continue;
    }

    try {
      const tarballUrl = `https://github.com/${repoFullName}/tarball/${pushedBranch}`;
      const buildRes = await fetch(`${HEROKU_API}/apps/${app.heroku_app_name}/builds`, {
        method: 'POST',
        headers: {
          Authorization: `Bearer ${apiKey}`,
          Accept: 'application/vnd.heroku+json; version=3',
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ source_blob: { url: tarballUrl } }),
      });
      const buildData = await buildRes.json();

      if (!buildRes.ok) {
        results.push({ appName: app.heroku_app_name, ok: false, error: buildData.message });
        continue;
      }

      await supabase.from('deployed_apps').update({ status: 'building', build_id: buildData.id }).eq('id', app.id);
      results.push({ appName: app.heroku_app_name, ok: true, buildId: buildData.id });
    } catch (err: any) {
      results.push({ appName: app.heroku_app_name, ok: false, error: err.message });
    }
  }

  return res.status(200).json({ ok: true, results });
}

// ---------------------------------------------------------------------
// Step: disconnect-account — forget this user's GitHub OAuth connection
// entirely, so "Connect to GitHub" starts fresh (lets them link a
// different GitHub account instead of the one currently linked).
// ---------------------------------------------------------------------
async function handleDisconnectAccount(req: any, res: any) {
  const { userId } = req.body || {};
  if (!userId) return res.status(400).json({ error: 'userId is required' });

  const supabase = getSupabase();
  if (!supabase) return res.status(500).json({ error: 'Server is missing Supabase service credentials' });

  // Also clear repo_full_name/auto_deploy on every bot of this user's that
  // was using this GitHub connection — otherwise they'd be left pointing
  // at a repo the (now disconnected) account can no longer authorize.
  await supabase
    .from('deployed_apps')
    .update({ repo_full_name: null, auto_deploy_enabled: false })
    .eq('user_id', userId);

  const { error } = await supabase.from('github_connections').delete().eq('user_id', userId);
  if (error) return res.status(500).json({ error: error.message });

  return res.status(200).json({ ok: true });
}

// ---------------------------------------------------------------------
// Router
// ---------------------------------------------------------------------
export default async function handler(req: any, res: any) {
  const step = req.query?.step;
  const isGithubWebhookCall = !step && req.headers['x-github-event'];

  if (isGithubWebhookCall) return handleWebhook(req, res);

  if (step === 'start') return handleStart(req, res);
  if (step === 'callback') return handleCallback(req, res);
  if (step === 'repos') return handleRepos(req, res);
  if (step === 'status') return handleStatus(req, res);
  if (step === 'disconnect-account') return handleDisconnectAccount(req, res);

  if (step === 'connect') {
    if (req.method === 'POST') return handleConnectPost(req, res);
    if (req.method === 'DELETE') return handleConnectDelete(req, res);
    res.setHeader('Allow', ['POST', 'DELETE']);
    return res.status(405).json({ error: 'Method not allowed' });
  }

  return res.status(400).json({ error: 'Unknown or missing ?step parameter' });
}
