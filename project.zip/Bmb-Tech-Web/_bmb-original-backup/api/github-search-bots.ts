// GET /api/github-search-bots?q=whatsapp+bot+baileys&page=1
// Searches public GitHub repos matching the query and checks each top
// result for an app.json at its root, returning only deployable ones.
//
// Uses GitHub's unauthenticated search API (10 requests/min limit).

export default async function handler(req: any, res: any) {
  if (req.method !== 'GET') {
    return res.status(405).json({ error: 'Method not allowed' });
  }

  const { q, page } = req.query;
  if (!q || typeof q !== 'string') {
    return res.status(400).json({ error: 'Query parameter "q" is required' });
  }

  const pageNum = Number(page) || 1;

  try {
    const searchUrl = `https://api.github.com/search/repositories?q=${encodeURIComponent(
      q
    )}&sort=stars&order=desc&per_page=10&page=${pageNum}`;

    const searchRes = await fetch(searchUrl, {
      headers: { Accept: 'application/vnd.github+json' },
    });
    const searchData = await searchRes.json();

    if (!searchRes.ok) {
      return res.status(searchRes.status).json({
        error: searchData.message || 'GitHub search failed',
      });
    }

    const items = searchData.items || [];

    // Check each repo for an app.json at its root (in parallel)
    const results = await Promise.all(
      items.map(async (repo: any) => {
        const branch = repo.default_branch || 'main';
        try {
          const appJsonRes = await fetch(
            `https://raw.githubusercontent.com/${repo.full_name}/${branch}/app.json`
          );
          if (!appJsonRes.ok) return null;

          const appJson = await appJsonRes.json();

          return {
            repo_full_name: repo.full_name,
            repo_url: repo.html_url,
            name: appJson.name || repo.name,
            description: repo.description || appJson.description || '',
            logo_url: appJson.logo || repo.owner?.avatar_url || null,
            stars: repo.stargazers_count,
            forks: repo.forks_count,
            language: repo.language,
            updated_at: repo.updated_at,
            default_branch: branch,
            env_schema: appJson.env || {},
          };
        } catch {
          return null;
        }
      })
    );

    const deployable = results.filter(Boolean);

    return res.status(200).json({
      total_count: searchData.total_count,
      page: pageNum,
      results: deployable,
    });
  } catch (err: any) {
    return res.status(500).json({ error: err.message || 'Unexpected error searching GitHub' });
  }
}
