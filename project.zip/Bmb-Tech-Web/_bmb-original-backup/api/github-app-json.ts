// GET /api/github-app-json?repo=owner/repo-name
// Fetches app.json from a public GitHub repo (root, main or master branch).
// No auth token is used — public repos only, subject to GitHub's 60 req/hr
// unauthenticated rate limit.

export default async function handler(req: any, res: any) {
  if (req.method !== 'GET') {
    return res.status(405).json({ error: 'Method not allowed' });
  }

  const { repo } = req.query;
  if (!repo || typeof repo !== 'string' || !repo.includes('/')) {
    return res.status(400).json({ error: 'Provide repo as "owner/repo-name"' });
  }

  const branches = ['main', 'master'];

  try {
    // Fetch basic repo info first (description, default branch)
    const repoInfoRes = await fetch(`https://api.github.com/repos/${repo}`);
    if (!repoInfoRes.ok) {
      return res.status(404).json({ error: 'Repository not found or not public' });
    }
    const repoInfo = await repoInfoRes.json();
    const defaultBranch = repoInfo.default_branch || 'main';
    const orderedBranches = [defaultBranch, ...branches.filter(b => b !== defaultBranch)];

    let appJson = null;
    for (const branch of orderedBranches) {
      const rawUrl = `https://raw.githubusercontent.com/${repo}/${branch}/app.json`;
      const appJsonRes = await fetch(rawUrl);
      if (appJsonRes.ok) {
        appJson = await appJsonRes.json();
        break;
      }
    }

    if (!appJson) {
      return res.status(404).json({ error: 'app.json not found in this repository' });
    }

    return res.status(200).json({
      repo_full_name: repoInfo.full_name,
      repo_url: repoInfo.html_url,
      description: repoInfo.description || appJson.description || '',
      default_branch: defaultBranch,
      app_json: appJson,
    });
  } catch (err: any) {
    return res.status(500).json({ error: err.message || 'Failed to fetch app.json' });
  }
}
