// POST /api/delete-account
// Body: { userId: string }
// Header: Authorization: Bearer <user's access token>
//
// Permanently deletes a user's Supabase Auth account (and, via cascade,
// their profiles/deployed_apps rows). Requires SUPABASE_SERVICE_ROLE_KEY
// set in Vercel env vars — this key must never be exposed to the frontend.

import { createClient } from '@supabase/supabase-js';

export default async function handler(req: any, res: any) {
  if (req.method !== 'POST') {
    return res.status(405).json({ error: 'Method not allowed' });
  }

  const supabaseUrl = process.env.VITE_SUPABASE_URL;
  const serviceRoleKey = process.env.SUPABASE_SERVICE_ROLE_KEY;

  if (!supabaseUrl || !serviceRoleKey) {
    return res.status(500).json({ error: 'Server is missing Supabase service role configuration' });
  }

  // Verify the request carries a valid session token for the account being deleted —
  // this prevents anyone from deleting an arbitrary user by guessing an id.
  const authHeader = req.headers.authorization || '';
  const token = authHeader.replace('Bearer ', '');
  if (!token) {
    return res.status(401).json({ error: 'Missing authorization token' });
  }

  const admin = createClient(supabaseUrl, serviceRoleKey);

  const { data: userData, error: userError } = await admin.auth.getUser(token);
  if (userError || !userData?.user) {
    return res.status(401).json({ error: 'Invalid session' });
  }

  const { userId } = req.body || {};
  if (!userId || userId !== userData.user.id) {
    return res.status(403).json({ error: 'You can only delete your own account' });
  }

  try {
    const { error: deleteError } = await admin.auth.admin.deleteUser(userId);
    if (deleteError) {
      return res.status(500).json({ error: deleteError.message });
    }
    return res.status(200).json({ success: true });
  } catch (err: any) {
    return res.status(500).json({ error: err.message || 'Failed to delete account' });
  }
}
