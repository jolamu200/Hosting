// GET /api/heroku-build?appName=xxx&buildId=xxx
// Combined endpoint: returns build status, app URL, and live build output
// text in a single call (merges what were previously two separate functions
// to stay under Vercel's Hobby-plan Serverless Function limit).

const HEROKU_API = 'https://api.heroku.com';

export default async function handler(req: any, res: any) {
  if (req.method !== 'GET') {
    return res.status(405).json({ error: 'Method not allowed' });
  }

  const apiKey = process.env.HEROKU_API_KEY;
  if (!apiKey) {
    return res.status(500).json({ error: 'Server is missing HEROKU_API_KEY' });
  }

  const { appName, buildId } = req.query;
  if (!appName || !buildId) {
    return res.status(400).json({ error: 'appName and buildId are required' });
  }

  const headers = {
    Authorization: `Bearer ${apiKey}`,
    Accept: 'application/vnd.heroku+json; version=3',
  };

  try {
    const buildRes = await fetch(`${HEROKU_API}/apps/${appName}/builds/${buildId}`, { headers });
    const buildData = await buildRes.json();

    if (!buildRes.ok) {
      return res.status(buildRes.status).json({ error: buildData.message || 'Failed to fetch build' });
    }

    // App URL (only needed once the build succeeds, but cheap to fetch either way)
    const appRes = await fetch(`${HEROKU_API}/apps/${appName}`, { headers });
    const appData = appRes.ok ? await appRes.json() : null;

    // Live build output text, if available
    let output = '';
    if (buildData.output_stream_url) {
      try {
        const outputRes = await fetch(buildData.output_stream_url);
        output = await outputRes.text();
      } catch {
        // best-effort — status/appUrl below are still returned
      }
    }

    return res.status(200).json({
      status: buildData.status, // pending | succeeded | failed
      appUrl: appData?.web_url,
      appName: appData?.name,
      output,
    });
  } catch (err: any) {
    return res.status(500).json({ error: err.message || 'Unexpected error fetching build info' });
  }
}
