// GET /api/heroku-app-logs?appName=xxx
// Returns recent log lines as plain text.

const HEROKU_API = 'https://api.heroku.com';

export default async function handler(req: any, res: any) {
  if (req.method !== 'GET') {
    return res.status(405).json({ error: 'Method not allowed' });
  }

  const apiKey = process.env.HEROKU_API_KEY;
  if (!apiKey) {
    return res.status(500).json({ error: 'Server is missing HEROKU_API_KEY' });
  }

  const { appName, lines } = req.query;
  if (!appName) {
    return res.status(400).json({ error: 'appName is required' });
  }

  const lineCount = Number(lines) || 200;

  try {
    // Step 1: request a log session (Heroku gives back a temporary URL to fetch logs from)
    const sessionRes = await fetch(`${HEROKU_API}/apps/${appName}/log-sessions`, {
      method: 'POST',
      headers: {
        Authorization: `Bearer ${apiKey}`,
        Accept: 'application/vnd.heroku+json; version=3',
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({ dyno: undefined, lines: lineCount, tail: false }),
    });
    const sessionData = await sessionRes.json();

    if (!sessionRes.ok) {
      return res.status(sessionRes.status).json({ error: sessionData.message || 'Failed to open log session' });
    }

    // Step 2: fetch the actual log text from the URL Heroku gave us
    const logRes = await fetch(sessionData.logplex_url);
    const logText = await logRes.text();

    return res.status(200).json({ logs: logText });
  } catch (err: any) {
    return res.status(500).json({ error: err.message || 'Unexpected error fetching logs' });
  }
}
