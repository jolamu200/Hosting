// POST /api/heroku-update-config
// Body: { appName: string, envVars: Record<string,string> }
// Updates config vars on an existing Heroku app. Heroku automatically
// restarts all dynos after a config var change, so this doubles as "restart".

const HEROKU_API = 'https://api.heroku.com';

export default async function handler(req: any, res: any) {
  if (req.method !== 'POST') {
    return res.status(405).json({ error: 'Method not allowed' });
  }

  const apiKey = process.env.HEROKU_API_KEY;
  if (!apiKey) {
    return res.status(500).json({ error: 'Server is missing HEROKU_API_KEY' });
  }

  const { appName, envVars } = req.body || {};

  if (!appName || !envVars || typeof envVars !== 'object') {
    return res.status(400).json({ error: 'appName and envVars are required' });
  }

  try {
    const configRes = await fetch(`${HEROKU_API}/apps/${appName}/config-vars`, {
      method: 'PATCH',
      headers: {
        Authorization: `Bearer ${apiKey}`,
        Accept: 'application/vnd.heroku+json; version=3',
        'Content-Type': 'application/json',
      },
      body: JSON.stringify(envVars),
    });
    const data = await configRes.json();

    if (!configRes.ok) {
      return res.status(configRes.status).json({ error: data.message || 'Failed to update config vars' });
    }

    return res.status(200).json({ success: true });
  } catch (err: any) {
    return res.status(500).json({ error: err.message || 'Unexpected error updating config' });
  }
}
