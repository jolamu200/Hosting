// POST /api/auth-lookup
// Body: { action: 'username-to-email', username: string }
//   -> { email } for a given username (used to let users log in with a username)
// Body: { action: 'check-email-exists', email: string }
//   -> { exists: boolean } for a given email (used to block duplicate sign-ups)
//
// Both actions need the service role key to safely inspect auth.users
// without exposing it to the client directly. Merged into one function to
// stay within Vercel's Hobby-plan Serverless Function limit.

import { createClient } from '@supabase/supabase-js';

export default async function handler(req: any, res: any) {
  if (req.method !== 'POST') {
    return res.status(405).json({ error: 'Method not allowed' });
  }

  const supabaseUrl = process.env.VITE_SUPABASE_URL;
  const serviceRoleKey = process.env.SUPABASE_SERVICE_ROLE_KEY;

  if (!supabaseUrl || !serviceRoleKey) {
    return res.status(500).json({ error: 'Server is missing Supabase service role configuration' });
  }

  const admin = createClient(supabaseUrl, serviceRoleKey);
  const { action } = req.body || {};

  if (action === 'username-to-email') {
    const { username } = req.body || {};
    if (!username) {
      return res.status(400).json({ error: 'username is required' });
    }

    const { data: profileRow, error: profileError } = await admin
      .from('profiles')
      .select('id')
      .eq('username', username.trim())
      .single();

    if (profileError || !profileRow) {
      // Deliberately vague — don't reveal whether the username exists or not.
      return res.status(404).json({ error: 'Invalid username or password.' });
    }

    const { data: userData, error: userError } = await admin.auth.admin.getUserById(profileRow.id);

    if (userError || !userData?.user?.email) {
      return res.status(404).json({ error: 'Invalid username or password.' });
    }

    return res.status(200).json({ email: userData.user.email });
  }

  if (action === 'check-email-exists') {
    const { email } = req.body || {};
    if (!email) {
      return res.status(400).json({ error: 'email is required' });
    }

    // listUsers doesn't support filtering by email directly across all SDK
    // versions, so page through results and match — fine at this app's scale.
    let page = 1;
    const perPage = 200;
    let found = false;

    while (page <= 10) { // hard cap: 2000 users checked, plenty for this app
      const { data, error } = await admin.auth.admin.listUsers({ page, perPage });
      if (error) {
        return res.status(500).json({ error: error.message });
      }
      if (data.users.some((u: any) => u.email?.toLowerCase() === email.trim().toLowerCase())) {
        found = true;
        break;
      }
      if (data.users.length < perPage) break; // no more pages
      page += 1;
    }

    return res.status(200).json({ exists: found });
  }

  return res.status(400).json({ error: 'Unknown action' });
}
