import { useEffect, useState } from 'react';
import { Send, Trash2, Loader2, Bell, AlertCircle, CheckCircle2 } from 'lucide-react';
import { supabase } from '@/lib/supabaseClient';

interface AdminUpdate {
  id: string;
  title: string;
  message: string;
  link: string | null;
  created_at: string;
}

const AdminNotifications = () => {
  const [notifications, setNotifications] = useState<AdminUpdate[]>([]);
  const [loading, setLoading] = useState(true);
  const [title, setTitle] = useState('');
  const [message, setMessage] = useState('');
  const [link, setLink] = useState('');
  const [sending, setSending] = useState(false);
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');
  const [deletingId, setDeletingId] = useState<string | null>(null);

  const loadNotifications = async () => {
    setLoading(true);
    const { data } = await supabase
      .from('admin_updates')
      .select('id, title, message, link, created_at')
      .order('created_at', { ascending: false });
    setNotifications(data || []);
    setLoading(false);
  };

  useEffect(() => {
    loadNotifications();
  }, []);

  const handleSend = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setSuccess('');

    if (!title.trim() || !message.trim()) {
      setError('Title and message are required.');
      return;
    }

    setSending(true);

    let normalizedLink = link.trim() || null;
    if (normalizedLink) {
      // Strip an accidentally pasted full URL down to just the path
      normalizedLink = normalizedLink.replace(/^https?:\/\/[^/]+/, '');
      // Make sure it starts with a single leading slash
      if (!normalizedLink.startsWith('/')) normalizedLink = `/${normalizedLink}`;
    }

    const { error: sendError } = await supabase.from('admin_updates').insert({
      title: title.trim(),
      message: message.trim(),
      link: normalizedLink,
    });
    setSending(false);

    if (sendError) {
      setError(sendError.message);
      return;
    }

    // Best-effort push to everyone subscribed — the update itself is
    // already saved above regardless of whether this succeeds.
    fetch('/api/push-notifications?step=send', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        title: title.trim(),
        body: message.trim(),
        url: normalizedLink || '/',
      }),
    }).catch(() => {});

    setSuccess('Update sent to all users.');
    setTitle('');
    setMessage('');
    setLink('');
    loadNotifications();
  };

  const handleDelete = async (id: string) => {
    setDeletingId(id);
    await supabase.from('admin_updates').delete().eq('id', id);
    setNotifications(prev => prev.filter(n => n.id !== id));
    setDeletingId(null);
  };

  const formatDate = (iso: string) => new Date(iso).toLocaleString();

  return (
    <div className="space-y-6">
      {/* Send new notification */}
      <div className="gradient-border p-5">
        <h2 className="text-sm font-semibold text-muted-foreground tracking-wide uppercase mb-4 flex items-center gap-2">
          <Bell className="w-4 h-4 text-primary" />
          Send Update
        </h2>

        {error && (
          <div className="flex items-center gap-2 px-3 py-2.5 rounded-xl bg-destructive/10 border border-destructive/40 text-destructive text-xs mb-3">
            <AlertCircle className="w-4 h-4 shrink-0" />
            {error}
          </div>
        )}
        {success && (
          <div className="flex items-center gap-2 px-3 py-2.5 rounded-xl bg-success/10 border border-success/40 text-success text-xs mb-3">
            <CheckCircle2 className="w-4 h-4 shrink-0" />
            {success}
          </div>
        )}

        <form onSubmit={handleSend} className="space-y-3">
          <input
            type="text"
            placeholder="Title"
            value={title}
            onChange={(e) => setTitle(e.target.value)}
            className="w-full px-4 py-2.5 rounded-xl bg-background/50 border border-border/60 text-foreground text-sm placeholder:text-muted-foreground focus:outline-none focus:border-primary/60 transition-colors"
          />
          <textarea
            placeholder="Message"
            rows={3}
            value={message}
            onChange={(e) => setMessage(e.target.value)}
            className="w-full px-4 py-2.5 rounded-xl bg-background/50 border border-border/60 text-foreground text-sm placeholder:text-muted-foreground focus:outline-none focus:border-primary/60 transition-colors resize-none"
          />
          <input
            type="text"
            placeholder="Link (optional) — e.g. /bots/nova-xmd"
            value={link}
            onChange={(e) => setLink(e.target.value)}
            className="w-full px-4 py-2.5 rounded-xl bg-background/50 border border-border/60 text-foreground text-sm placeholder:text-muted-foreground focus:outline-none focus:border-primary/60 transition-colors"
          />
          <button
            type="submit"
            disabled={sending}
            className="w-full flex items-center justify-center gap-2 py-3 rounded-xl bg-gradient-to-r from-primary to-secondary text-primary-foreground text-sm font-bold hover:opacity-90 transition-opacity disabled:opacity-60"
          >
            {sending ? <Loader2 className="w-4 h-4 animate-spin" /> : <Send className="w-4 h-4" />}
            Send Update to All Users
          </button>
        </form>
      </div>

      {/* Sent notifications list */}
      <div>
        <h2 className="text-sm font-semibold text-muted-foreground tracking-wide uppercase mb-3">
          Sent Updates
        </h2>

        {loading && (
          <div className="flex items-center justify-center gap-2 py-10 text-muted-foreground text-sm">
            <Loader2 className="w-4 h-4 animate-spin" />
            Loading...
          </div>
        )}

        {!loading && notifications.length === 0 && (
          <p className="text-sm text-muted-foreground text-center py-10">No updates sent yet.</p>
        )}

        <div className="space-y-3">
          {notifications.map((notif) => (
            <div key={notif.id} className="gradient-border p-4">
              <div className="flex items-start justify-between gap-3 mb-1.5">
                <p className="font-semibold text-foreground text-sm">{notif.title}</p>
                <button
                  onClick={() => handleDelete(notif.id)}
                  disabled={deletingId === notif.id}
                  className="shrink-0 w-7 h-7 rounded-lg flex items-center justify-center text-destructive hover:bg-destructive/10 transition-colors disabled:opacity-50"
                >
                  {deletingId === notif.id ? (
                    <Loader2 className="w-3.5 h-3.5 animate-spin" />
                  ) : (
                    <Trash2 className="w-3.5 h-3.5" />
                  )}
                </button>
              </div>
              <p className="text-xs text-muted-foreground mb-2">{notif.message}</p>
              <div className="flex items-center justify-between text-[10px] text-muted-foreground">
                {notif.link && <span className="font-mono text-primary">{notif.link}</span>}
                <span className="ml-auto">{formatDate(notif.created_at)}</span>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default AdminNotifications;
