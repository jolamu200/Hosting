import { useEffect, useState } from 'react';
import { Loader2, Inbox, Check, X, ExternalLink, Clock, CheckCircle2, XCircle } from 'lucide-react';
import { supabase } from '@/lib/supabaseClient';

interface BotRequestRow {
  id: string;
  repo_url: string;
  pair_code_url: string;
  repo_name: string | null;
  description: string | null;
  reason: string | null;
  status: 'pending' | 'approved' | 'rejected';
  created_at: string;
}

const statusStyles: Record<BotRequestRow['status'], string> = {
  pending: 'text-warning bg-warning/10 border-warning/40',
  approved: 'text-success bg-success/10 border-success/40',
  rejected: 'text-destructive bg-destructive/10 border-destructive/40',
};

const AdminBotRequests = () => {
  const [requests, setRequests] = useState<BotRequestRow[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [actingId, setActingId] = useState<string | null>(null);

  const load = async () => {
    setLoading(true);
    const { data, error: fetchError } = await supabase
      .from('bot_requests')
      .select('id, repo_url, pair_code_url, repo_name, description, reason, status, created_at')
      .order('created_at', { ascending: false });

    if (fetchError) {
      setError('Failed to load bot requests: ' + fetchError.message);
    } else {
      setRequests((data as any) || []);
      setError('');
    }
    setLoading(false);
  };

  useEffect(() => {
    load();
  }, []);

  const handleApprove = async (id: string) => {
    setActingId(id);
    const { error: updateError } = await supabase
      .from('bot_requests')
      .update({ status: 'approved', reviewed_at: new Date().toISOString() })
      .eq('id', id);
    setActingId(null);

    if (updateError) {
      setError('Failed to update request: ' + updateError.message);
      return;
    }

    setRequests((prev) => prev.map((r) => (r.id === id ? { ...r, status: 'approved' } : r)));
  };

  const handleReject = async (id: string) => {
    setActingId(id);
    const { error: deleteError, count } = await supabase
      .from('bot_requests')
      .delete({ count: 'exact' })
      .eq('id', id);
    setActingId(null);

    if (deleteError) {
      setError('Failed to reject request: ' + deleteError.message);
      return;
    }

    if (!count) {
      setError('Reject did not delete anything — you may not have permission (check your admin role).');
      return;
    }

    // Rejected requests are removed entirely, not kept in any list.
    setRequests((prev) => prev.filter((r) => r.id !== id));
  };

  const pending = requests.filter((r) => r.status === 'pending');
  const reviewed = requests.filter((r) => r.status !== 'pending');

  if (loading) {
    return (
      <div className="flex items-center justify-center gap-2 py-16 text-muted-foreground text-sm">
        <Loader2 className="w-4 h-4 animate-spin" />
        Loading bot requests...
      </div>
    );
  }

  return (
    <div className="space-y-4">
      <h2 className="text-sm font-semibold text-muted-foreground tracking-wide uppercase flex items-center gap-2">
        <Inbox className="w-4 h-4 text-primary" />
        Bot Requests
        {pending.length > 0 && (
          <span className="px-1.5 py-0.5 rounded-full bg-primary/20 text-primary text-[10px] font-bold">
            {pending.length} pending
          </span>
        )}
      </h2>

      {error && (
        <div className="px-4 py-3 rounded-xl bg-destructive/10 border border-destructive/40 text-destructive text-sm">
          {error}
        </div>
      )}

      {requests.length === 0 && (
        <p className="text-sm text-muted-foreground text-center py-10">No bot requests yet.</p>
      )}

      <div className="space-y-2">
        {[...pending, ...reviewed].map((req) => (
          <div key={req.id} className="gradient-border p-4 space-y-2.5">
            <div className="flex items-start justify-between gap-2">
              <div className="min-w-0">
                <p className="font-semibold text-foreground text-sm truncate">
                  {req.repo_name || 'Untitled bot request'}
                </p>
                <p className="text-[11px] text-muted-foreground flex items-center gap-1 mt-0.5">
                  <Clock className="w-3 h-3" />
                  {new Date(req.created_at).toLocaleString()}
                </p>
              </div>
              <span
                className={`shrink-0 px-2 py-0.5 rounded-full border text-[10px] font-semibold uppercase tracking-wide ${statusStyles[req.status]}`}
              >
                {req.status}
              </span>
            </div>

            {req.description && (
              <p className="text-xs text-muted-foreground leading-relaxed">{req.description}</p>
            )}
            {req.reason && (
              <p className="text-xs text-muted-foreground/80 leading-relaxed italic">"{req.reason}"</p>
            )}

            <div className="flex flex-col gap-1 text-xs">
              <a
                href={req.repo_url}
                target="_blank"
                rel="noopener noreferrer"
                className="flex items-center gap-1.5 text-primary hover:underline truncate"
              >
                <ExternalLink className="w-3 h-3 shrink-0" />
                {req.repo_url}
              </a>
              <a
                href={req.pair_code_url}
                target="_blank"
                rel="noopener noreferrer"
                className="flex items-center gap-1.5 text-secondary hover:underline truncate"
              >
                <ExternalLink className="w-3 h-3 shrink-0" />
                {req.pair_code_url}
              </a>
            </div>

            {req.status === 'pending' ? (
              <div className="flex items-center gap-2 pt-1">
                <button
                  onClick={() => handleApprove(req.id)}
                  disabled={actingId === req.id}
                  className="flex-1 flex items-center justify-center gap-1.5 py-2 rounded-lg bg-success/15 text-success text-xs font-semibold hover:bg-success/25 transition-colors disabled:opacity-50"
                >
                  {actingId === req.id ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <Check className="w-3.5 h-3.5" />}
                  Approve
                </button>
                <button
                  onClick={() => handleReject(req.id)}
                  disabled={actingId === req.id}
                  className="flex-1 flex items-center justify-center gap-1.5 py-2 rounded-lg bg-destructive/15 text-destructive text-xs font-semibold hover:bg-destructive/25 transition-colors disabled:opacity-50"
                >
                  {actingId === req.id ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <X className="w-3.5 h-3.5" />}
                  Reject
                </button>
              </div>
            ) : (
              <p className="flex items-center gap-1.5 text-xs pt-1 text-success">
                <CheckCircle2 className="w-3.5 h-3.5" />
                Approved
              </p>
            )}
          </div>
        ))}
      </div>
    </div>
  );
};

export default AdminBotRequests;
