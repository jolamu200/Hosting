import { useEffect, useState } from 'react';
import { Trash2, Pencil, Loader2, Bot as BotIcon, X, Save, AlertCircle, Link as LinkIcon } from 'lucide-react';
import { supabase } from '@/lib/supabaseClient';

interface BotRow {
  id: string;
  name: string;
  repo_full_name: string;
  tags: string[];
  ram_mb: number;
  disk_mb: number;
  session_link: string | null;
  created_at: string;
}

const AdminBotList = () => {
  const [bots, setBots] = useState<BotRow[]>([]);
  const [loading, setLoading] = useState(true);
  const [deletingId, setDeletingId] = useState<string | null>(null);

  const [editBot, setEditBot] = useState<BotRow | null>(null);
  const [editName, setEditName] = useState('');
  const [editTags, setEditTags] = useState('');
  const [editRam, setEditRam] = useState(256);
  const [editDisk, setEditDisk] = useState(1024);
  const [editSessionLink, setEditSessionLink] = useState('');
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState('');

  const loadBots = async () => {
    setLoading(true);
    const { data } = await supabase
      .from('bots_catalog')
      .select('id, name, repo_full_name, tags, ram_mb, disk_mb, session_link, created_at')
      .order('created_at', { ascending: false });
    setBots(data || []);
    setLoading(false);
  };

  useEffect(() => {
    loadBots();
  }, []);

  const handleDelete = async (id: string) => {
    setDeletingId(id);
    await supabase.from('bots_catalog').delete().eq('id', id);
    setBots(prev => prev.filter(b => b.id !== id));
    setDeletingId(null);
  };

  const openEdit = (bot: BotRow) => {
    setEditBot(bot);
    setEditName(bot.name);
    setEditTags((bot.tags || []).join(', '));
    setEditRam(bot.ram_mb || 256);
    setEditDisk(bot.disk_mb || 1024);
    setEditSessionLink(bot.session_link || '');
    setError('');
  };

  const handleSaveEdit = async () => {
    if (!editBot) return;
    setSaving(true);
    setError('');

    const tags = editTags.split(',').map(t => t.trim()).filter(Boolean);
    const sessionLink = editSessionLink.trim() || null;

    const { error: saveError } = await supabase
      .from('bots_catalog')
      .update({ name: editName, tags, ram_mb: editRam, disk_mb: editDisk, session_link: sessionLink })
      .eq('id', editBot.id);

    setSaving(false);

    if (saveError) {
      setError(saveError.message);
      return;
    }

    setBots(prev =>
      prev.map(b =>
        b.id === editBot.id
          ? { ...b, name: editName, tags, ram_mb: editRam, disk_mb: editDisk, session_link: sessionLink }
          : b
      )
    );
    setEditBot(null);
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center gap-2 py-10 text-muted-foreground text-sm">
        <Loader2 className="w-4 h-4 animate-spin" />
        Loading bot catalog...
      </div>
    );
  }

  if (bots.length === 0) {
    return (
      <div className="flex flex-col items-center justify-center gap-2 py-10 text-center text-muted-foreground text-sm">
        <BotIcon className="w-8 h-8" />
        No bots added yet.
      </div>
    );
  }

  return (
    <>
      <div className="space-y-3">
        {bots.map((bot) => (
          <div key={bot.id} className="gradient-border p-4 flex items-center justify-between gap-3">
            <div className="min-w-0">
              <p className="font-semibold text-foreground truncate">{bot.name}</p>
              <p className="text-xs text-muted-foreground font-mono truncate">{bot.repo_full_name}</p>
              {bot.tags?.length > 0 && (
                <div className="flex flex-wrap gap-1 mt-1.5">
                  {bot.tags.slice(0, 4).map((tag, i) => (
                    <span key={i} className="text-[10px] px-1.5 py-0.5 rounded bg-primary/10 text-primary">
                      #{tag}
                    </span>
                  ))}
                </div>
              )}
            </div>
            <div className="flex items-center gap-1.5 shrink-0">
              <button
                onClick={() => openEdit(bot)}
                className="w-9 h-9 rounded-lg flex items-center justify-center text-foreground hover:bg-muted/40 transition-colors"
                aria-label="Edit bot"
              >
                <Pencil className="w-4 h-4" />
              </button>
              <button
                onClick={() => handleDelete(bot.id)}
                disabled={deletingId === bot.id}
                className="w-9 h-9 rounded-lg flex items-center justify-center text-destructive hover:bg-destructive/10 transition-colors disabled:opacity-50"
                aria-label="Delete bot"
              >
                {deletingId === bot.id ? (
                  <Loader2 className="w-4 h-4 animate-spin" />
                ) : (
                  <Trash2 className="w-4 h-4" />
                )}
              </button>
            </div>
          </div>
        ))}
      </div>

      {/* Edit modal */}
      {editBot && (
        <div
          className="fixed inset-0 z-[60] flex items-center justify-center bg-background/80 backdrop-blur-sm px-4"
          onClick={() => setEditBot(null)}
        >
          <div
            className="w-full max-w-sm gradient-border p-6"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="flex items-center justify-between mb-4">
              <p className="flex items-center gap-2 font-semibold text-foreground">
                <Pencil className="w-4 h-4 text-primary" />
                Edit Bot
              </p>
              <button onClick={() => setEditBot(null)} className="text-muted-foreground hover:text-foreground">
                <X className="w-5 h-5" />
              </button>
            </div>

            {error && (
              <div className="flex items-center gap-2 px-3 py-2.5 rounded-xl bg-destructive/10 border border-destructive/40 text-destructive text-xs mb-3">
                <AlertCircle className="w-4 h-4 shrink-0" />
                {error}
              </div>
            )}

            <div className="space-y-4">
              <div>
                <label className="text-xs font-semibold text-muted-foreground tracking-wide uppercase mb-1.5 block">
                  Bot Name
                </label>
                <input
                  type="text"
                  value={editName}
                  onChange={(e) => setEditName(e.target.value)}
                  className="w-full px-4 py-2.5 rounded-xl bg-background/50 border border-border/60 text-foreground text-sm focus:outline-none focus:border-primary/60 transition-colors"
                />
              </div>

              <div>
                <label className="text-xs font-semibold text-muted-foreground tracking-wide uppercase mb-1.5 block">
                  Tags (comma separated)
                </label>
                <input
                  type="text"
                  value={editTags}
                  onChange={(e) => setEditTags(e.target.value)}
                  placeholder="whatsapp, bot, baileys"
                  className="w-full px-4 py-2.5 rounded-xl bg-background/50 border border-border/60 text-foreground text-sm placeholder:text-muted-foreground focus:outline-none focus:border-primary/60 transition-colors"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-xs font-semibold text-muted-foreground tracking-wide uppercase mb-1.5 block">
                    RAM (MB)
                  </label>
                  <input
                    type="number"
                    value={editRam}
                    onChange={(e) => setEditRam(Number(e.target.value))}
                    className="w-full px-4 py-2.5 rounded-xl bg-background/50 border border-border/60 text-foreground text-sm focus:outline-none focus:border-primary/60 transition-colors"
                  />
                </div>
                <div>
                  <label className="text-xs font-semibold text-muted-foreground tracking-wide uppercase mb-1.5 block">
                    Disk (MB)
                  </label>
                  <input
                    type="number"
                    value={editDisk}
                    onChange={(e) => setEditDisk(Number(e.target.value))}
                    className="w-full px-4 py-2.5 rounded-xl bg-background/50 border border-border/60 text-foreground text-sm focus:outline-none focus:border-primary/60 transition-colors"
                  />
                </div>
              </div>

              <div>
                <label className="text-xs font-semibold text-muted-foreground tracking-wide uppercase mb-1.5 flex items-center gap-1.5">
                  <LinkIcon className="w-3.5 h-3.5 text-primary" />
                  Session ID Link
                </label>
                <input
                  type="text"
                  value={editSessionLink}
                  onChange={(e) => setEditSessionLink(e.target.value)}
                  placeholder="https://example.com/get-session"
                  className="w-full px-4 py-2.5 rounded-xl bg-background/50 border border-border/60 text-foreground text-sm placeholder:text-muted-foreground focus:outline-none focus:border-primary/60 transition-colors"
                />
                <p className="text-[11px] text-muted-foreground mt-1">
                  Shown as a "Get Session ID" button on the deploy page. Leave blank to hide it.
                </p>
              </div>

              <button
                onClick={handleSaveEdit}
                disabled={saving}
                className="w-full flex items-center justify-center gap-2 py-3 rounded-xl bg-gradient-to-r from-primary to-secondary text-primary-foreground text-sm font-bold hover:opacity-90 transition-opacity disabled:opacity-60"
              >
                {saving ? <Loader2 className="w-4 h-4 animate-spin" /> : <Save className="w-4 h-4" />}
                Save Changes
              </button>
            </div>
          </div>
        </div>
      )}
    </>
  );
};

export default AdminBotList;
