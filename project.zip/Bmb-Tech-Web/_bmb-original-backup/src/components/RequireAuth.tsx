import { ReactNode } from 'react';
import { useAuth } from '@/context/AuthContext';
import Login from '@/pages/Login';
import TechBackground from '@/components/TechBackground';
import AppHeader from '@/components/AppHeader';
import { usePresenceHeartbeat } from '@/hooks/usePresenceHeartbeat';

const RequireAuth = ({ children }: { children: ReactNode }) => {
  const { session, loading } = useAuth();
  usePresenceHeartbeat();

  if (loading) {
    return (
      <div className="min-h-screen bg-background text-foreground relative flex items-center justify-center">
        <TechBackground />
        <p className="relative z-10 text-muted-foreground text-sm font-mono tracking-widest">
          LOADING...
        </p>
      </div>
    );
  }

  if (!session) {
    return <Login />;
  }

  return (
    <>
      <AppHeader />
      {children}
    </>
  );
};

export default RequireAuth;
