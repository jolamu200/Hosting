import { Link } from 'react-router-dom';
import { Linkedin, Github } from 'lucide-react';

const XIcon = ({ className }: { className?: string }) => (
  <svg viewBox="0 0 24 24" className={className} fill="currentColor">
    <path d="M18.9 2H22l-7.6 8.7L23.3 22H16.6l-5.2-6.8L5.4 22H2.3l8.1-9.3L1.5 2h6.9l4.7 6.2L18.9 2Zm-1.2 18h1.7L7.4 4H5.6l12.1 16Z" />
  </svg>
);

const BlueskyIcon = ({ className }: { className?: string }) => (
  <svg viewBox="0 0 24 24" className={className} fill="currentColor">
    <path d="M12 10.8C10.4 7.6 7.5 4.6 5 3c-.5 3.5.3 8.7 2.6 10.6C5.4 13.5 3 14.4 3 16.8c2.5 1.1 5.6-.1 7.4-2 .3-.3.5-.2.5.2v1.6c0 1.1.4 2 1.1 2.4.7-.4 1.1-1.3 1.1-2.4v-1.6c0-.4.2-.5.5-.2 1.8 1.9 4.9 3.1 7.4 2 0-2.4-2.4-3.3-4.6-3.2C18.7 11.7 19.5 6.5 19 3c-2.5 1.6-5.4 4.6-7 7.8Z" />
  </svg>
);

const footerLinks = [
  { label: 'Home', href: '/' },
  { label: 'Careers', href: '/careers' },
  { label: 'Documentation', href: '/docs' },
  { label: 'Blog', href: '/blog' },
];

const legalLinks = [
  { label: 'Terms of Service', href: '/terms' },
  { label: 'Privacy', href: '/terms' },
  { label: 'Cookies', href: '/terms' },
];

const socialLinks = [
  { label: 'LinkedIn', href: 'https://www.linkedin.com/in/bmbtech', Icon: Linkedin },
  { label: 'X', href: 'https://x.com/bmb_tech', Icon: XIcon },
  { label: 'Bluesky', href: 'https://bsky.app/profile/bmbtech.bsky.social', Icon: BlueskyIcon },
  { label: 'GitHub', href: 'https://github.com/novaxmd', Icon: Github },
];

const Footer = () => {
  return (
    <footer className="relative z-10 mt-16 border-t border-border/50">
      <div className="max-w-4xl mx-auto px-4 py-6 flex flex-wrap items-center justify-center gap-x-8 gap-y-2">
        {footerLinks.map((link) => (
          <Link
            key={link.label}
            to={link.href}
            className="text-sm text-muted-foreground hover:text-foreground transition-colors"
          >
            {link.label}
          </Link>
        ))}
      </div>

      <div className="border-t border-border/50">
        <div className="max-w-4xl mx-auto px-4 py-6 flex flex-wrap items-center justify-center gap-x-8 gap-y-2">
          {legalLinks.map((link) => (
            <Link
              key={link.label}
              to={link.href}
              className="text-sm text-muted-foreground hover:text-foreground transition-colors"
            >
              {link.label}
            </Link>
          ))}
          <span className="text-sm text-muted-foreground">© 2026 bmbtech.zone.id</span>
        </div>
      </div>

      <div className="border-t border-border/50">
        <div className="max-w-4xl mx-auto px-4 py-6 flex flex-col items-center gap-4">
          <Link
            to="/contact"
            className="px-6 py-2.5 rounded-xl bg-gradient-to-r from-primary to-secondary text-primary-foreground text-sm font-semibold hover:opacity-90 transition-opacity"
          >
            Support
          </Link>
          <div className="flex items-center gap-4">
            {socialLinks.map(({ label, href, Icon }) => (
              <a
                key={label}
                href={href}
                target="_blank"
                rel="noopener noreferrer"
                aria-label={label}
                className="text-muted-foreground hover:text-foreground transition-colors"
              >
                <Icon className="w-4 h-4" />
              </a>
            ))}
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
