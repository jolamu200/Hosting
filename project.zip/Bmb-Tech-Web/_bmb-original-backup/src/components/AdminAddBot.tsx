import { useState } from 'react';
import { Search, Loader2, AlertCircle, CheckCircle2, Trash2, Plus } from 'lucide-react';
import { supabase } from '@/lib/supabaseClient';

interface EnvField {
  key: string;
  description?: string;
  required?: boolean;
  value?: string;
}

interface FetchedRepo {
  repo_full_name: string;
  repo_url: string;
  description: string;
  default_branch: string;
  app_json: {
    name?: string;
    description?: string;
    logo?: string;
    env?: Record<string, { description?: string; required?: boolean; value?: string }>;
  };
}

interface AdminAddBotProps {
  onAdded?: (bot: {
    id: string;
    name: string;
    slug: string;
    description: string;
    logo_url: string | null;
    creator_name: string;
    price_label: string | null;
    deploy_count: number;
    rank_badge: string | null;
  }) => void;
}

const AdminAddBot = ({ onAdded }: AdminAddBotProps = {}) => {
  const [repoInput, setRepoInput] = useState('');
  const [searching, setSearching] = useState(false);
  const [fetched, setFetched] = useState<FetchedRepo | null>(null);
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');
  const [saving, setSaving] = useState(false);

  // Editable fields before saving to the catalog
  const [botName, setBotName] = useState('');
  const [tagsInput, setTagsInput] = useState('');
  const [ramMb, setRamMb] = useState(256);
  const [diskMb, setDiskMb] = useState(1024);
  const [creatorName, setCreatorName] = useState('Bmb Tech');
  const [priceLabel, setPriceLabel] = useState('from 50 XD');
  const [sessionLink, setSessionLink] = useState('');

  const handleSearch = async () => {
    const repo = repoInput.trim().replace(/^https?:\/\/github\.com\//, '').replace(/\/$/, '');
    if (!repo || !repo.includes('/')) {
      setError('Enter a GitHub repo as "owner/repo-name" or a full GitHub URL.');
      return;
    }

    setError('');
    setSuccess('');
    setSearching(true);
    setFetched(null);

    try {
      const res = await fetch(`/api/github-app-json?repo=${encodeURIComponent(repo)}`);
      const data = await res.json();

      if (!res.ok) {
        setError(data.error || 'Failed to fetch repository.');
        setSearching(false);
        return;
      }

      setFetched(data);
      setBotName(data.app_json?.name || data.repo_full_name.split('/')[1]);
    } catch (err: any) {
      setError(err.message || 'Failed to fetch repository.');
    }

    setSearching(false);
  };

  const handleSave = async () => {
    if (!fetched) return;

    setError('');
    setSuccess('');
    setSaving(true);

    const slug = botName.toLowerCase().trim().replace(/[^a-z0-9]+/g, '-').replace(/(^-|-$)/g, '');
    const tags = tagsInput.split(',').map(t => t.trim()).filter(Boolean);

    const envSchema: EnvField[] = Object.entries(fetched.app_json?.env || {}).map(([key, val]) => ({
      key,
      description: val.description,
      required: val.required !== false,
      value: val.value,
    }));

    const { data: inserted, error: saveError } = await supabase
      .from('bots_catalog')
      .insert({
        name: botName,
        slug,
        description: fetched.description || fetched.app_json?.description || '',
        repo_url: fetched.repo_url,
        repo_full_name: fetched.repo_full_name,
        logo_url: fetched.app_json?.logo || null,
        tags,
        env_schema: envSchema,
        ram_mb: ramMb,
        disk_mb: diskMb,
        creator_name: creatorName || 'Bmb Tech',
        price_label: priceLabel || null,
        session_link: sessionLink.trim() || null,
      })
      .select('id, name, slug, description, logo_url, creator_name, price_label, deploy_count, rank_badge')
      .single();

    setSaving(false);

    if (saveError) {
      setError('Failed to save bot: ' + saveError.message);
      return;
    }

    // Let the parent page (e.g. the bots list) add it immediately —
    // no page reload needed to see the new bot show up.
    if (inserted) onAdded?.(inserted);

    setSuccess(`"${botName}" added to the bot catalog.`);
    setFetched(null);
    setRepoInput('');
    setBotName('');
    setSessionLink('');
    setTagsInput('');
    setCreatorName('Bmb Tech');
    setPriceLabel('from 50 XD');
  };

  return (
    <div className="space-y-6">
      {/* Search */}
      <div className="gradient-border p-5">
        <label className="text-xs font-semibold text-muted-foreground tracking-wide uppercase mb-2 block">
          GitHub Repository
        </label>
        <div className="flex gap-2">
          <input
            type="text"
            placeholder="owner/repo-name or full GitHub URL"
            value={repoInput}
            onChange={(e) => setRepoInput(e.target.value)}
            onKeyDown={(e) => e.key === 'Enter' && handleSearch()}
            className="flex-1 px-4 py-3 rounded-xl bg-background/50 border border-border/60 text-foreground text-sm placeholder:text-muted-foreground focus:outline-none focus:border-primary/60 transition-colors"
          />
          <button
            onClick={handleSearch}
            disabled={searching}
            className="flex items-center gap-2 px-5 py-3 rounded-xl bg-primary text-primary-foreground text-sm font-semibold hover:opacity-90 transition-opacity disabled:opacity-60"
          >
            {searching ? <Loader2 className="w-4 h-4 animate-spin" /> : <Search className="w-4 h-4" />}
            Search
          </button>
        </div>
        <p className="text-[11px] text-muted-foreground mt-2">
          The repo must be public and contain an app.json file at its root.
        </p>
      </div>

      {error && (
        <div className="flex items-center gap-2 px-4 py-3 rounded-xl bg-destructive/10 border border-destructive/40 text-destructive text-sm">
          <AlertCircle className="w-4 h-4 shrink-0" />
          {error}
        </div>
      )}
      {success && (
        <div className="flex items-center gap-2 px-4 py-3 rounded-xl bg-success/10 border border-success/40 text-success text-sm">
          <CheckCircle2 className="w-4 h-4 shrink-0" />
          {success}
        </div>
      )}

      {/* Preview + editable fields */}
      {fetched && (
        <div className="gradient-border p-5 space-y-4">
          <div>
            <p className="text-xs text-muted-foreground mb-1">Repository</p>
            <p className="text-sm font-mono text-primary">{fetched.repo_full_name}</p>
          </div>

          <div>
            <label className="text-xs font-semibold text-muted-foreground tracking-wide uppercase mb-1.5 block">
              Bot Name
            </label>
            <input
              type="text"
              value={botName}
              onChange={(e) => setBotName(e.target.value)}
              className="w-full px-4 py-2.5 rounded-xl bg-background/50 border border-border/60 text-foreground text-sm focus:outline-none focus:border-primary/60 transition-colors"
            />
          </div>

          <div>
            <label className="text-xs font-semibold text-muted-foreground tracking-wide uppercase mb-1.5 block">
              Tags (comma separated)
            </label>
            <input
              type="text"
              placeholder="whatsapp, bot, baileys"
              value={tagsInput}
              onChange={(e) => setTagsInput(e.target.value)}
              className="w-full px-4 py-2.5 rounded-xl bg-background/50 border border-border/60 text-foreground text-sm placeholder:text-muted-foreground focus:outline-none focus:border-primary/60 transition-colors"
            />
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="text-xs font-semibold text-muted-foreground tracking-wide uppercase mb-1.5 block">
                Creator Name
              </label>
              <input
                type="text"
                value={creatorName}
                onChange={(e) => setCreatorName(e.target.value)}
                className="w-full px-4 py-2.5 rounded-xl bg-background/50 border border-border/60 text-foreground text-sm focus:outline-none focus:border-primary/60 transition-colors"
              />
            </div>
            <div>
              <label className="text-xs font-semibold text-muted-foreground tracking-wide uppercase mb-1.5 block">
                Price Label
              </label>
              <input
                type="text"
                placeholder="from 50 XD"
                value={priceLabel}
                onChange={(e) => setPriceLabel(e.target.value)}
                className="w-full px-4 py-2.5 rounded-xl bg-background/50 border border-border/60 text-foreground text-sm placeholder:text-muted-foreground focus:outline-none focus:border-primary/60 transition-colors"
              />
              <p className="text-[10px] text-muted-foreground mt-1">Display only — deploy is still free.</p>
            </div>
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="text-xs font-semibold text-muted-foreground tracking-wide uppercase mb-1.5 block">
                RAM (MB)
              </label>
              <input
                type="number"
                value={ramMb}
                onChange={(e) => setRamMb(Number(e.target.value))}
                className="w-full px-4 py-2.5 rounded-xl bg-background/50 border border-border/60 text-foreground text-sm focus:outline-none focus:border-primary/60 transition-colors"
              />
            </div>
            <div>
              <label className="text-xs font-semibold text-muted-foreground tracking-wide uppercase mb-1.5 block">
                Disk (MB)
              </label>
              <input
                type="number"
                value={diskMb}
                onChange={(e) => setDiskMb(Number(e.target.value))}
                className="w-full px-4 py-2.5 rounded-xl bg-background/50 border border-border/60 text-foreground text-sm focus:outline-none focus:border-primary/60 transition-colors"
              />
            </div>
          </div>

          <div>
            <label className="text-xs font-semibold text-muted-foreground tracking-wide uppercase mb-1.5 block">
              Session ID Link
            </label>
            <input
              type="text"
              placeholder="https://example.com/get-session"
              value={sessionLink}
              onChange={(e) => setSessionLink(e.target.value)}
              className="w-full px-4 py-2.5 rounded-xl bg-background/50 border border-border/60 text-foreground text-sm placeholder:text-muted-foreground focus:outline-none focus:border-primary/60 transition-colors"
            />
            <p className="text-[10px] text-muted-foreground mt-1">
              Shown as a "Get Session ID" button on the deploy page. Leave blank to hide it.
            </p>
          </div>

          {fetched.app_json?.env && Object.keys(fetched.app_json.env).length > 0 && (
            <div>
              <p className="text-xs font-semibold text-muted-foreground tracking-wide uppercase mb-2">
                Detected env fields
              </p>
              <div className="space-y-1.5">
                {Object.entries(fetched.app_json.env).map(([key, val]) => (
                  <div key={key} className="flex items-center gap-2 text-xs px-3 py-2 rounded-lg bg-background/40 border border-border/40">
                    <span className="font-mono text-primary">{key}</span>
                    {val.required !== false && (
                      <span className="text-[10px] px-1.5 py-0.5 rounded bg-secondary/20 text-secondary">Required</span>
                    )}
                    {val.description && <span className="text-muted-foreground truncate">{val.description}</span>}
                  </div>
                ))}
              </div>
            </div>
          )}

          <button
            onClick={handleSave}
            disabled={saving || !botName}
            className="w-full flex items-center justify-center gap-2 py-3 rounded-xl bg-gradient-to-r from-primary to-secondary text-primary-foreground text-sm font-bold hover:opacity-90 transition-opacity disabled:opacity-60"
          >
            {saving ? <Loader2 className="w-4 h-4 animate-spin" /> : <Plus className="w-4 h-4" />}
            Add to Bot Catalog
          </button>
        </div>
      )}
    </div>
  );
};

export default AdminAddBot;
