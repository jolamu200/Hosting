import { useState } from 'react';
import { Mail, Phone, User, Trash2, Pencil, Share2, Check, X, Save, Loader2, AlertTriangle } from 'lucide-react';
import { supabase } from '@/lib/supabaseClient';

interface ContactMessage {
  id: string;
  name: string;
  email: string | null;
  phone: string | null;
  message: string;
  created_at: string;
}

interface Props {
  message: ContactMessage;
  onDeleted: (id: string) => void;
  onUpdated: (updated: ContactMessage) => void;
}

const AdminMessageCard = ({ message, onDeleted, onUpdated }: Props) => {
  const [editing, setEditing] = useState(false);
  const [name, setName] = useState(message.name);
  const [email, setEmail] = useState(message.email || '');
  const [phone, setPhone] = useState(message.phone || '');
  const [text, setText] = useState(message.message);
  const [saving, setSaving] = useState(false);
  const [deleting, setDeleting] = useState(false);
  const [copied, setCopied] = useState(false);
  const [showDeleteConfirm, setShowDeleteConfirm] = useState(false);

  const formatDate = (iso: string) => new Date(iso).toLocaleString();

  const handleDelete = async () => {
    setDeleting(true);
    const { error, count } = await supabase
      .from('contact_messages')
      .delete({ count: 'exact' })
      .eq('id', message.id);
    setDeleting(false);
    setShowDeleteConfirm(false);

    if (!error && count) onDeleted(message.id);
  };

  const handleSave = async () => {
    setSaving(true);
    const { error } = await supabase
      .from('contact_messages')
      .update({
        name,
        email: email || null,
        phone: phone || null,
        message: text,
      })
      .eq('id', message.id);
    setSaving(false);

    if (!error) {
      onUpdated({ ...message, name, email: email || null, phone: phone || null, message: text });
      setEditing(false);
    }
  };

  const handleCancel = () => {
    setName(message.name);
    setEmail(message.email || '');
    setPhone(message.phone || '');
    setText(message.message);
    setEditing(false);
  };

  const handleShare = () => {
    const parts = [`Name: ${message.name}`];
    if (message.email) parts.push(`Email: ${message.email}`);
    if (message.phone) parts.push(`Phone: ${message.phone}`);
    parts.push(`Message: ${message.message}`);

    navigator.clipboard.writeText(parts.join('\n')).then(() => {
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    });
  };

  if (editing) {
    return (
      <div className="gradient-border p-5 border-primary/50">
        <div className="space-y-3">
          <input
            type="text"
            value={name}
            onChange={(e) => setName(e.target.value)}
            placeholder="Name"
            className="w-full px-3 py-2 rounded-lg bg-background/50 border border-border/60 text-foreground text-sm focus:outline-none focus:border-primary/60"
          />
          <div className="grid grid-cols-2 gap-3">
            <input
              type="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              placeholder="Email"
              className="w-full px-3 py-2 rounded-lg bg-background/50 border border-border/60 text-foreground text-sm focus:outline-none focus:border-primary/60"
            />
            <input
              type="tel"
              value={phone}
              onChange={(e) => setPhone(e.target.value)}
              placeholder="Phone"
              className="w-full px-3 py-2 rounded-lg bg-background/50 border border-border/60 text-foreground text-sm focus:outline-none focus:border-primary/60"
            />
          </div>
          <textarea
            value={text}
            onChange={(e) => setText(e.target.value)}
            rows={4}
            placeholder="Message"
            className="w-full px-3 py-2 rounded-lg bg-background/50 border border-border/60 text-foreground text-sm resize-none focus:outline-none focus:border-primary/60"
          />
          <div className="flex gap-2">
            <button
              onClick={handleCancel}
              className="flex-1 flex items-center justify-center gap-1.5 py-2 rounded-lg border border-border/50 text-sm text-foreground hover:bg-muted/40 transition-colors"
            >
              <X className="w-3.5 h-3.5" />
              Cancel
            </button>
            <button
              onClick={handleSave}
              disabled={saving}
              className="flex-1 flex items-center justify-center gap-1.5 py-2 rounded-lg bg-primary text-primary-foreground text-sm font-semibold hover:opacity-90 transition-opacity disabled:opacity-60"
            >
              {saving ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <Save className="w-3.5 h-3.5" />}
              Save
            </button>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="gradient-border p-5">
      <div className="flex items-start justify-between gap-3 mb-3 flex-wrap">
        <div className="flex items-center gap-2">
          <User className="w-4 h-4 text-primary" />
          <span className="font-semibold text-foreground">{message.name}</span>
        </div>
        <span className="text-xs text-muted-foreground font-mono">
          {formatDate(message.created_at)}
        </span>
      </div>

      {(message.email || message.phone) && (
        <div className="flex flex-wrap gap-4 mb-3 text-xs text-muted-foreground">
          {message.email && (
            <span className="flex items-center gap-1.5">
              <Mail className="w-3.5 h-3.5" />
              {message.email}
            </span>
          )}
          {message.phone && (
            <span className="flex items-center gap-1.5">
              <Phone className="w-3.5 h-3.5" />
              {message.phone}
            </span>
          )}
        </div>
      )}

      <p className="text-sm text-foreground/90 leading-relaxed whitespace-pre-wrap mb-4">
        {message.message}
      </p>

      <div className="flex gap-2">
        <button
          onClick={handleShare}
          className="flex-1 flex items-center justify-center gap-1.5 py-2 rounded-lg border border-border/50 text-xs text-foreground hover:bg-muted/40 transition-colors"
        >
          {copied ? <Check className="w-3.5 h-3.5 text-success" /> : <Share2 className="w-3.5 h-3.5" />}
          {copied ? 'Copied' : 'Share'}
        </button>
        <button
          onClick={() => setEditing(true)}
          className="flex-1 flex items-center justify-center gap-1.5 py-2 rounded-lg border border-border/50 text-xs text-foreground hover:bg-muted/40 transition-colors"
        >
          <Pencil className="w-3.5 h-3.5" />
          Edit
        </button>
        <button
          onClick={() => setShowDeleteConfirm(true)}
          disabled={deleting}
          className="flex-1 flex items-center justify-center gap-1.5 py-2 rounded-lg border border-destructive/40 text-destructive text-xs hover:bg-destructive/10 transition-colors disabled:opacity-60"
        >
          {deleting ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <Trash2 className="w-3.5 h-3.5" />}
          Delete
        </button>
      </div>

      {/* Styled delete confirmation modal, replacing window.confirm() */}
      {showDeleteConfirm && (
        <div
          className="fixed inset-0 z-[60] flex items-center justify-center bg-background/80 backdrop-blur-sm px-4"
          onClick={() => !deleting && setShowDeleteConfirm(false)}
        >
          <div
            className="w-full max-w-sm gradient-border p-6"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="flex items-center gap-2 mb-3">
              <AlertTriangle className="w-5 h-5 text-destructive" />
              <p className="font-semibold text-foreground">Delete this message?</p>
            </div>
            <p className="text-xs text-muted-foreground mb-5">
              This will permanently delete the message from{' '}
              <span className="text-foreground font-medium">{message.name}</span>. This cannot be undone.
            </p>

            <div className="flex gap-3">
              <button
                onClick={() => setShowDeleteConfirm(false)}
                disabled={deleting}
                className="flex-1 py-2.5 rounded-xl border border-border/60 text-sm text-foreground hover:bg-muted/40 transition-colors disabled:opacity-60"
              >
                Cancel
              </button>
              <button
                onClick={handleDelete}
                disabled={deleting}
                className="flex-1 flex items-center justify-center gap-1.5 py-2.5 rounded-xl bg-destructive text-white text-sm font-semibold hover:opacity-90 transition-opacity disabled:opacity-60"
              >
                {deleting ? <Loader2 className="w-4 h-4 animate-spin" /> : <Trash2 className="w-4 h-4" />}
                {deleting ? 'Deleting...' : 'Delete'}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default AdminMessageCard;
