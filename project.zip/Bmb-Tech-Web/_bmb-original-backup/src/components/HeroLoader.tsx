import { useNavigate } from 'react-router-dom';
import { Rocket, Search, Sparkles } from 'lucide-react';
import profileImage from '@/assets/profile.jpg';

const HeroLoader = () => {
  const navigate = useNavigate();

  return (
    <div className="flex flex-col items-center gap-8 max-w-2xl mx-auto px-4 text-center">
      {/* Badge */}
      <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-success/10 border border-success/30">
        <span className="w-1.5 h-1.5 rounded-full bg-success animate-pulse" />
        <span className="text-xs font-medium text-success" style={{ fontFamily: 'Rajdhani, sans-serif' }}>
          Cloud Infrastructure &amp; App Deployment
        </span>
      </div>

      {/* Profile Picture with animations */}
      <div className="relative group">
        <div className="absolute -inset-8 rounded-full bg-gradient-to-r from-primary/30 via-secondary/30 to-primary/30 blur-2xl animate-pulse opacity-60" />
        <div className="absolute -inset-6 rounded-full border-2 border-dashed border-primary/40 animate-spin-slow" />
        <div className="absolute -inset-10 rounded-full border border-secondary/30 animate-spin-reverse" />

        <div className="absolute inset-0 w-48 h-48 md:w-56 md:h-56 -translate-x-4 -translate-y-4">
          <div className="absolute inset-0 animate-orbit">
            <div className="absolute top-0 left-1/2 -translate-x-1/2 w-3 h-3 rounded-full bg-primary shadow-lg shadow-primary/50" />
          </div>
          <div className="absolute inset-0 animate-orbit-reverse" style={{ animationDelay: '-2s' }}>
            <div className="absolute top-0 left-1/2 -translate-x-1/2 w-2 h-2 rounded-full bg-secondary shadow-lg shadow-secondary/50" />
          </div>
          <div className="absolute inset-0 animate-orbit-fast">
            <div className="absolute top-0 left-1/2 -translate-x-1/2 w-4 h-4 rounded-full bg-gradient-to-r from-cyan-400 to-blue-500 blur-[1px]" />
          </div>
        </div>

        <div className="absolute -inset-2 rounded-full bg-gradient-to-r from-primary via-secondary to-primary animate-spin-slow opacity-75 blur-sm" />
        <div className="absolute -inset-1 rounded-full bg-gradient-to-r from-secondary via-primary to-secondary animate-spin-reverse opacity-60" />

        <div className="relative w-36 h-36 md:w-48 md:h-48 rounded-full overflow-hidden border-4 border-background transition-all duration-700 group-hover:scale-105 group-hover:shadow-2xl group-hover:shadow-primary/30">
          <img
            src={profileImage}
            alt="Bmb Tech"
            className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-110"
          />
        </div>

        <div className="absolute -top-4 -right-4 w-4 h-4 rounded-full bg-primary animate-float shadow-lg shadow-primary/50" />
        <div className="absolute -bottom-2 -left-4 w-3 h-3 rounded-full bg-secondary animate-float shadow-lg shadow-secondary/50" style={{ animationDelay: '0.5s' }} />
        <div className="absolute top-1/2 -right-6 w-2 h-2 rounded-full bg-cyan-400 animate-float" style={{ animationDelay: '1s' }} />
      </div>

      {/* Subtext */}
      <p className="text-base md:text-lg text-muted-foreground leading-relaxed max-w-xl">
        Bmb Tech is your fastest path from idea to production. Our fully managed platform
        provides scalable bot hosting so you can stay focused on building great apps.
      </p>

      {/* CTAs */}
      <div className="flex flex-col gap-3 w-full max-w-xs">
        <button
          onClick={() => navigate('/my-bots')}
          className="flex items-center justify-center gap-2 py-3.5 rounded-xl bg-gradient-to-r from-primary to-secondary text-primary-foreground text-sm font-semibold hover:opacity-90 transition-opacity"
        >
          <Rocket className="w-4 h-4" />
          Start for free
        </button>
        <button
          onClick={() => navigate('/discover')}
          className="flex items-center justify-center gap-2 py-3.5 rounded-xl border border-border/60 text-foreground text-sm font-medium hover:bg-muted/40 transition-colors"
        >
          <Search className="w-4 h-4" />
          Browse apps
        </button>
      </div>

      {/* Fine print */}
      <div className="flex items-center gap-2 px-4 py-1.5 rounded-full bg-card/40 border border-border/40">
        <Sparkles className="w-3.5 h-3.5 text-primary" />
        <span className="text-xs text-muted-foreground">Free to deploy &middot; No credit card required</span>
      </div>
    </div>
  );
};

export default HeroLoader;
