import { useEffect, useState } from 'react';

interface Piece {
  id: number;
  left: number; // vw %
  delay: number; // seconds
  duration: number; // seconds
  color: string;
  size: number; // px
  drift: number; // px, horizontal sway
}

const COLORS = ['#47b0f2', '#b432ca', '#4ade80', '#facc15', '#f472b6', '#60a5fa'];

// Confetti burst: small pieces rise and fall for ~5s, then unmount.
// Used when a user opens a notification.
const ConfettiEffect = ({ onDone }: { onDone: () => void }) => {
  const [pieces, setPieces] = useState<Piece[]>([]);

  useEffect(() => {
    const generated: Piece[] = Array.from({ length: 40 }, (_, i) => ({
      id: i,
      left: Math.random() * 100,
      delay: Math.random() * 0.6,
      duration: 2.2 + Math.random() * 1.6,
      color: COLORS[Math.floor(Math.random() * COLORS.length)],
      size: 6 + Math.random() * 6,
      drift: (Math.random() - 0.5) * 120,
    }));
    setPieces(generated);

    const timer = setTimeout(onDone, 5000);
    return () => clearTimeout(timer);
  }, [onDone]);

  return (
    <div className="fixed inset-0 z-[100] pointer-events-none overflow-hidden">
      {pieces.map((p) => (
        <span
          key={p.id}
          className="absolute rounded-sm"
          style={{
            left: `${p.left}%`,
            bottom: '-20px',
            width: p.size,
            height: p.size * 1.6,
            backgroundColor: p.color,
            animation: `confetti-rise-fall ${p.duration}s ease-in-out ${p.delay}s 1`,
            // @ts-ignore custom property used by the keyframes below
            '--drift': `${p.drift}px`,
          }}
        />
      ))}
      <style>{`
        @keyframes confetti-rise-fall {
          0% { transform: translate(0, 0) rotate(0deg); opacity: 0; }
          15% { opacity: 1; }
          50% { transform: translate(var(--drift), -60vh) rotate(180deg); opacity: 1; }
          85% { opacity: 1; }
          100% { transform: translate(calc(var(--drift) * 1.4), 5vh) rotate(360deg); opacity: 0; }
        }
      `}</style>
    </div>
  );
};

export default ConfettiEffect;
