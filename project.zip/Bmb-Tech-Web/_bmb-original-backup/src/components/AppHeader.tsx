import { useNavigate, useLocation } from 'react-router-dom';
import profileImage from '@/assets/profile.jpg';
import { useAuth } from '@/context/AuthContext';
import NotificationBell from './NotificationBell';

// Persistent top bar shown on every interior page once logged in — brand
// name + logo on the left (fixed, like the menu toggle), notification bell
// and avatar space on the right. Mirrors FloatingMenu's fixed positioning
// so it behaves the same way wherever the user navigates.
const AppHeader = () => {
  const navigate = useNavigate();
  const location = useLocation();
  const { user } = useAuth();

  if (!user) return null;

  return (
    <div className="fixed top-0 inset-x-0 z-40 flex items-center justify-between gap-3 px-16 py-3 bg-background/80 backdrop-blur-md border-b border-border/40">
      <button
        onClick={() => location.pathname !== '/my-bots' && navigate('/my-bots')}
        className="flex items-center gap-2.5 min-w-0"
      >
        <img
          src={profileImage}
          alt="Bmb Hosting"
          className="w-8 h-8 rounded-full object-cover border-2 border-primary/50 shrink-0"
        />
        <span className="font-bold text-foreground text-base truncate">Bmb Hosting</span>
      </button>

      <NotificationBell />
    </div>
  );
};

export default AppHeader;
