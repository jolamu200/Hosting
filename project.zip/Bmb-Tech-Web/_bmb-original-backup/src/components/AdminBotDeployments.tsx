import { useEffect, useState } from 'react';
import { Loader2, Server, Trash2, RefreshCw, AlertCircle, CheckCircle2, XCircle } from 'lucide-react';

interface DeploymentRow {
  id: string;
  heroku_app_name: string;
  bot_name: string;
  user_id: string;
  status: string;
  created_at: string;
  state: 'up' | 'down' | 'unknown';
}

const AdminBotDeployments = () => {
  const [apps, setApps] = useState<DeploymentRow[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [selected, setSelected] = useState<Set<string>>(new Set());
  const [deleting, setDeleting] = useState(false);
  const [confirmOpen, setConfirmOpen] = useState(false);

  const [checkingStatus, setCheckingStatus] = useState(false);
  const [checkedCount, setCheckedCount] = useState(0);

  const load = async () => {
    setLoading(true);
    setError('');
    setApps([]);
    setCheckedCount(0);

    try {
      const res = await fetch('/api/heroku-dyno?scope=all-status');
      const rawText = await res.text();
      let data: any = {};
      try {
        data = JSON.parse(rawText);
      } catch {
        setError(`Server returned a non-JSON response (status ${res.status}): ${rawText.slice(0, 200)}`);
        setLoading(false);
        return;
      }

      if (!res.ok) {
        setError(`(${res.status}) ${data.error || 'Failed to load deployments.'}`);
        setLoading(false);
        return;
      }

      const loadedApps: DeploymentRow[] = data.apps || [];
      setApps(loadedApps);
      setLoading(false);

      // Now fill in live Heroku dyno state in small batches, so ~100 bots
      // doesn't time out in one request. Only bots the database thinks are
      // "live" are worth checking — others are already known-inactive.
      const toCheck = loadedApps.filter((a) => a.status === 'live').map((a) => a.heroku_app_name);
      if (toCheck.length === 0) return;

      setCheckingStatus(true);
      const batchSize = 10;

      for (let i = 0; i < toCheck.length; i += batchSize) {
        const batch = toCheck.slice(i, i + batchSize);
        try {
          const batchRes = await fetch(`/api/heroku-dyno?scope=status-batch&names=${batch.map(encodeURIComponent).join(',')}`);
          const batchData = await batchRes.json();
          if (batchRes.ok) {
            const stateByName: Record<string, string> = {};
            for (const s of batchData.states || []) stateByName[s.heroku_app_name] = s.state;

            setApps((prev) =>
              prev.map((app) => (stateByName[app.heroku_app_name] ? { ...app, state: stateByName[app.heroku_app_name] as any } : app))
            );
          }
        } catch {
          // best-effort — those apps just stay "unknown"
        }
        setCheckedCount((c) => c + batch.length);
      }
      setCheckingStatus(false);
    } catch (err: any) {
      setError('Network error: ' + (err?.message || String(err)));
      setLoading(false);
    }
  };

  useEffect(() => {
    load();
  }, []);

  const offlineApps = apps.filter((a) => a.status === 'failed' || (a.status !== 'live' && a.state !== 'up') || a.state === 'down');
  const onlineCount = apps.filter((a) => a.state === 'up').length;

  const toggleSelect = (appName: string) => {
    setSelected((prev) => {
      const next = new Set(prev);
      if (next.has(appName)) next.delete(appName);
      else next.add(appName);
      return next;
    });
  };

  const selectAllOffline = () => {
    setSelected(new Set(offlineApps.map((a) => a.heroku_app_name)));
  };

  const handleBulkDelete = async () => {
    if (selected.size === 0) return;
    setDeleting(true);
    setError('');

    try {
      const res = await fetch('/api/heroku-dyno', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ action: 'bulk-delete', appNames: Array.from(selected) }),
      });
      const data = await res.json();

      if (!res.ok) {
        setError(data.error || 'Failed to delete selected bots.');
      } else {
        const failed = (data.results || []).filter((r: any) => !r.ok);
        if (failed.length > 0) {
          setError(`${failed.length} bot(s) failed to delete: ${failed.map((f: any) => f.appName).join(', ')}`);
        }
        setApps((prev) => prev.filter((a) => !selected.has(a.heroku_app_name) || failed.some((f: any) => f.appName === a.heroku_app_name)));
        setSelected(new Set());
      }
    } catch {
      setError('Failed to delete selected bots.');
    }

    setDeleting(false);
    setConfirmOpen(false);
  };

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <h2 className="text-sm font-semibold text-muted-foreground tracking-wide uppercase flex items-center gap-2">
          <Server className="w-4 h-4 text-primary" />
          Bot Deployments
        </h2>
        <button
          onClick={load}
          disabled={loading}
          className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg border border-border/60 text-xs text-muted-foreground hover:text-foreground transition-colors disabled:opacity-50"
        >
          {loading ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <RefreshCw className="w-3.5 h-3.5" />}
          Refresh
        </button>
      </div>

      {!loading && apps.length > 0 && (
        <div className="grid grid-cols-2 gap-3">
          <div className="gradient-border p-3">
            <p className="text-xs text-muted-foreground">Server Running</p>
            <p className="text-xl font-bold text-success">{onlineCount}</p>
          </div>
          <div className="gradient-border p-3">
            <p className="text-xs text-muted-foreground">Server Stopped</p>
            <p className="text-xl font-bold text-destructive">{offlineApps.length}</p>
          </div>
        </div>
      )}
      <p className="text-[11px] text-muted-foreground -mt-1">
        This reflects the server process only, not whether it's actually connected to WhatsApp.
      </p>

      {checkingStatus && (
        <div className="flex items-center gap-2 text-xs text-muted-foreground">
          <Loader2 className="w-3.5 h-3.5 animate-spin" />
          Checking live status... ({checkedCount} checked)
        </div>
      )}

      {error && (
        <div className="flex items-center gap-2 px-3 py-2.5 rounded-xl bg-destructive/10 border border-destructive/40 text-destructive text-xs">
          <AlertCircle className="w-4 h-4 shrink-0" />
          {error}
        </div>
      )}

      {loading && (
        <div className="flex items-center justify-center gap-2 py-16 text-muted-foreground text-sm">
          <Loader2 className="w-4 h-4 animate-spin" />
          Checking every bot's status on Heroku...
        </div>
      )}

      {!loading && apps.length === 0 && (
        <p className="text-sm text-muted-foreground text-center py-10">No deployed bots found.</p>
      )}

      {!loading && !checkingStatus && offlineApps.length > 0 && (
        <div className="flex items-center gap-2">
          <button
            onClick={selectAllOffline}
            className="text-xs px-3 py-1.5 rounded-lg border border-border/60 text-muted-foreground hover:text-foreground transition-colors"
          >
            Select all offline ({offlineApps.length})
          </button>
          {selected.size > 0 && (
            <button
              onClick={() => setConfirmOpen(true)}
              className="flex items-center gap-1.5 text-xs px-3 py-1.5 rounded-lg bg-destructive/15 text-destructive font-semibold hover:bg-destructive/25 transition-colors"
            >
              <Trash2 className="w-3.5 h-3.5" />
              Delete {selected.size} selected
            </button>
          )}
        </div>
      )}

      <div className="space-y-2">
        {apps.map((app) => {
          const isStillChecking = app.status === 'live' && app.state === 'unknown';
          const isOffline = !isStillChecking && (app.status === 'failed' || app.state === 'down' || (app.status !== 'live' && app.state !== 'up'));
          return (
            <div key={app.id} className="gradient-border p-3 flex items-center gap-3">
              <input
                type="checkbox"
                checked={selected.has(app.heroku_app_name)}
                onChange={() => toggleSelect(app.heroku_app_name)}
                className="shrink-0 w-4 h-4"
              />
              <div className="min-w-0 flex-1">
                <p className="text-sm font-medium text-foreground truncate">{app.bot_name || app.heroku_app_name}</p>
                <p className="text-[11px] text-muted-foreground font-mono truncate">{app.heroku_app_name}</p>
              </div>
              {isStillChecking ? (
                <span className="shrink-0 flex items-center gap-1 text-[11px] text-muted-foreground">
                  <Loader2 className="w-3.5 h-3.5 animate-spin" />
                  Checking
                </span>
              ) : (
                <span className={`shrink-0 flex items-center gap-1 text-[11px] font-semibold ${isOffline ? 'text-destructive' : 'text-success'}`}>
                  {isOffline ? <XCircle className="w-3.5 h-3.5" /> : <CheckCircle2 className="w-3.5 h-3.5" />}
                  {isOffline ? 'Server Stopped' : 'Server Running'}
                </span>
              )}
            </div>
          );
        })}
      </div>

      {confirmOpen && (
        <div
          className="fixed inset-0 z-[60] flex items-center justify-center bg-background/80 backdrop-blur-sm px-4"
          onClick={() => setConfirmOpen(false)}
        >
          <div className="w-full max-w-sm gradient-border p-6" onClick={(e) => e.stopPropagation()}>
            <p className="font-semibold text-foreground mb-2">Delete {selected.size} bot(s)?</p>
            <p className="text-sm text-muted-foreground mb-5">
              This permanently deletes each app on Heroku and removes its record from the database. This cannot be undone.
            </p>
            <div className="flex gap-2">
              <button
                onClick={handleBulkDelete}
                disabled={deleting}
                className="flex-1 flex items-center justify-center gap-2 py-2.5 rounded-xl bg-destructive text-destructive-foreground text-sm font-semibold hover:opacity-90 transition-opacity disabled:opacity-50"
              >
                {deleting ? <Loader2 className="w-4 h-4 animate-spin" /> : <Trash2 className="w-4 h-4" />}
                Delete
              </button>
              <button
                onClick={() => setConfirmOpen(false)}
                className="px-4 py-2.5 rounded-xl border border-border/50 text-muted-foreground text-sm hover:text-foreground transition-colors"
              >
                Cancel
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default AdminBotDeployments;
