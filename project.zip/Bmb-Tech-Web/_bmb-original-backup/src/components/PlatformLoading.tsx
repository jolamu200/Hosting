import { useEffect, useState } from 'react';
import { TrendingUp } from 'lucide-react';
import profileImage from '@/assets/profile.jpg';

interface Props {
  onDone: () => void;
}

const STEPS = ['Connect', 'Load', 'Ready'] as const;

const PlatformLoading = ({ onDone }: Props) => {
  const [stepIndex, setStepIndex] = useState(0);

  useEffect(() => {
    const stepTimer1 = setTimeout(() => setStepIndex(1), 1000);
    const stepTimer2 = setTimeout(() => setStepIndex(2), 2000);
    const doneTimer = setTimeout(onDone, 3000);

    return () => {
      clearTimeout(stepTimer1);
      clearTimeout(stepTimer2);
      clearTimeout(doneTimer);
    };
  }, [onDone]);

  return (
    <div className="min-h-screen bg-background text-foreground flex items-center justify-center px-4">
      <div className="flex flex-col items-center text-center">
        {/* Animated ring icon */}
        <div className="relative w-28 h-28 mb-6">
          <div className="absolute inset-0 rounded-full border-2 border-transparent bg-gradient-to-r from-primary via-secondary to-primary bg-[length:200%_200%] animate-[spin_2s_linear_infinite]" style={{ padding: '2px' }}>
            <div className="w-full h-full rounded-full bg-background" />
          </div>
          <div className="absolute inset-3 rounded-2xl bg-card border border-primary/30 flex items-center justify-center">
            <img src={profileImage} alt="Bmb Tech" className="w-9 h-9 rounded-lg object-cover" />
          </div>
        </div>

        <div className="flex items-center gap-2 mb-2">
          <h1 className="text-xl font-bold text-transparent bg-clip-text bg-gradient-to-r from-primary to-secondary">
            Bmb Tech
          </h1>
          <span className="px-2 py-0.5 rounded-full bg-secondary/15 border border-secondary/40 text-[10px] font-bold text-secondary tracking-wide">
            CLOUD
          </span>
        </div>

        <p className="text-sm text-muted-foreground mb-6">Initializing platform...</p>

        {/* Progress bar */}
        <div className="w-64 h-1 rounded-full bg-muted/40 overflow-hidden mb-4">
          <div
            className="h-full bg-gradient-to-r from-primary to-secondary transition-all duration-700 ease-out"
            style={{ width: `${((stepIndex + 1) / STEPS.length) * 100}%` }}
          />
        </div>

        {/* Steps */}
        <div className="flex items-center gap-6">
          {STEPS.map((label, i) => (
            <div key={label} className="flex items-center gap-1.5">
              <span
                className={`w-1.5 h-1.5 rounded-full transition-colors ${
                  i <= stepIndex ? 'bg-primary' : 'bg-muted-foreground/30'
                }`}
              />
              <span
                className={`text-xs font-medium transition-colors ${
                  i <= stepIndex ? 'text-foreground' : 'text-muted-foreground/50'
                }`}
              >
                {label}
              </span>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default PlatformLoading;
