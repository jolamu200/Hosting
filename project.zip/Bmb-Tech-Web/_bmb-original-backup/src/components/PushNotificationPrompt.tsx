import { useEffect, useState } from 'react';
import { Bell, X } from 'lucide-react';
import { useAuth } from '@/context/AuthContext';

// Set once VAPID keys are generated — see push_subscriptions.sql for the
// server-side setup. This is the PUBLIC key only (safe to ship to the
// browser); the private key stays server-side as an env var.
const VAPID_PUBLIC_KEY = import.meta.env.VITE_VAPID_PUBLIC_KEY || '';

function urlBase64ToUint8Array(base64String: string) {
  const padding = '='.repeat((4 - (base64String.length % 4)) % 4);
  const base64 = (base64String + padding).replace(/-/g, '+').replace(/_/g, '/');
  const rawData = atob(base64);
  return Uint8Array.from([...rawData].map((c) => c.charCodeAt(0)));
}

const DISMISSED_KEY = 'bmb_push_prompt_dismissed';

const PushNotificationPrompt = () => {
  const { user } = useAuth();
  const [visible, setVisible] = useState(false);
  const [subscribing, setSubscribing] = useState(false);

  const registerSubscription = async (uid: string) => {
    const registration = await navigator.serviceWorker.ready;

    // pushManager.subscribe() is idempotent — if a subscription already
    // exists for this browser it just returns it, so it's safe to call
    // this every time the app loads rather than only once.
    const subscription = await registration.pushManager.subscribe({
      userVisibleOnly: true,
      applicationServerKey: urlBase64ToUint8Array(VAPID_PUBLIC_KEY),
    });

    const res = await fetch('/api/push-notifications?step=subscribe', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ userId: uid, subscription: subscription.toJSON() }),
    });

    if (!res.ok) {
      const body = await res.json().catch(() => ({}));
      console.error('Push subscribe failed:', body?.error || res.status);
    }
  };

  useEffect(() => {
    if (!user) return;
    if (!VAPID_PUBLIC_KEY) return;
    if (!('serviceWorker' in navigator) || !('PushManager' in window)) return;

    // Permission was granted some other way — e.g. the person allowed it
    // from the browser's own site-settings page instead of tapping "Turn
    // on notifications" here. Our subscribe step never ran in that case,
    // so this device was never actually registered to receive anything.
    // Re-run it silently (no modal) whenever the app loads with permission
    // already granted, so it self-heals instead of staying broken forever.
    if (Notification.permission === 'granted') {
      registerSubscription(user.id).catch((err) =>
        console.error('Push auto-subscribe failed:', err)
      );
      return;
    }

    // Already decided some other way (denied at the OS level, or dismissed
    // the in-app prompt before) — don't ask again.
    if (Notification.permission !== 'default') return;
    if (localStorage.getItem(DISMISSED_KEY)) return;

    const timer = setTimeout(() => setVisible(true), 1500);
    return () => clearTimeout(timer);
  }, [user]);

  const handleEnable = async () => {
    if (!user) return;
    setSubscribing(true);

    try {
      const permission = await Notification.requestPermission();

      if (permission !== 'granted') {
        setVisible(false);
        setSubscribing(false);
        return;
      }

      await registerSubscription(user.id);
    } catch (err) {
      // Best-effort — if this fails, the prompt just won't reappear until
      // permission state changes, same as a normal browser dismiss. Still
      // log it so it shows up in the console instead of vanishing silently.
      console.error('Push enable failed:', err);
    }

    setVisible(false);
    setSubscribing(false);
  };

  const handleDismiss = () => {
    localStorage.setItem(DISMISSED_KEY, '1');
    setVisible(false);
  };

  if (!visible) return null;

  return (
    <div className="fixed inset-0 z-[70] flex items-center justify-center bg-background/80 backdrop-blur-sm px-4">
      <div className="relative w-full max-w-sm gradient-border p-6 text-center">
        <button
          onClick={handleDismiss}
          className="absolute top-4 right-4 w-7 h-7 rounded-full flex items-center justify-center bg-muted/40 text-muted-foreground hover:text-foreground transition-colors"
        >
          <X className="w-4 h-4" />
        </button>

        <div className="w-14 h-14 rounded-2xl bg-gradient-to-br from-primary to-secondary flex items-center justify-center mx-auto mb-4">
          <Bell className="w-7 h-7 text-primary-foreground" />
        </div>

        <h2 className="text-lg font-bold text-foreground mb-2">Stay in the loop</h2>
        <p className="text-sm text-muted-foreground mb-4">
          Turn on notifications to know the moment there's a new community message or an important update — right
          on your device.
        </p>
        <p className="text-xs text-muted-foreground mb-5">You can turn this off anytime in Settings</p>

        <button
          onClick={handleEnable}
          disabled={subscribing}
          className="w-full py-3 rounded-xl bg-gradient-to-r from-primary to-secondary text-primary-foreground text-sm font-bold hover:opacity-90 transition-opacity disabled:opacity-60 mb-2"
        >
          {subscribing ? 'Enabling...' : 'Turn on notifications'}
        </button>
        <button onClick={handleDismiss} className="text-sm text-muted-foreground hover:text-foreground transition-colors">
          Not now
        </button>
      </div>
    </div>
  );
};

export default PushNotificationPrompt;
