import { useEffect, useState } from 'react';
import { Lock, AlertCircle, CheckCircle2, X, Github, ShieldAlert, Rocket } from 'lucide-react';
import { supabase } from '@/lib/supabaseClient';
import { useAuth } from '@/context/AuthContext';

const SecurityTab = () => {
  const { user } = useAuth();
  const [showForm, setShowForm] = useState(false);
  const [newPassword, setNewPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');

  // Users who only ever signed in via Google/GitHub have no password to change.
  const hasPasswordAuth = user?.app_metadata?.provider === 'email' ||
    user?.identities?.some(i => i.provider === 'email');

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setSuccess('');

    if (newPassword.length < 6) {
      setError('Password must be at least 6 characters.');
      return;
    }
    if (newPassword !== confirmPassword) {
      setError('Passwords do not match.');
      return;
    }

    setSaving(true);
    const { error: updateError } = await supabase.auth.updateUser({ password: newPassword });
    setSaving(false);

    if (updateError) {
      setError(updateError.message);
      return;
    }

    setSuccess('Password updated successfully.');
    setNewPassword('');
    setConfirmPassword('');
    setTimeout(() => { setShowForm(false); setSuccess(''); }, 2000);
  };

  // Full GitHub OAuth connection for this account — distinct from removing
  // a single deployed bot/repo, which only unlinks that one repo and
  // leaves the GitHub sign-in itself in place.
  const githubIdentity = user?.identities?.find(i => i.provider === 'github');
  const githubUsername =
    (githubIdentity?.identity_data?.user_name as string | undefined) ||
    (githubIdentity?.identity_data?.preferred_username as string | undefined) ||
    (githubIdentity?.identity_data?.full_name as string | undefined) ||
    'your GitHub account';

  const [disconnecting, setDisconnecting] = useState(false);
  const [confirmDisconnect, setConfirmDisconnect] = useState(false);
  const [githubError, setGithubError] = useState('');
  const [reauthorizing, setReauthorizing] = useState(false);

  const handleRevokeGithub = async () => {
    if (!githubIdentity) return;
    setDisconnecting(true);
    setGithubError('');

    const { error: unlinkError } = await supabase.auth.unlinkIdentity(githubIdentity);

    setDisconnecting(false);
    setConfirmDisconnect(false);

    if (unlinkError) {
      setGithubError(
        unlinkError.message.includes('last identity')
          ? 'This is your only sign-in method — add a password or another provider before disconnecting GitHub.'
          : unlinkError.message
      );
    }
  };

  // Re-runs the GitHub OAuth handshake without unlinking first — useful
  // when GitHub-side permissions changed (e.g. new org access) and the
  // stored token needs refreshing, same idea as Heroku's "Re-authorize".
  const handleReauthorizeGithub = async () => {
    setReauthorizing(true);
    setGithubError('');
    const { error: linkError } = await supabase.auth.linkIdentity({
      provider: 'github',
      options: { redirectTo: window.location.origin + '/profile' },
    });
    setReauthorizing(false);
    if (linkError) setGithubError(linkError.message);
  };

  // The GitHub connection used for Auto Deploy (picking a repo to deploy a
  // bot from) is a SEPARATE thing from "Sign in with GitHub" above — it's
  // its own GitHub App authorization, stored in github_connections, and
  // most people set it up from a bot's Settings page without ever using
  // GitHub as their sign-in method at all. That's why this account can
  // have this connection without a githubIdentity existing above.
  const [autoDeployConnection, setAutoDeployConnection] = useState<{ github_login: string } | null>(null);
  const [loadingAutoDeploy, setLoadingAutoDeploy] = useState(true);
  const [disconnectingAutoDeploy, setDisconnectingAutoDeploy] = useState(false);
  const [confirmDisconnectAutoDeploy, setConfirmDisconnectAutoDeploy] = useState(false);
  const [autoDeployError, setAutoDeployError] = useState('');

  useEffect(() => {
    if (!user) return;
    supabase
      .from('github_connections')
      .select('github_login')
      .eq('user_id', user.id)
      .maybeSingle()
      .then(({ data }) => {
        setAutoDeployConnection(data || null);
        setLoadingAutoDeploy(false);
      });
  }, [user]);

  const handleDisconnectAutoDeploy = async () => {
    if (!user) return;
    setDisconnectingAutoDeploy(true);
    setAutoDeployError('');
    try {
      const res = await fetch('/api/github-auto-deploy?step=disconnect-account', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ userId: user.id }),
      });
      if (res.ok) {
        setAutoDeployConnection(null);
      } else {
        const data = await res.json().catch(() => ({}));
        setAutoDeployError(data?.error || 'Could not disconnect.');
      }
    } catch (err: any) {
      setAutoDeployError(err?.message || 'Could not disconnect.');
    }
    setDisconnectingAutoDeploy(false);
    setConfirmDisconnectAutoDeploy(false);
  };

  return (
    <div className="space-y-4">
      <div className="gradient-border p-6">
        <h2 className="text-lg font-bold text-foreground mb-1">Account Security</h2>
        <p className="text-xs text-muted-foreground mb-5">Keep your account safe with a strong password</p>

      {!hasPasswordAuth && (
        <div className="flex items-center gap-2 px-3 py-2.5 rounded-xl bg-muted/30 border border-border/40 text-muted-foreground text-xs mb-4">
          <AlertCircle className="w-4 h-4 shrink-0" />
          You signed in with Google or GitHub, so there's no password to change here.
        </div>
      )}

      {!showForm ? (
        <button
          onClick={() => setShowForm(true)}
          disabled={!hasPasswordAuth}
          className="flex items-center gap-2 px-5 py-3 rounded-xl border border-border/60 text-foreground text-sm font-medium hover:bg-muted/40 transition-colors disabled:opacity-40 disabled:cursor-not-allowed"
        >
          <Lock className="w-4 h-4 text-primary" />
          Change Password
        </button>
      ) : (
        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="flex items-center justify-between">
            <p className="text-sm font-semibold text-foreground">New Password</p>
            <button type="button" onClick={() => setShowForm(false)} className="text-muted-foreground hover:text-foreground">
              <X className="w-4 h-4" />
            </button>
          </div>

          {error && (
            <div className="flex items-center gap-2 px-3 py-2.5 rounded-xl bg-destructive/10 border border-destructive/40 text-destructive text-xs">
              <AlertCircle className="w-4 h-4 shrink-0" />
              {error}
            </div>
          )}
          {success && (
            <div className="flex items-center gap-2 px-3 py-2.5 rounded-xl bg-success/10 border border-success/40 text-success text-xs">
              <CheckCircle2 className="w-4 h-4 shrink-0" />
              {success}
            </div>
          )}

          <input
            type="password"
            required
            minLength={6}
            placeholder="New password"
            value={newPassword}
            onChange={(e) => setNewPassword(e.target.value)}
            className="w-full px-4 py-3 rounded-xl bg-background/50 border border-border/60 text-foreground text-sm placeholder:text-muted-foreground focus:outline-none focus:border-primary/60 transition-colors"
          />
          <input
            type="password"
            required
            minLength={6}
            placeholder="Confirm new password"
            value={confirmPassword}
            onChange={(e) => setConfirmPassword(e.target.value)}
            className="w-full px-4 py-3 rounded-xl bg-background/50 border border-border/60 text-foreground text-sm placeholder:text-muted-foreground focus:outline-none focus:border-primary/60 transition-colors"
          />

          <button
            type="submit"
            disabled={saving}
            className="w-full py-3 rounded-xl bg-gradient-to-r from-primary to-secondary text-primary-foreground text-sm font-bold hover:opacity-90 transition-opacity disabled:opacity-60"
          >
            {saving ? 'Updating...' : 'Update Password'}
          </button>
        </form>
        )}
      </div>

      {/* Third-party Services — same idea as Heroku's Manage Account page:
          shows what external accounts are linked, with a way to refresh
          the connection (Re-authorize) or remove it (Revoke access).
          These are two independent GitHub connections, so either, both,
          or neither may show depending on what this account has set up. */}
      {(githubIdentity || autoDeployConnection) && (
        <div className="gradient-border p-6">
          <h2 className="text-lg font-bold text-foreground mb-1">Third-party Services</h2>
          <p className="text-xs text-muted-foreground mb-5">
            External accounts connected to your Bmb Hosting account.
          </p>

          <div className="space-y-3">
            {githubIdentity && (
              <>
                {githubError && (
                  <div className="flex items-center gap-2 px-3 py-2.5 rounded-xl bg-destructive/10 border border-destructive/40 text-destructive text-xs">
                    <AlertCircle className="w-4 h-4 shrink-0" />
                    {githubError}
                  </div>
                )}
                <div className="flex items-start gap-3 p-4 rounded-xl border border-border/50">
                  <div className="w-10 h-10 rounded-full bg-foreground/10 flex items-center justify-center shrink-0">
                    <Github className="w-5 h-5 text-foreground" />
                  </div>
                  <div className="min-w-0 flex-1">
                    <p className="text-sm font-semibold text-foreground">GitHub OAuth</p>
                    <p className="text-[11px] text-muted-foreground mb-0.5">Used to sign in to your account</p>
                    <p className="text-xs text-muted-foreground truncate">
                      Connected as <span className="text-primary">@{githubUsername}</span>
                    </p>

                    <div className="flex items-center gap-2 mt-3">
                      <button
                        onClick={handleReauthorizeGithub}
                        disabled={reauthorizing}
                        className="px-3 py-2 rounded-lg border border-border/60 text-foreground text-xs font-semibold hover:bg-muted/40 transition-colors disabled:opacity-50"
                      >
                        {reauthorizing ? 'Redirecting...' : 'Re-authorize'}
                      </button>

                      {!confirmDisconnect ? (
                        <button
                          onClick={() => setConfirmDisconnect(true)}
                          className="px-3 py-2 rounded-lg border border-destructive/40 text-destructive text-xs font-semibold hover:bg-destructive/10 transition-colors"
                        >
                          Revoke access...
                        </button>
                      ) : (
                        <div className="flex items-center gap-1.5">
                          <button
                            onClick={() => setConfirmDisconnect(false)}
                            className="px-2.5 py-2 rounded-lg border border-border/50 text-muted-foreground text-xs"
                          >
                            Cancel
                          </button>
                          <button
                            onClick={handleRevokeGithub}
                            disabled={disconnecting}
                            className="px-2.5 py-2 rounded-lg bg-destructive text-white text-xs font-semibold disabled:opacity-60"
                          >
                            {disconnecting ? 'Revoking...' : 'Confirm'}
                          </button>
                        </div>
                      )}
                    </div>
                  </div>
                </div>
              </>
            )}

            {autoDeployConnection && (
              <>
                {autoDeployError && (
                  <div className="flex items-center gap-2 px-3 py-2.5 rounded-xl bg-destructive/10 border border-destructive/40 text-destructive text-xs">
                    <AlertCircle className="w-4 h-4 shrink-0" />
                    {autoDeployError}
                  </div>
                )}
                <div className="flex items-start gap-3 p-4 rounded-xl border border-border/50">
                  <div className="w-10 h-10 rounded-full bg-foreground/10 flex items-center justify-center shrink-0">
                    <Rocket className="w-5 h-5 text-foreground" />
                  </div>
                  <div className="min-w-0 flex-1">
                    <p className="text-sm font-semibold text-foreground">GitHub (Auto Deploy)</p>
                    <p className="text-[11px] text-muted-foreground mb-0.5">Used to deploy bots from your repos</p>
                    <p className="text-xs text-muted-foreground truncate">
                      Connected as <span className="text-primary">@{autoDeployConnection.github_login}</span>
                    </p>

                    <div className="flex items-center gap-2 mt-3">
                      {!confirmDisconnectAutoDeploy ? (
                        <button
                          onClick={() => setConfirmDisconnectAutoDeploy(true)}
                          className="px-3 py-2 rounded-lg border border-destructive/40 text-destructive text-xs font-semibold hover:bg-destructive/10 transition-colors"
                        >
                          Disconnect...
                        </button>
                      ) : (
                        <div className="flex items-center gap-1.5">
                          <button
                            onClick={() => setConfirmDisconnectAutoDeploy(false)}
                            className="px-2.5 py-2 rounded-lg border border-border/50 text-muted-foreground text-xs"
                          >
                            Cancel
                          </button>
                          <button
                            onClick={handleDisconnectAutoDeploy}
                            disabled={disconnectingAutoDeploy}
                            className="px-2.5 py-2 rounded-lg bg-destructive text-white text-xs font-semibold disabled:opacity-60"
                          >
                            {disconnectingAutoDeploy ? 'Disconnecting...' : 'Confirm'}
                          </button>
                        </div>
                      )}
                    </div>
                  </div>
                </div>
              </>
            )}
          </div>

          <p className="flex items-start gap-1.5 text-[11px] text-muted-foreground mt-3">
            <ShieldAlert className="w-3.5 h-3.5 shrink-0 mt-0.5" />
            Disconnecting either one only affects that connection. To remove just one deployed
            bot's repo access instead of the whole connection, do that from the bot's own settings.
          </p>
        </div>
      )}
    </div>
  );
};

export default SecurityTab;
