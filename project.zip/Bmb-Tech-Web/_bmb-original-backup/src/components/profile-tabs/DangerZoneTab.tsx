import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { AlertTriangle, LogOut, X, AlertCircle } from 'lucide-react';
import { supabase } from '@/lib/supabaseClient';
import { useAuth } from '@/context/AuthContext';

const DangerZoneTab = () => {
  const { user, session } = useAuth();
  const navigate = useNavigate();
  const [showConfirm, setShowConfirm] = useState(false);
  const [confirmText, setConfirmText] = useState('');
  const [deleting, setDeleting] = useState(false);
  const [error, setError] = useState('');

  const handleSignOut = async () => {
    await supabase.auth.signOut();
    navigate('/');
  };

  const handleDeleteAccount = async () => {
    if (confirmText !== 'DELETE' || !user || !session) return;

    setError('');
    setDeleting(true);

    try {
      const res = await fetch('/api/delete-account', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${session.access_token}`,
        },
        body: JSON.stringify({ userId: user.id }),
      });
      const data = await res.json();

      if (!res.ok) {
        setError(data.error || 'Failed to delete account.');
        setDeleting(false);
        return;
      }

      await supabase.auth.signOut();
      navigate('/');
    } catch (err: any) {
      setError(err.message || 'Failed to delete account.');
      setDeleting(false);
    }
  };

  return (
    <div className="gradient-border p-6 border-destructive/40">
      <h2 className="text-lg font-bold text-destructive mb-1">Danger Zone</h2>
      <p className="text-xs text-muted-foreground mb-5">Irreversible and destructive actions</p>

      <div className="space-y-4">
        {/* Delete Account */}
        <div className="p-4 rounded-xl bg-destructive/5 border border-destructive/30">
          <p className="text-sm font-semibold text-destructive mb-1">Delete Account</p>
          <p className="text-xs text-muted-foreground mb-3">Permanently removes your account and all data</p>

          {!showConfirm ? (
            <button
              onClick={() => setShowConfirm(true)}
              className="flex items-center gap-2 px-4 py-2.5 rounded-xl bg-destructive text-white text-sm font-semibold hover:opacity-90 transition-opacity"
            >
              <AlertTriangle className="w-4 h-4" />
              Delete Account
            </button>
          ) : (
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <p className="text-xs text-foreground">
                  Type <span className="font-mono font-bold">DELETE</span> to confirm
                </p>
                <button onClick={() => { setShowConfirm(false); setConfirmText(''); setError(''); }} className="text-muted-foreground hover:text-foreground">
                  <X className="w-4 h-4" />
                </button>
              </div>

              {error && (
                <div className="flex items-center gap-2 px-3 py-2 rounded-xl bg-destructive/10 border border-destructive/40 text-destructive text-xs">
                  <AlertCircle className="w-4 h-4 shrink-0" />
                  {error}
                </div>
              )}

              <input
                type="text"
                value={confirmText}
                onChange={(e) => setConfirmText(e.target.value)}
                placeholder="DELETE"
                className="w-full px-4 py-2.5 rounded-xl bg-background/50 border border-destructive/40 text-foreground text-sm font-mono focus:outline-none focus:border-destructive/70 transition-colors"
              />

              <button
                onClick={handleDeleteAccount}
                disabled={confirmText !== 'DELETE' || deleting}
                className="w-full py-2.5 rounded-xl bg-destructive text-white text-sm font-semibold hover:opacity-90 transition-opacity disabled:opacity-40"
              >
                {deleting ? 'Deleting...' : 'Permanently Delete My Account'}
              </button>
            </div>
          )}
        </div>

        {/* Sign Out */}
        <div className="p-4 rounded-xl bg-background/40 border border-border/40">
          <p className="text-sm font-semibold text-foreground mb-1">Sign Out</p>
          <p className="text-xs text-muted-foreground mb-3">Sign out from your current session</p>
          <button
            onClick={handleSignOut}
            className="flex items-center gap-2 px-4 py-2.5 rounded-xl border border-border/60 text-foreground text-sm font-medium hover:bg-muted/40 transition-colors"
          >
            <LogOut className="w-4 h-4" />
            Sign Out
          </button>
        </div>
      </div>
    </div>
  );
};

export default DangerZoneTab;
