import { useState } from 'react';
import { AlertCircle, CheckCircle2, Save, Copy, Check } from 'lucide-react';
import { supabase } from '@/lib/supabaseClient';
import { useAuth } from '@/context/AuthContext';

interface ProfileData {
  full_name: string;
  username: string;
  phone: string;
  avatar_url: string | null;
  ph_balance: number;
  referral_code: string | null;
  created_at?: string;
}

interface Props {
  profile: ProfileData;
  setProfile: React.Dispatch<React.SetStateAction<ProfileData>>;
}

const ProfileInfoTab = ({ profile, setProfile }: Props) => {
  const { user } = useAuth();
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');
  const [copied, setCopied] = useState(false);

  const referralLink = profile.referral_code
    ? `${window.location.origin}/signup?ref=${profile.referral_code}`
    : '';

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!user) return;

    setError('');
    setSuccess('');
    setSaving(true);

    const { error: saveError } = await supabase.from('profiles').upsert({
      id: user.id,
      full_name: profile.full_name,
      username: profile.username,
      phone: profile.phone,
      avatar_url: profile.avatar_url,
      updated_at: new Date().toISOString(),
    });

    setSaving(false);

    if (saveError) {
      setError('Failed to save: ' + saveError.message);
    } else {
      setSuccess('Profile updated successfully.');
      setTimeout(() => setSuccess(''), 3000);
    }
  };

  const handleCopyReferral = () => {
    if (!referralLink) return;
    navigator.clipboard.writeText(referralLink).then(() => {
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    });
  };

  return (
    <div className="gradient-border p-6">
      <h2 className="text-lg font-bold text-foreground mb-1">Profile Information</h2>
      <p className="text-xs text-muted-foreground mb-5">Username and email are not editable</p>

      {error && (
        <div className="flex items-center gap-2 px-3 py-2.5 rounded-xl bg-destructive/10 border border-destructive/40 text-destructive text-xs mb-4">
          <AlertCircle className="w-4 h-4 shrink-0" />
          {error}
        </div>
      )}
      {success && (
        <div className="flex items-center gap-2 px-3 py-2.5 rounded-xl bg-success/10 border border-success/40 text-success text-xs mb-4">
          <CheckCircle2 className="w-4 h-4 shrink-0" />
          {success}
        </div>
      )}

      <form onSubmit={handleSave} className="space-y-4">
        <div>
          <label className="text-xs font-semibold text-muted-foreground tracking-wide uppercase mb-1.5 block">
            Username
          </label>
          <input
            type="text"
            value={profile.username}
            disabled
            className="w-full px-4 py-3 rounded-xl bg-background/30 border border-border/40 text-muted-foreground text-sm cursor-not-allowed"
          />
        </div>

        <div>
          <label className="text-xs font-semibold text-muted-foreground tracking-wide uppercase mb-1.5 block">
            Email
          </label>
          <input
            type="email"
            value={user?.email || ''}
            disabled
            className="w-full px-4 py-3 rounded-xl bg-background/30 border border-border/40 text-muted-foreground text-sm cursor-not-allowed"
          />
        </div>

        <div>
          <label className="text-xs font-semibold text-muted-foreground tracking-wide uppercase mb-1.5 block">
            Display Name
          </label>
          <input
            type="text"
            value={profile.full_name}
            onChange={(e) => setProfile(prev => ({ ...prev, full_name: e.target.value }))}
            placeholder="Your display name"
            className="w-full px-4 py-3 rounded-xl bg-background/50 border border-border/60 text-foreground text-sm placeholder:text-muted-foreground focus:outline-none focus:border-primary/60 transition-colors"
          />
        </div>

        <div>
          <label className="text-xs font-semibold text-muted-foreground tracking-wide uppercase mb-1.5 block">
            Phone Number
          </label>
          <input
            type="tel"
            value={profile.phone}
            onChange={(e) => setProfile(prev => ({ ...prev, phone: e.target.value }))}
            placeholder="+255..."
            className="w-full px-4 py-3 rounded-xl bg-background/50 border border-border/60 text-foreground text-sm placeholder:text-muted-foreground focus:outline-none focus:border-primary/60 transition-colors"
          />
        </div>

        {referralLink && (
          <div>
            <label className="text-xs font-semibold text-muted-foreground tracking-wide uppercase mb-1.5 block">
              Referral Link
            </label>
            <div className="flex items-center gap-2">
              <input
                type="text"
                value={referralLink}
                readOnly
                className="flex-1 px-4 py-3 rounded-xl bg-background/30 border border-border/40 text-muted-foreground text-xs font-mono truncate"
              />
              <button
                type="button"
                onClick={handleCopyReferral}
                className="shrink-0 w-11 h-11 rounded-xl border border-border/50 flex items-center justify-center text-muted-foreground hover:text-foreground hover:bg-muted/40 transition-colors"
              >
                {copied ? <Check className="w-4 h-4 text-success" /> : <Copy className="w-4 h-4" />}
              </button>
            </div>
          </div>
        )}

        <button
          type="submit"
          disabled={saving}
          className="w-full flex items-center justify-center gap-2 py-3.5 rounded-xl bg-gradient-to-r from-primary to-secondary text-primary-foreground font-bold tracking-wide hover:opacity-90 transition-opacity disabled:opacity-60 mt-2"
        >
          {saving ? 'Saving...' : 'Save Changes'}
          <Save className="w-4 h-4" />
        </button>
      </form>
    </div>
  );
};

export default ProfileInfoTab;
