import { useTheme } from 'next-themes';
import { Moon, Globe } from 'lucide-react';
import { useLanguage } from '@/context/LanguageContext';

const AppearanceTab = () => {
  const { theme, setTheme } = useTheme();
  const { language, setLanguage } = useLanguage();
  const isDark = theme !== 'light';

  return (
    <div className="gradient-border p-6">
      <h2 className="text-lg font-bold text-foreground mb-1">Appearance</h2>
      <p className="text-xs text-muted-foreground mb-5">Customize how the app looks</p>

      <div className="space-y-3">
        {/* Dark Mode */}
        <div className="flex items-center justify-between gap-3 p-4 rounded-xl bg-background/40 border border-border/40">
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-lg bg-primary/10 flex items-center justify-center shrink-0">
              <Moon className="w-4 h-4 text-primary" />
            </div>
            <div>
              <p className="text-sm font-medium text-foreground">Dark Mode</p>
              <p className="text-xs text-muted-foreground">Using {isDark ? 'dark' : 'light'} theme</p>
            </div>
          </div>
          <button
            onClick={() => setTheme(isDark ? 'light' : 'dark')}
            className={`shrink-0 w-12 h-7 rounded-full flex items-center px-1 transition-colors ${
              isDark ? 'bg-primary justify-end' : 'bg-muted justify-start'
            }`}
            aria-label="Toggle dark mode"
          >
            <span className="w-5 h-5 rounded-full bg-white block" />
          </button>
        </div>

        {/* Language */}
        <div className="flex items-center justify-between gap-3 p-4 rounded-xl bg-background/40 border border-border/40">
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-lg bg-primary/10 flex items-center justify-center shrink-0">
              <Globe className="w-4 h-4 text-primary" />
            </div>
            <div>
              <p className="text-sm font-medium text-foreground">Language</p>
              <p className="text-xs text-muted-foreground">Choose your preferred language</p>
            </div>
          </div>
          <div className="flex items-center gap-1.5 shrink-0">
            <button
              onClick={() => setLanguage('en')}
              className={`px-3 py-1.5 rounded-full text-xs font-semibold transition-colors ${
                language === 'en' ? 'bg-primary text-primary-foreground' : 'bg-muted/50 text-muted-foreground'
              }`}
            >
              EN
            </button>
            <button
              onClick={() => setLanguage('sw')}
              className={`px-3 py-1.5 rounded-full text-xs font-semibold transition-colors ${
                language === 'sw' ? 'bg-primary text-primary-foreground' : 'bg-muted/50 text-muted-foreground'
              }`}
            >
              SW
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default AppearanceTab;
