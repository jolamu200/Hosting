import { useEffect, useState } from 'react';
import { CheckCircle2, XCircle, Loader2, ExternalLink, Eye, Heart, Share2, ChevronRight } from 'lucide-react';
import { supabase } from '@/lib/supabaseClient';
import type { Tool } from '@/data/tools';

interface WebsiteStatusProps {
  tools: Tool[];
}

// Base URL of this site — used to build shareable links for each tool's own page
const SITE_URL = 'https://bmb-tech-web-site.vercel.app';

// Border/glow color themes that rotate per card, matching the reference design
const cardThemes = [
  { border: 'border-secondary/50', glow: 'hover:shadow-[0_0_30px_-5px] hover:shadow-secondary/40', iconBorder: 'border-secondary/60', iconGlow: 'shadow-[0_0_20px_-4px] shadow-secondary/50', text: 'text-secondary' },
  { border: 'border-primary/50', glow: 'hover:shadow-[0_0_30px_-5px] hover:shadow-primary/40', iconBorder: 'border-primary/60', iconGlow: 'shadow-[0_0_20px_-4px] shadow-primary/50', text: 'text-primary' },
];

// Stable id per tool, independent of array position (used as the Supabase row key)
const toolId = (title: string) =>
  title.toLowerCase().trim().replace(/[^a-z0-9]+/g, '-').replace(/(^-|-$)/g, '');

const LIKED_STORAGE_KEY = 'bmb_liked_tools';

const WebsiteStatus = ({ tools }: WebsiteStatusProps) => {
  const [statuses, setStatuses] = useState<Record<string, 'checking' | 'online' | 'offline'>>({});
  const [likes, setLikes] = useState<Record<string, number>>({});
  const [shares, setShares] = useState<Record<string, number>>({});
  const [views, setViews] = useState<Record<string, number>>({});
  const [liked, setLiked] = useState<Record<string, boolean>>({});
  const [pending, setPending] = useState<Record<string, boolean>>({});

  const websites = tools.filter(t => !t.isComingSoon && t.url);

  // Load real like/share counts from Supabase
  useEffect(() => {
    const loadStats = async () => {
      const { data, error } = await supabase
        .from('tool_stats')
        .select('tool_id, likes, shares, views');

      if (error) {
        console.error('Failed to load tool_stats from Supabase:', error.message);
        return;
      }

      const likesMap: Record<string, number> = {};
      const sharesMap: Record<string, number> = {};
      const viewsMap: Record<string, number> = {};
      data?.forEach(row => {
        likesMap[row.tool_id] = row.likes;
        sharesMap[row.tool_id] = row.shares;
        viewsMap[row.tool_id] = row.views;
      });
      setLikes(likesMap);
      setShares(sharesMap);
      setViews(viewsMap);
    };

    loadStats();

    // Remember which tools this browser already liked, so the heart shows filled
    try {
      const saved = localStorage.getItem(LIKED_STORAGE_KEY);
      if (saved) setLiked(JSON.parse(saved));
    } catch {
      // ignore malformed local storage
    }
  }, [tools]);

  useEffect(() => {
    const checkStatuses = async () => {
      const newStatuses: Record<string, 'checking' | 'online' | 'offline'> = {};
      
      for (const site of websites) {
        if (site.url) newStatuses[site.url] = 'checking';
      }
      setStatuses(newStatuses);

      for (const site of websites) {
        if (!site.url) continue;
        try {
          const controller = new AbortController();
          const timeoutId = setTimeout(() => controller.abort(), 5000);
          
          await fetch(site.url, { 
            mode: 'no-cors',
            signal: controller.signal 
          });
          
          clearTimeout(timeoutId);
          newStatuses[site.url] = 'online';
        } catch (error) {
          newStatuses[site.url] = 'online';
        }
        setStatuses({ ...newStatuses });
      }
    };

    checkStatuses();
    const interval = setInterval(checkStatuses, 60000);
    return () => clearInterval(interval);
  }, []);

  const formatCount = (n: number) => {
    if (n >= 1000) return `${(n / 1000).toFixed(1)}K`;
    return n.toString();
  };

  const handleLike = async (id: string) => {
    if (pending[id]) return;
    setPending(prev => ({ ...prev, [id]: true }));

    // Optimistic update
    setLikes(prev => ({ ...prev, [id]: (prev[id] || 0) + 1 }));

    const { data, error } = await supabase.rpc('increment_like', { p_tool_id: id });

    if (error) {
      console.error('Failed to save like:', error.message);
      // Roll back on failure
      setLikes(prev => ({ ...prev, [id]: Math.max(0, (prev[id] || 1) - 1) }));
    } else if (data) {
      setLikes(prev => ({ ...prev, [id]: data.likes }));
      const nextLiked = { ...liked, [id]: true };
      setLiked(nextLiked);
      try {
        localStorage.setItem(LIKED_STORAGE_KEY, JSON.stringify(nextLiked));
      } catch {
        // ignore storage errors (e.g. private browsing)
      }
    }

    setPending(prev => ({ ...prev, [id]: false }));
  };

  const handleLaunch = (id: string) => {
    // Optimistic bump so the count feels instant; the actual navigation
    // happens via the anchor tag itself (href + target="_blank").
    setViews(prev => ({ ...prev, [id]: (prev[id] || 0) + 1 }));
    supabase.rpc('increment_view', { p_tool_id: id }).then(({ data, error }) => {
      if (error) {
        console.error('Failed to save view:', error.message);
      } else if (data) {
        setViews(prev => ({ ...prev, [id]: data.views }));
      }
    });
  };

  const handleShare = async (id: string, tool: Tool) => {
    if (pending[`share-${id}`]) return;

    const shareUrl = tool.slug ? `${SITE_URL}/${tool.slug}` : tool.url;

    // Trigger the actual share action first
    if (navigator.share && shareUrl) {
      try {
        await navigator.share({ title: tool.title, text: tool.description, url: shareUrl });
      } catch {
        // user cancelled the share sheet — still fine to continue
      }
    } else if (shareUrl) {
      try {
        await navigator.clipboard.writeText(shareUrl);
      } catch {
        // clipboard may be unavailable — ignore silently
      }
    }

    setPending(prev => ({ ...prev, [`share-${id}`]: true }));
    setShares(prev => ({ ...prev, [id]: (prev[id] || 0) + 1 }));

    const { data, error } = await supabase.rpc('increment_share', { p_tool_id: id });

    if (error) {
      console.error('Failed to save share:', error.message);
      setShares(prev => ({ ...prev, [id]: Math.max(0, (prev[id] || 1) - 1) }));
    } else if (data) {
      setShares(prev => ({ ...prev, [id]: data.shares }));
    }

    setPending(prev => ({ ...prev, [`share-${id}`]: false }));
  };

  return (
    <section id="tools" className="relative px-4 pt-6 pb-20">
      <div className="max-w-7xl mx-auto">
        <div className="text-center mb-12">
          <p className="text-primary font-mono text-sm mb-2 tracking-widest">&lt;/&gt; TOOLS & STATUS</p>
          <h2 className="text-4xl md:text-5xl font-bold gradient-text mb-4 tracking-wider">
            Our Services
          </h2>
          <div className="flex items-center justify-center gap-2 mt-4">
            <div className="w-2 h-2 rounded-full bg-success animate-pulse" />
            <span className="text-muted-foreground text-sm">All systems operational</span>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {tools.map((tool, index) => {
            const Icon = tool.icon;
            const isComingSoon = tool.isComingSoon;
            const theme = cardThemes[index % cardThemes.length];
            const techList = tool.tech ? tool.tech.split('+').map(t => t.trim()).filter(Boolean) : [];
            const id = toolId(tool.title);

            return (
              <div
                key={index}
                className="group relative animate-slide-up"
                style={{ animationDelay: `${index * 100}ms` }}
              >
                {/* Card Container */}
                <div className={`relative overflow-hidden rounded-2xl border-2 bg-card/40 backdrop-blur-sm transition-all duration-500 p-5 md:p-6 ${!isComingSoon ? `${theme.border} ${theme.glow}` : 'border-border/50 opacity-70'}`}>
                  
                  {/* Top Row: Tech badges + Status */}
                  <div className="flex items-start justify-between gap-2 mb-5 flex-wrap">
                    <div className="flex items-center gap-2 flex-wrap">
                      {techList.map((t, i) => (
                        <span
                          key={i}
                          className="flex items-center gap-1 px-3 py-1.5 rounded-full bg-background/60 border border-primary/30 text-xs font-mono text-primary"
                        >
                          {t}
                          <ChevronRight className="w-3 h-3 opacity-60" />
                        </span>
                      ))}
                    </div>

                    {!isComingSoon && tool.url && (
                      <div className="shrink-0">
                        {statuses[tool.url] === 'checking' && (
                          <div className="flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-background/80 border border-border/50">
                            <Loader2 className="w-3 h-3 text-primary animate-spin" />
                            <span className="text-xs text-muted-foreground">Checking</span>
                          </div>
                        )}
                        {statuses[tool.url] === 'online' && (
                          <div className="flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-success/10 border border-success/40">
                            <CheckCircle2 className="w-3.5 h-3.5 text-success" />
                            <span className="text-xs text-success font-medium">Online</span>
                          </div>
                        )}
                        {statuses[tool.url] === 'offline' && (
                          <div className="flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-destructive/10 border border-destructive/40">
                            <XCircle className="w-3.5 h-3.5 text-destructive" />
                            <span className="text-xs text-destructive font-medium">Offline</span>
                          </div>
                        )}
                      </div>
                    )}

                    {isComingSoon && (
                      <div className="px-3 py-1.5 rounded-full bg-secondary/10 border border-secondary/30">
                        <span className="text-xs text-secondary">Coming Soon</span>
                      </div>
                    )}
                  </div>

                  {/* Main content: icon + title/desc */}
                  <div className="flex items-start gap-5 mb-5">
                    <div className={`shrink-0 w-24 h-24 rounded-2xl border-2 flex items-center justify-center bg-background/30 ${!isComingSoon ? `${theme.iconBorder} ${theme.iconGlow}` : 'border-border/40'}`}>
                      <Icon className={`w-11 h-11 ${!isComingSoon ? theme.text : 'text-muted-foreground'}`} />
                    </div>
                    <div className="flex-1 min-w-0 pt-1">
                      <div className="flex items-center gap-2 mb-1.5">
                        <h3 className="text-xl md:text-2xl font-bold text-foreground tracking-wide">
                          {tool.title}
                        </h3>
                        {tool.isNew && !isComingSoon && (
                          <span className="px-2 py-0.5 rounded-full bg-gradient-to-r from-green-500/20 to-emerald-500/20 border border-green-500/40 text-[10px] font-bold text-green-400 tracking-wider animate-pulse">
                            NEW
                          </span>
                        )}
                      </div>
                      <p className="text-sm text-muted-foreground leading-relaxed">
                        {tool.description}
                      </p>
                    </div>
                  </div>

                  {/* Launch Tool button */}
                  {!isComingSoon && tool.url && (
                    <a
                      href={tool.url}
                      target="_blank"
                      rel="noopener noreferrer"
                      onClick={() => handleLaunch(id)}
                      className="flex items-center justify-center gap-2 w-full py-3 rounded-xl bg-gradient-to-r from-primary to-secondary text-primary-foreground text-sm font-semibold hover:opacity-90 transition-opacity duration-300 mb-3"
                    >
                      Launch Tool
                      <ExternalLink className="w-4 h-4" />
                    </a>
                  )}

                  {/* Views / Like / Share row */}
                  {!isComingSoon && tool.url && (
                    <div className="grid grid-cols-3 gap-2 mb-3">
                      <div className="flex items-center justify-center gap-1.5 py-2.5 rounded-xl border border-primary/30 bg-background/30 text-primary text-xs font-medium">
                        <Eye className="w-3.5 h-3.5" />
                        {formatCount(views[id] || 0)}
                      </div>
                      <button
                        onClick={() => handleLike(id)}
                        disabled={pending[id]}
                        className={`flex items-center justify-center gap-1.5 py-2.5 rounded-xl border text-xs font-medium transition-colors disabled:opacity-60 ${
                          liked[id]
                            ? 'border-red-500/50 bg-red-500/10 text-red-400'
                            : 'border-red-500/30 bg-background/30 text-red-400 hover:bg-red-500/10'
                        }`}
                      >
                        <Heart className={`w-3.5 h-3.5 ${liked[id] ? 'fill-current' : ''}`} />
                        {formatCount(likes[id] || 0)}
                      </button>
                      <button
                        onClick={() => handleShare(id, tool)}
                        disabled={pending[`share-${id}`]}
                        className="flex items-center justify-center gap-1.5 py-2.5 rounded-xl border border-secondary/30 bg-background/30 text-secondary text-xs font-medium hover:bg-secondary/10 transition-colors disabled:opacity-60"
                      >
                        <Share2 className="w-3.5 h-3.5" />
                        {formatCount(shares[id] || 0)}
                      </button>
                    </div>
                  )}

                  {/* URL Display */}
                  {tool.url && (
                    <p className="text-xs text-muted-foreground text-center font-mono truncate">
                      {tool.url.replace('https://', '')}
                    </p>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
};

export default WebsiteStatus;
