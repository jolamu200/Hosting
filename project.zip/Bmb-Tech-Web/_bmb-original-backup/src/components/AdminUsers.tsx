import { useEffect, useState } from 'react';
import { Loader2, Users, Mail, Calendar, Crown, ShieldCheck, Search } from 'lucide-react';
import { supabase } from '@/lib/supabaseClient';

interface UserRow {
  id: string;
  username: string | null;
  full_name: string | null;
  avatar_url: string | null;
  role: string | null;
  created_at: string | null;
  email?: string;
}

const AdminUsers = () => {
  const [users, setUsers] = useState<UserRow[]>([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');

  useEffect(() => {
    const load = async () => {
      const { data } = await supabase
        .from('profiles')
        .select('id, username, full_name, avatar_url, role, updated_at')
        .order('updated_at', { ascending: false });

      setUsers((data as any) || []);
      setLoading(false);
    };
    load();
  }, []);

  const filtered = users.filter((u) => {
    const q = search.toLowerCase();
    return (
      (u.username || '').toLowerCase().includes(q) ||
      (u.full_name || '').toLowerCase().includes(q)
    );
  });

  const formatDate = (iso: string | null) =>
    iso ? new Date(iso).toLocaleDateString('en-US', { day: '2-digit', month: 'short', year: 'numeric' }) : '—';

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between gap-3">
        <h2 className="text-sm font-semibold text-muted-foreground tracking-wide uppercase flex items-center gap-2">
          <Users className="w-4 h-4 text-primary" />
          Registered Users
        </h2>
        <span className="text-xs text-muted-foreground">{filtered.length} total</span>
      </div>

      <div className="relative">
        <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
        <input
          type="text"
          placeholder="Search by username or name..."
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          className="w-full pl-10 pr-4 py-2.5 rounded-xl bg-background/50 border border-border/60 text-foreground text-sm placeholder:text-muted-foreground focus:outline-none focus:border-primary/60 transition-colors"
        />
      </div>

      {loading && (
        <div className="flex items-center justify-center gap-2 py-16 text-muted-foreground text-sm">
          <Loader2 className="w-4 h-4 animate-spin" />
          Loading users...
        </div>
      )}

      {!loading && filtered.length === 0 && (
        <p className="text-sm text-muted-foreground text-center py-16">No users found.</p>
      )}

      <div className="space-y-2">
        {filtered.map((u) => (
          <div key={u.id} className="gradient-border p-4 flex items-center gap-3">
            <div className="w-10 h-10 rounded-full bg-primary/10 border border-primary/30 flex items-center justify-center overflow-hidden shrink-0">
              {u.avatar_url ? (
                <img src={u.avatar_url} alt="" className="w-full h-full object-cover" />
              ) : (
                <span className="text-xs font-bold text-primary">
                  {(u.username || u.full_name || 'U').slice(0, 2).toUpperCase()}
                </span>
              )}
            </div>
            <div className="flex-1 min-w-0">
              <div className="flex items-center gap-1.5">
                <p className="font-semibold text-foreground text-sm truncate">{u.username || '—'}</p>
                {u.role === 'owner' && (
                  <span className="flex items-center gap-0.5 px-1.5 py-0.5 rounded-full bg-warning/15 text-warning text-[10px] font-bold shrink-0">
                    <Crown className="w-2.5 h-2.5" /> Owner
                  </span>
                )}
                {u.role === 'admin' && (
                  <span className="flex items-center gap-0.5 px-1.5 py-0.5 rounded-full bg-primary/15 text-primary text-[10px] font-bold shrink-0">
                    <ShieldCheck className="w-2.5 h-2.5" /> Admin
                  </span>
                )}
              </div>
              <p className="text-xs text-muted-foreground truncate">{u.full_name || 'No name set'}</p>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default AdminUsers;
