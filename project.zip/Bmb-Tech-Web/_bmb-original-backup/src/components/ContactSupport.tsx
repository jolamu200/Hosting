import { useState } from 'react';
import { Send, CheckCircle2, AlertCircle, MessageCircle, Mail, ExternalLink } from 'lucide-react';
import profileImage from '@/assets/profile.jpg';
import { supabase } from '@/lib/supabaseClient';

const channels = [
  {
    name: 'WhatsApp',
    value: '+255 767 862 457',
    description: 'Chat with us on WhatsApp for fast support',
    href: 'https://wa.me/255767862457',
    color: 'text-success',
    bg: 'bg-success/10',
  },
  {
    name: 'WhatsApp Channel',
    value: 'Bmb Tech',
    description: 'Join our WhatsApp channel for news and updates',
    href: 'https://whatsapp.com/channel/0029VawO6hgF6sn7k3SuVU3z',
    color: 'text-success',
    bg: 'bg-success/10',
  },
  {
    name: 'Telegram',
    value: '@bmbtech',
    description: 'Contact us via Telegram',
    href: 'https://t.me/bmb_tech',
    color: 'text-sky-400',
    bg: 'bg-sky-400/10',
  },
  {
    name: 'Email',
    value: 'bmbxmd@gmail.com',
    description: 'Send us an email for detailed inquiries',
    href: 'mailto:bmbxmd@gmail.com',
    color: 'text-primary',
    bg: 'bg-primary/10',
  },
];

const ContactSupport = () => {
  const [form, setForm] = useState({ name: '', email: '', phone: '', message: '' });
  const [submitted, setSubmitted] = useState(false);
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState('');

  const handleChange = (field: keyof typeof form) => (
    e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>
  ) => {
    setForm(prev => ({ ...prev, [field]: e.target.value }));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setSubmitting(true);

    const { error: submitError } = await supabase.from('contact_messages').insert({
      name: form.name,
      email: form.email || null,
      phone: form.phone || null,
      message: form.message,
    });

    setSubmitting(false);

    if (submitError) {
      console.error('Failed to send message:', submitError.message);
      setError('Something went wrong. Please try again.');
      return;
    }

    setSubmitted(true);
    setTimeout(() => {
      setSubmitted(false);
      setForm({ name: '', email: '', phone: '', message: '' });
    }, 3000);
  };

  return (
    <section id="contact-support" className="relative px-4 py-12">
      <div className="max-w-2xl mx-auto">
        <div className="text-center mb-6">
          <h2 className="text-xl md:text-2xl font-bold text-foreground flex items-center justify-center gap-2">
            <MessageCircle className="w-5 h-5 text-primary" />
            Contact Support
          </h2>
          <p className="text-sm text-muted-foreground mt-1">Reach us through any of the channels below</p>
        </div>

        <div className="space-y-3 mb-8">
          {channels.map((channel) => (
            <a
              key={channel.name}
              href={channel.href}
              target="_blank"
              rel="noopener noreferrer"
              className="flex items-center gap-4 p-4 rounded-2xl gradient-border hover:bg-muted/20 transition-colors"
            >
              <div className={`w-11 h-11 rounded-full flex items-center justify-center shrink-0 ${channel.bg}`}>
                {channel.name === 'Email' ? (
                  <Mail className={`w-5 h-5 ${channel.color}`} />
                ) : (
                  <MessageCircle className={`w-5 h-5 ${channel.color}`} />
                )}
              </div>
              <div className="min-w-0 flex-1">
                <p className={`text-sm font-semibold ${channel.color}`}>{channel.name}</p>
                <p className="text-foreground font-medium text-sm truncate">{channel.value}</p>
                <p className="text-xs text-muted-foreground truncate">{channel.description}</p>
              </div>
              <ExternalLink className="w-4 h-4 text-muted-foreground shrink-0" />
            </a>
          ))}
        </div>

        <div className="gradient-border p-6 md:p-10">
          {/* Header */}
          <div className="flex flex-col items-center text-center mb-6">
            <img
              src={profileImage}
              alt="Bmb Tech"
              className="w-20 h-20 rounded-full object-cover border-2 border-primary/50 mb-4"
            />
            <p className="text-primary font-semibold tracking-wide">@bmbtech</p>
            <h3 className="text-xl md:text-2xl font-bold text-foreground mt-1">
              Send Me a Message
            </h3>
          </div>

          <div className="w-full h-px bg-border/50 mb-6" />

          {submitted ? (
            <div className="flex flex-col items-center justify-center py-10 gap-3 text-center">
              <CheckCircle2 className="w-12 h-12 text-success" />
              <p className="text-foreground font-semibold">Message sent!</p>
              <p className="text-sm text-muted-foreground">We'll get back to you as soon as possible.</p>
            </div>
          ) : (
            <form onSubmit={handleSubmit} className="space-y-4">
              {error && (
                <div className="flex items-center gap-2 px-4 py-3 rounded-xl bg-destructive/10 border border-destructive/40 text-destructive text-sm">
                  <AlertCircle className="w-4 h-4 shrink-0" />
                  {error}
                </div>
              )}
              <input
                type="text"
                required
                placeholder="Your Name (Required)"
                value={form.name}
                onChange={handleChange('name')}
                className="w-full px-4 py-3 rounded-xl bg-background/50 border border-border/60 text-foreground placeholder:text-muted-foreground focus:outline-none focus:border-primary/60 transition-colors"
              />
              <input
                type="email"
                placeholder="Your Email (Optional)"
                value={form.email}
                onChange={handleChange('email')}
                className="w-full px-4 py-3 rounded-xl bg-background/50 border border-border/60 text-foreground placeholder:text-muted-foreground focus:outline-none focus:border-primary/60 transition-colors"
              />
              <input
                type="tel"
                placeholder="Your Phone Number (Optional)"
                value={form.phone}
                onChange={handleChange('phone')}
                className="w-full px-4 py-3 rounded-xl bg-background/50 border border-border/60 text-foreground placeholder:text-muted-foreground focus:outline-none focus:border-primary/60 transition-colors"
              />
              <textarea
                required
                rows={5}
                placeholder="Your Message (Required)"
                value={form.message}
                onChange={handleChange('message')}
                className="w-full px-4 py-3 rounded-xl bg-background/50 border border-border/60 text-foreground placeholder:text-muted-foreground focus:outline-none focus:border-primary/60 transition-colors resize-none"
              />
              <button
                type="submit"
                disabled={submitting}
                className="w-full flex items-center justify-center gap-2 py-3.5 rounded-xl bg-gradient-to-r from-primary to-secondary text-primary-foreground font-bold tracking-wide hover:opacity-90 transition-opacity disabled:opacity-60"
              >
                {submitting ? 'SENDING...' : 'SEND MESSAGE'}
                <Send className="w-4 h-4" />
              </button>
            </form>
          )}
        </div>
      </div>
    </section>
  );
};

export default ContactSupport;
