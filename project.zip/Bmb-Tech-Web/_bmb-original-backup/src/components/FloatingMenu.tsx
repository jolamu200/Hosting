import { useEffect, useState } from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import { 
  Home,
  Phone,
  UserCircle,
  Bot as BotIcon,
  Users,
  ShieldCheck,
  Download,
  PlusCircle,
  KeyRound,
  BookOpen,
  Wallet,
  Receipt,
  X,
} from 'lucide-react';
import profileImage from '@/assets/profile.jpg';
import { useAuth } from '@/context/AuthContext';
import { supabase } from '@/lib/supabaseClient';

const FloatingMenu = () => {
  const [isOpen, setIsOpen] = useState(false);
  const [avatarUrl, setAvatarUrl] = useState<string | null>(null);
  const [isOwner, setIsOwner] = useState(false);
  const [unreadCount, setUnreadCount] = useState(0);
  const navigate = useNavigate();
  const location = useLocation();
  const { user } = useAuth();

  useEffect(() => {
    if (!user) {
      setAvatarUrl(null);
      setIsOwner(false);
      return;
    }

    supabase
      .from('profiles')
      .select('avatar_url, role')
      .eq('id', user.id)
      .single()
      .then(({ data }) => {
        if (data?.avatar_url) setAvatarUrl(data.avatar_url);
        setIsOwner(data?.role === 'owner');
      });
  }, [user]);

  // Track unread messages in the community chat — anything sent after the
  // last time this person read chat_read_state.last_read_at counts as
  // unread. That timestamp is kept fresh by CommunityChat.tsx itself while
  // the person is actually on /community (FloatingMenu isn't rendered on
  // that page, so it can't do the marking itself).
  useEffect(() => {
    if (!user) {
      setUnreadCount(0);
      return;
    }

    const refreshUnreadCount = async () => {
      const { data: readState, error: readError } = await supabase
        .from('chat_read_state')
        .select('last_read_at')
        .eq('user_id', user.id)
        .maybeSingle();
      if (readError) console.error('chat_read_state select failed:', readError.message);

      const lastRead = readState?.last_read_at || new Date(0).toISOString();

      const { count, error: countError } = await supabase
        .from('chat_messages')
        .select('id', { count: 'exact', head: true })
        .gt('created_at', lastRead)
        .neq('user_id', user.id);
      if (countError) console.error('chat_messages count failed:', countError.message);

      setUnreadCount(count || 0);
    };

    refreshUnreadCount();

    const channel = supabase
      .channel('floating-menu-unread')
      .on(
        'postgres_changes',
        { event: 'INSERT', schema: 'public', table: 'chat_messages' },
        refreshUnreadCount
      )
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
  }, [user, location.pathname]);

  const initials = (user?.email || 'U').slice(0, 2).toUpperCase();

  // Not logged in — the menu and avatar only appear once a visitor has an account.
  if (!user) return null;

  const mainMenuItems = [
    { icon: Home, label: 'Home', href: '/' },
    { icon: BotIcon, label: 'Browse Bots', href: '/my-bots' },
    { icon: Users, label: 'Community Chat', href: '/community' },
    { icon: Wallet, label: 'Top Up Coins', href: '/topup' },
    { icon: Phone, label: 'Contact Support', href: '/contact' },
    ...(isOwner ? [{ icon: ShieldCheck, label: 'Tools Admin', href: '/admin' }] : []),
    ...(isOwner ? [{ icon: Receipt, label: 'Admin Payments', href: '/admin-payments' }] : []),
  ];

  const secondaryMenuItems = [
    { icon: PlusCircle, label: 'Request Bot', href: '/request-bot' },
    { icon: Download, label: 'Media Tools', href: '/tools' },
    { icon: KeyRound, label: 'API Key', href: '/profile' },
    { icon: BookOpen, label: 'API Docs', href: '/docs' },
    { icon: UserCircle, label: 'Account Settings', href: '/profile' },
  ];

  const isActive = (href: string) => {
    if (href === '/') return location.pathname === '/';
    if (href.startsWith('/#')) return false;
    if (href.startsWith('http')) return false;
    if (href === '/my-bots') return location.pathname.startsWith('/my-bots') || location.pathname.startsWith('/bots');
    if (href === '/topup') return location.pathname.startsWith('/topup');
    return location.pathname === href;
  };

  const handleNavClick = (e: React.MouseEvent<HTMLAnchorElement>, href: string, external?: boolean) => {
    if (external) return;
    
    e.preventDefault();
    setIsOpen(false);
    
    // Handle hash links on current page
    if (href.startsWith('/#')) {
      const targetId = href.replace('/#', '');
      if (location.pathname === '/') {
        const element = document.getElementById(targetId);
        if (element) {
          element.scrollIntoView({ behavior: 'smooth', block: 'start' });
        }
      } else {
        navigate('/');
        setTimeout(() => {
          const element = document.getElementById(targetId);
          if (element) {
            element.scrollIntoView({ behavior: 'smooth', block: 'start' });
          }
        }, 100);
      }
    } else {
      navigate(href);
      window.scrollTo({ top: 0, behavior: 'smooth' });
    }
  };

  return (
    <>
      {/* Menu Toggle Button */}
      <button
        onClick={() => setIsOpen(!isOpen)}
        className="fixed top-4 left-4 z-50 w-9 h-9 rounded-full gradient-border glow-primary flex items-center justify-center group hover:scale-110 transition-transform duration-300"
        aria-label="Toggle menu"
      >
        {unreadCount > 0 && !isOpen && (
          <span className="absolute -top-0.5 -right-0.5 w-2.5 h-2.5 rounded-full bg-destructive border-2 border-background" />
        )}
        <div className="flex flex-col items-center justify-center w-4 h-4 gap-1">
          <span 
            className={`block h-0.5 bg-primary transition-all duration-300 ease-out ${
              isOpen ? 'w-4 rotate-45 translate-y-1.5' : 'w-4'
            }`} 
          />
          <span 
            className={`block h-0.5 bg-primary transition-all duration-300 ease-out ${
              isOpen ? 'w-0 opacity-0' : 'w-3'
            }`} 
          />
          <span 
            className={`block h-0.5 bg-primary transition-all duration-300 ease-out ${
              isOpen ? 'w-4 -rotate-45 -translate-y-1.5' : 'w-4'
            }`} 
          />
        </div>
      </button>

      {/* Profile avatar button - top right */}
      {user && (
        <button
          onClick={() => navigate('/profile')}
          className="fixed top-4 right-4 z-50 w-9 h-9 rounded-full border-2 border-primary/60 overflow-hidden flex items-center justify-center bg-card hover:scale-110 transition-transform duration-300"
          aria-label="Account settings"
        >
          {avatarUrl ? (
            <img src={avatarUrl} alt="Profile" className="w-full h-full object-cover" />
          ) : (
            <span className="text-xs font-bold text-primary">{initials}</span>
          )}
        </button>
      )}

      {/* Backdrop */}
      <div
        className={`fixed inset-0 z-40 bg-background/70 backdrop-blur-sm transition-opacity duration-300 ${
          isOpen ? 'opacity-100 pointer-events-auto' : 'opacity-0 pointer-events-none'
        }`}
        onClick={() => setIsOpen(false)}
      />

      {/* Sidebar Panel */}
      <nav
        className={`fixed top-0 left-0 z-50 h-full w-[280px] max-w-[80vw] bg-card border-r border-border/60 shadow-2xl transition-transform duration-300 ease-out flex flex-col ${
          isOpen ? 'translate-x-0' : '-translate-x-full'
        }`}
      >
        {/* Header */}
        <div className="flex items-center justify-between gap-3 p-5 border-b border-border/50">
          <div className="flex items-center gap-3 min-w-0">
            <img
              src={profileImage}
              alt="Bmb Tech"
              className="w-10 h-10 rounded-full object-cover border-2 border-primary/50 shrink-0"
            />
            <div className="min-w-0">
              <p className="font-bold text-foreground text-sm truncate">Bmb Tech</p>
              <p className="text-xs text-muted-foreground truncate">Full-Stack Developer</p>
            </div>
          </div>
          <button
            onClick={() => setIsOpen(false)}
            className="shrink-0 w-8 h-8 rounded-full flex items-center justify-center text-muted-foreground hover:text-foreground hover:bg-muted/50 transition-colors"
            aria-label="Close menu"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Menu Items */}
        <ul className="flex-1 overflow-y-auto py-2">
          {mainMenuItems.map((item, index) => {
            const Icon = item.icon;
            const active = isActive(item.href);

            return (
              <li key={index}>
                <a
                  href={item.href}
                  target={item.external ? '_blank' : undefined}
                  rel={item.external ? 'noopener noreferrer' : undefined}
                  onClick={(e) => handleNavClick(e, item.href, item.external)}
                  className={`flex items-center gap-3 px-5 py-3 border-l-2 transition-colors duration-200 ${
                    active
                      ? 'bg-primary/15 border-primary text-primary'
                      : 'border-transparent text-foreground/90 hover:bg-muted/40 hover:border-primary/40'
                  }`}
                >
                  <Icon className={`w-5 h-5 shrink-0 ${active ? 'text-primary' : 'text-muted-foreground'}`} />
                  <span className="text-sm font-medium tracking-wide flex-1">
                    {item.label}
                  </span>
                  {item.href === '/community' && unreadCount > 0 && (
                    <span className="shrink-0 min-w-[20px] h-5 px-1.5 rounded-full bg-destructive text-destructive-foreground text-[11px] font-bold flex items-center justify-center">
                      {unreadCount > 9 ? '9+' : unreadCount}
                    </span>
                  )}
                </a>
              </li>
            );
          })}
        </ul>

        {/* Secondary group — utility links, pinned just above the footer */}
        <div className="mt-auto mx-4 pt-3 border-t border-border/40 space-y-1.5">
          {secondaryMenuItems.map((item, index) => {
            const Icon = item.icon;
            const active = isActive(item.href);

            return (
              <a
                key={index}
                href={item.href}
                onClick={(e) => handleNavClick(e, item.href)}
                className={`flex items-center gap-3 px-3 py-2.5 rounded-xl transition-colors duration-200 ${
                  active
                    ? 'bg-primary/15 text-primary'
                    : 'bg-card/60 text-foreground/90 hover:bg-muted/40'
                }`}
              >
                <Icon className={`w-4 h-4 shrink-0 ${active ? 'text-primary' : 'text-muted-foreground'}`} />
                <span className="text-sm font-medium tracking-wide">
                  {item.label}
                </span>
              </a>
            );
          })}
        </div>

        {/* Footer */}
        <div className="p-4 border-t border-border/50 text-center">
          <p className="text-muted-foreground text-[10px] font-mono tracking-widest select-none">
            B.M.B TECH WEB
          </p>
        </div>
      </nav>
    </>
  );
};

export default FloatingMenu;
