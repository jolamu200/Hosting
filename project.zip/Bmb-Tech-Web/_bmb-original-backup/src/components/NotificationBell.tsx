import { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Bell, X } from 'lucide-react';
import { supabase } from '@/lib/supabaseClient';
import { useAuth } from '@/context/AuthContext';
import ConfettiEffect from './ConfettiEffect';

interface Notification {
  id: string;
  title: string;
  message: string;
  link: string | null;
  created_at: string;
}

const NotificationBell = () => {
  const { user } = useAuth();
  const navigate = useNavigate();
  const [notifications, setNotifications] = useState<Notification[]>([]);
  const [readIds, setReadIds] = useState<Set<string>>(new Set());
  const [open, setOpen] = useState(false);
  const [showConfetti, setShowConfetti] = useState(false);

  const loadNotifications = async () => {
    if (!user) return;

    const { data: notifData } = await supabase
      .from('notifications')
      .select('id, title, message, link, created_at')
      .order('created_at', { ascending: false })
      .limit(30);

    const { data: readData } = await supabase
      .from('notification_reads')
      .select('notification_id')
      .eq('user_id', user.id);

    setNotifications(notifData || []);
    setReadIds(new Set((readData || []).map(r => r.notification_id)));
  };

  useEffect(() => {
    loadNotifications();
  }, [user]);

  const unreadCount = notifications.filter(n => !readIds.has(n.id)).length;
  const badgeLabel = unreadCount > 9 ? '9+' : String(unreadCount);

  const handleOpenNotification = async (notif: Notification) => {
    if (!user) return;

    if (!readIds.has(notif.id)) {
      await supabase.from('notification_reads').insert({
        user_id: user.id,
        notification_id: notif.id,
      });
      setReadIds(prev => new Set(prev).add(notif.id));

      // Celebrate only the first time this notification is opened
      setShowConfetti(true);
    }

    setOpen(false);

    if (notif.link) {
      navigate(notif.link);
    }
  };

  if (!user) return null;

  return (
    <>
      <div className="relative">
        <button
          onClick={() => setOpen(!open)}
          className="relative w-9 h-9 rounded-full flex items-center justify-center text-foreground hover:bg-muted/40 transition-colors"
          aria-label="Notifications"
        >
          <Bell className="w-5 h-5" />
          {unreadCount > 0 && (
            <span className="absolute -top-0.5 -right-0.5 min-w-[16px] h-4 px-1 rounded-full bg-destructive text-white text-[10px] font-bold flex items-center justify-center">
              {badgeLabel}
            </span>
          )}
        </button>

        {open && (
          <>
            <div className="fixed inset-0 z-40" onClick={() => setOpen(false)} />
            <div className="absolute right-0 top-11 z-50 w-80 max-w-[85vw] max-h-96 overflow-y-auto gradient-border p-3">
              <div className="flex items-center justify-between mb-2 px-1">
                <p className="text-sm font-bold text-foreground">Notifications</p>
                <button onClick={() => setOpen(false)} className="text-muted-foreground hover:text-foreground">
                  <X className="w-4 h-4" />
                </button>
              </div>

              {notifications.length === 0 ? (
                <p className="text-xs text-muted-foreground text-center py-8">No notifications yet.</p>
              ) : (
                <div className="space-y-1.5">
                  {notifications.map((notif) => {
                    const isUnread = !readIds.has(notif.id);
                    return (
                      <button
                        key={notif.id}
                        onClick={() => handleOpenNotification(notif)}
                        className={`w-full text-left p-3 rounded-xl border transition-colors ${
                          isUnread
                            ? 'bg-primary/10 border-primary/40'
                            : 'bg-background/30 border-border/40 hover:bg-muted/30'
                        }`}
                      >
                        <div className="flex items-center gap-2 mb-1">
                          {isUnread && <span className="w-1.5 h-1.5 rounded-full bg-primary shrink-0" />}
                          <p className="text-xs font-semibold text-foreground truncate">{notif.title}</p>
                        </div>
                        <p className="text-[11px] text-muted-foreground line-clamp-2">{notif.message}</p>
                      </button>
                    );
                  })}
                </div>
              )}
            </div>
          </>
        )}
      </div>

      {showConfetti && <ConfettiEffect onDone={() => setShowConfetti(false)} />}
    </>
  );
};

export default NotificationBell;
