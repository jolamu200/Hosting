import { useEffect, useState } from 'react';
import { Loader2, KeyRound, Plus, Pencil, Trash2, Eye, EyeOff, X, Check } from 'lucide-react';
import { supabase } from '@/lib/supabaseClient';

interface ApiKeyRow {
  id: string;
  key_name: string;
  key_value: string;
  description: string | null;
  updated_at: string | null;
}

const AdminApiKeys = () => {
  const [keys, setKeys] = useState<ApiKeyRow[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [revealed, setRevealed] = useState<Record<string, boolean>>({});

  // Add form
  const [showAddForm, setShowAddForm] = useState(false);
  const [newName, setNewName] = useState('');
  const [newValue, setNewValue] = useState('');
  const [newDescription, setNewDescription] = useState('');
  const [saving, setSaving] = useState(false);

  // Edit state
  const [editingId, setEditingId] = useState<string | null>(null);
  const [editValue, setEditValue] = useState('');
  const [editDescription, setEditDescription] = useState('');

  const [deletingId, setDeletingId] = useState<string | null>(null);

  const loadKeys = async () => {
    setLoading(true);
    const { data, error: fetchError } = await supabase
      .from('admin_api_keys')
      .select('id, key_name, key_value, description, updated_at')
      .order('key_name', { ascending: true });

    if (fetchError) {
      setError('Failed to load API keys: ' + fetchError.message);
    } else {
      setKeys((data as any) || []);
      setError('');
    }
    setLoading(false);
  };

  useEffect(() => {
    loadKeys();
  }, []);

  const resetAddForm = () => {
    setNewName('');
    setNewValue('');
    setNewDescription('');
    setShowAddForm(false);
  };

  const handleAdd = async () => {
    const keyName = newName.trim();
    const keyValue = newValue.trim();

    if (!keyName || !keyValue) {
      setError('Key name and value are both required.');
      return;
    }

    setSaving(true);
    setError('');

    const { data, error: insertError } = await supabase
      .from('admin_api_keys')
      .insert({
        key_name: keyName,
        key_value: keyValue,
        description: newDescription.trim() || null,
      })
      .select('id, key_name, key_value, description, updated_at')
      .single();

    setSaving(false);

    if (insertError) {
      setError(
        insertError.code === '23505'
          ? `A key named "${keyName}" already exists.`
          : 'Failed to add key: ' + insertError.message
      );
      return;
    }

    setKeys((prev) => [...prev, data as any].sort((a, b) => a.key_name.localeCompare(b.key_name)));
    resetAddForm();
  };

  const startEdit = (row: ApiKeyRow) => {
    setEditingId(row.id);
    setEditValue(row.key_value);
    setEditDescription(row.description || '');
  };

  const cancelEdit = () => {
    setEditingId(null);
    setEditValue('');
    setEditDescription('');
  };

  const handleSaveEdit = async (id: string) => {
    const value = editValue.trim();
    if (!value) {
      setError('Key value cannot be empty.');
      return;
    }

    setSaving(true);
    setError('');

    const { data, error: updateError } = await supabase
      .from('admin_api_keys')
      .update({ key_value: value, description: editDescription.trim() || null })
      .eq('id', id)
      .select('id, key_name, key_value, description, updated_at')
      .single();

    setSaving(false);

    if (updateError) {
      setError('Failed to update key: ' + updateError.message);
      return;
    }

    setKeys((prev) => prev.map((k) => (k.id === id ? (data as any) : k)));
    cancelEdit();
  };

  const handleDelete = async (id: string) => {
    setDeletingId(id);
    const { error: deleteError } = await supabase.from('admin_api_keys').delete().eq('id', id);
    setDeletingId(null);

    if (deleteError) {
      setError('Failed to delete key: ' + deleteError.message);
      return;
    }

    setKeys((prev) => prev.filter((k) => k.id !== id));
  };

  const toggleReveal = (id: string) => {
    setRevealed((prev) => ({ ...prev, [id]: !prev[id] }));
  };

  const maskValue = (value: string) => {
    if (value.length <= 8) return '••••••••';
    return `${value.slice(0, 4)}${'•'.repeat(Math.min(value.length - 8, 20))}${value.slice(-4)}`;
  };

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between gap-3">
        <h2 className="text-sm font-semibold text-muted-foreground tracking-wide uppercase flex items-center gap-2">
          <KeyRound className="w-4 h-4 text-primary" />
          API Keys
        </h2>
        <button
          onClick={() => setShowAddForm((v) => !v)}
          className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-primary/15 text-primary text-xs font-semibold hover:bg-primary/25 transition-colors"
        >
          <Plus className="w-3.5 h-3.5" />
          Add Key
        </button>
      </div>

      <p className="text-xs text-muted-foreground leading-relaxed">
        Keys added here are auto-filled for anyone deploying a bot whose{' '}
        <code className="px-1 py-0.5 rounded bg-muted/50">app.json</code> env var name matches the{' '}
        <span className="font-semibold text-foreground">Key name</span> below exactly (e.g.{' '}
        <code className="px-1 py-0.5 rounded bg-muted/50">HEROKU_API_KEY</code>). Users can still overwrite the
        pre-filled value if they need to.
      </p>

      {error && (
        <div className="px-4 py-3 rounded-xl bg-destructive/10 border border-destructive/40 text-destructive text-sm">
          {error}
        </div>
      )}

      {showAddForm && (
        <div className="gradient-border p-4 space-y-3">
          <div>
            <label className="text-xs text-muted-foreground mb-1 block">Key name (must match app.json env var)</label>
            <input
              type="text"
              value={newName}
              onChange={(e) => setNewName(e.target.value.toUpperCase().replace(/[^A-Z0-9_]/g, ''))}
              placeholder="HEROKU_API_KEY"
              className="w-full px-3 py-2 rounded-lg bg-background/50 border border-border/60 text-foreground text-sm font-mono placeholder:text-muted-foreground focus:outline-none focus:border-primary/60 transition-colors"
            />
          </div>
          <div>
            <label className="text-xs text-muted-foreground mb-1 block">Key value</label>
            <input
              type="text"
              value={newValue}
              onChange={(e) => setNewValue(e.target.value)}
              placeholder="Paste the secret value"
              className="w-full px-3 py-2 rounded-lg bg-background/50 border border-border/60 text-foreground text-sm font-mono placeholder:text-muted-foreground focus:outline-none focus:border-primary/60 transition-colors"
            />
          </div>
          <div>
            <label className="text-xs text-muted-foreground mb-1 block">Description (optional)</label>
            <input
              type="text"
              value={newDescription}
              onChange={(e) => setNewDescription(e.target.value)}
              placeholder="e.g. Owner's personal Heroku API key"
              className="w-full px-3 py-2 rounded-lg bg-background/50 border border-border/60 text-foreground text-sm placeholder:text-muted-foreground focus:outline-none focus:border-primary/60 transition-colors"
            />
          </div>
          <div className="flex items-center gap-2 pt-1">
            <button
              onClick={handleAdd}
              disabled={saving}
              className="flex items-center gap-1.5 px-4 py-2 rounded-lg bg-gradient-to-r from-primary to-secondary text-primary-foreground text-sm font-semibold hover:opacity-90 transition-opacity disabled:opacity-50"
            >
              {saving ? <Loader2 className="w-4 h-4 animate-spin" /> : <Check className="w-4 h-4" />}
              Save
            </button>
            <button
              onClick={resetAddForm}
              className="flex items-center gap-1.5 px-4 py-2 rounded-lg border border-border/60 text-sm text-muted-foreground hover:text-foreground hover:bg-muted/40 transition-colors"
            >
              <X className="w-4 h-4" />
              Cancel
            </button>
          </div>
        </div>
      )}

      {loading && (
        <div className="flex items-center justify-center gap-2 py-16 text-muted-foreground text-sm">
          <Loader2 className="w-4 h-4 animate-spin" />
          Loading API keys...
        </div>
      )}

      {!loading && keys.length === 0 && (
        <p className="text-sm text-muted-foreground text-center py-16">
          No API keys saved yet. Add one so it auto-fills during bot deploys.
        </p>
      )}

      <div className="space-y-2">
        {keys.map((k) => (
          <div key={k.id} className="gradient-border p-4">
            {editingId === k.id ? (
              <div className="space-y-3">
                <p className="font-mono text-sm font-semibold text-foreground">{k.key_name}</p>
                <div>
                  <label className="text-xs text-muted-foreground mb-1 block">Key value</label>
                  <input
                    type="text"
                    value={editValue}
                    onChange={(e) => setEditValue(e.target.value)}
                    className="w-full px-3 py-2 rounded-lg bg-background/50 border border-border/60 text-foreground text-sm font-mono focus:outline-none focus:border-primary/60 transition-colors"
                  />
                </div>
                <div>
                  <label className="text-xs text-muted-foreground mb-1 block">Description (optional)</label>
                  <input
                    type="text"
                    value={editDescription}
                    onChange={(e) => setEditDescription(e.target.value)}
                    className="w-full px-3 py-2 rounded-lg bg-background/50 border border-border/60 text-foreground text-sm focus:outline-none focus:border-primary/60 transition-colors"
                  />
                </div>
                <div className="flex items-center gap-2">
                  <button
                    onClick={() => handleSaveEdit(k.id)}
                    disabled={saving}
                    className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-gradient-to-r from-primary to-secondary text-primary-foreground text-xs font-semibold hover:opacity-90 transition-opacity disabled:opacity-50"
                  >
                    {saving ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <Check className="w-3.5 h-3.5" />}
                    Save
                  </button>
                  <button
                    onClick={cancelEdit}
                    className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg border border-border/60 text-xs text-muted-foreground hover:text-foreground hover:bg-muted/40 transition-colors"
                  >
                    <X className="w-3.5 h-3.5" />
                    Cancel
                  </button>
                </div>
              </div>
            ) : (
              <div className="flex items-start justify-between gap-3">
                <div className="min-w-0 flex-1">
                  <p className="font-mono text-sm font-semibold text-foreground truncate">{k.key_name}</p>
                  {k.description && (
                    <p className="text-xs text-muted-foreground mt-0.5 truncate">{k.description}</p>
                  )}
                  <div className="flex items-center gap-1.5 mt-2">
                    <code className="text-xs font-mono text-foreground/80 px-2 py-1 rounded bg-muted/40 truncate">
                      {revealed[k.id] ? k.key_value : maskValue(k.key_value)}
                    </code>
                    <button
                      onClick={() => toggleReveal(k.id)}
                      className="shrink-0 w-6 h-6 rounded-full flex items-center justify-center text-muted-foreground hover:text-foreground hover:bg-muted/50 transition-colors"
                      aria-label={revealed[k.id] ? 'Hide value' : 'Reveal value'}
                    >
                      {revealed[k.id] ? <EyeOff className="w-3.5 h-3.5" /> : <Eye className="w-3.5 h-3.5" />}
                    </button>
                  </div>
                </div>
                <div className="flex items-center gap-1 shrink-0">
                  <button
                    onClick={() => startEdit(k)}
                    className="w-8 h-8 rounded-full flex items-center justify-center text-muted-foreground hover:text-foreground hover:bg-muted/50 transition-colors"
                    aria-label="Edit key"
                  >
                    <Pencil className="w-4 h-4" />
                  </button>
                  <button
                    onClick={() => handleDelete(k.id)}
                    disabled={deletingId === k.id}
                    className="w-8 h-8 rounded-full flex items-center justify-center text-muted-foreground hover:text-destructive hover:bg-destructive/10 transition-colors disabled:opacity-50"
                    aria-label="Delete key"
                  >
                    {deletingId === k.id ? (
                      <Loader2 className="w-4 h-4 animate-spin" />
                    ) : (
                      <Trash2 className="w-4 h-4" />
                    )}
                  </button>
                </div>
              </div>
            )}
          </div>
        ))}
      </div>
    </div>
  );
};

export default AdminApiKeys;
