import { useEffect } from 'react';
import { supabase } from '@/lib/supabaseClient';
import { useAuth } from '@/context/AuthContext';

// Bumps profiles.last_seen_at every 60s while the user has the app open on
// any page. "Online" elsewhere in the app is derived from this timestamp
// being recent (e.g. within the last 2 minutes).
export const usePresenceHeartbeat = () => {
  const { user } = useAuth();

  useEffect(() => {
    if (!user) return;

    const beat = () => {
      supabase.from('profiles').update({ last_seen_at: new Date().toISOString() }).eq('id', user.id);
    };

    beat(); // immediately on mount/login
    const interval = setInterval(beat, 60000);

    return () => clearInterval(interval);
  }, [user]);
};
