import { useEffect, useState } from 'react';
import { supabase } from '@/lib/supabaseClient';

const ONLINE_WINDOW_MINUTES = 2;

// Counts how many profiles have a recent last_seen_at (updated by
// usePresenceHeartbeat). Refreshes every 30s while mounted.
export const useOnlineCount = () => {
  const [count, setCount] = useState(0);

  useEffect(() => {
    const load = async () => {
      const cutoff = new Date(Date.now() - ONLINE_WINDOW_MINUTES * 60 * 1000).toISOString();
      const { count: onlineCount } = await supabase
        .from('profiles')
        .select('id', { count: 'exact', head: true })
        .gte('last_seen_at', cutoff);

      setCount(onlineCount || 0);
    };

    load();
    const interval = setInterval(load, 30000);
    return () => clearInterval(interval);
  }, []);

  return count;
};
