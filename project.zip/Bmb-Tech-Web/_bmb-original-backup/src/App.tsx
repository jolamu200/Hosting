import { Toaster } from "@/components/ui/toaster";
import { Toaster as Sonner } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import { ThemeProvider } from "next-themes";
import { AuthProvider } from "./context/AuthContext";
import { LanguageProvider } from "./context/LanguageContext";
import RequireAuth from "./components/RequireAuth";
import Index from "./pages/Index";
import SignupRedirect from "./pages/SignupRedirect";
import MediaTools from "./pages/MediaTools";
import About from "./pages/About";
import Contact from "./pages/Contact";
import Profile from "./pages/Profile";
import BrowseBots from "./pages/BrowseBots";
import RequestBot from "./pages/RequestBot";
import Terms from "./pages/Terms";
import Careers from "./pages/Careers";
import Docs from "./pages/Docs";
import Blog from "./pages/Blog";
import BotDetail from "./pages/BotDetail";
import MyBots from "./pages/MyBots";
import BotDeployment from "./pages/BotDeployment";
import BotSettings from "./pages/BotSettings";
import CommunityChat from "./pages/CommunityChat";
import DiscoverAppsGate from "./pages/DiscoverAppsGate";
import Admin from "./pages/Admin";
import AdminPayments from "./pages/AdminPayments";
import TopUpWallet from "./pages/TopUpWallet";
import TopUpCoins from "./pages/TopUpCoins";
import ToolRedirect from "./pages/ToolRedirect";
import NotFound from "./pages/NotFound";
import InstallPrompt from "./components/InstallPrompt";
import PushNotificationPrompt from "./components/PushNotificationPrompt";

const queryClient = new QueryClient();

const App = () => (
  <QueryClientProvider client={queryClient}>
    <ThemeProvider attribute="class" defaultTheme="dark" enableSystem>
      <AuthProvider>
        <LanguageProvider>
        <TooltipProvider>
          <Toaster />
          <Sonner />
          <InstallPrompt />
          <PushNotificationPrompt />
          <BrowserRouter>
            <Routes>
              {/* Admin has its own separate username/password gate, not the visitor login */}
              <Route path="/admin" element={<Admin />} />
              {/* Payments dashboard — Owner-only, checked inside the page itself */}
              <Route path="/admin-payments" element={<AdminPayments />} />

              {/* Home is public — no login required to view it */}
              <Route path="/" element={<Index />} />

              {/* Referral links land here, capture the code, then bounce to Home */}
              <Route path="/signup" element={<SignupRedirect />} />

              {/* Terms are public — readable before signing in or logging in */}
              <Route path="/terms" element={<Terms />} />
              <Route path="/careers" element={<Careers />} />
              <Route path="/docs" element={<Docs />} />
              <Route path="/blog" element={<Blog />} />

              {/* Every other route requires a logged-in visitor */}
              <Route
                path="/*"
                element={
                  <RequireAuth>
                    <Routes>
                      <Route path="/tools" element={<MediaTools />} />
                      <Route path="/about" element={<About />} />
                      <Route path="/contact" element={<Contact />} />
                      <Route path="/profile" element={<Profile />} />
                      <Route path="/bots" element={<BrowseBots />} />
                      <Route path="/request-bot" element={<RequestBot />} />
                      <Route path="/bots/:slug" element={<BotDetail />} />
                      <Route path="/deploy" element={<BrowseBots />} />
                      <Route path="/deploy/:slug" element={<BotDetail />} />
                      <Route path="/my-bots" element={<MyBots />} />
                      <Route path="/my-bots/deployments" element={<BotDeployment />} />
                      <Route path="/my-bots/:appId" element={<BotSettings />} />
                      <Route path="/community" element={<CommunityChat />} />
                      <Route path="/topup" element={<TopUpWallet />} />
                      <Route path="/topup/:countryCode" element={<TopUpCoins />} />
                      <Route path="/discover" element={<DiscoverAppsGate />} />
                      {/* ADD ALL CUSTOM ROUTES ABOVE THE CATCH-ALL "*" ROUTE */}
                      <Route path="/:slug" element={<ToolRedirect />} />
                      <Route path="*" element={<NotFound />} />
                    </Routes>
                  </RequireAuth>
                }
              />
            </Routes>
          </BrowserRouter>
        </TooltipProvider>
        </LanguageProvider>
      </AuthProvider>
    </ThemeProvider>
  </QueryClientProvider>
);

export default App;
