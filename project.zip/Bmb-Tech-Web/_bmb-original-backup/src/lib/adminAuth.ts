// Very lightweight client-side gate for the admin panel.
// Credentials live in Vite env vars, which are readable in the built
// bundle — this is a basic deterrent, not real security.

const SESSION_KEY = 'bmb_admin_session';

export const ADMIN_USERNAME = import.meta.env.VITE_ADMIN_USERNAME as string;
export const ADMIN_PASSWORD = import.meta.env.VITE_ADMIN_PASSWORD as string;

export function checkAdminCredentials(username: string, password: string): boolean {
  if (!ADMIN_USERNAME || !ADMIN_PASSWORD) {
    console.warn('Admin credentials are not set in .env (VITE_ADMIN_USERNAME / VITE_ADMIN_PASSWORD).');
    return false;
  }
  return username === ADMIN_USERNAME && password === ADMIN_PASSWORD;
}

export function setAdminSession() {
  sessionStorage.setItem(SESSION_KEY, 'true');
}

export function isAdminLoggedIn(): boolean {
  return sessionStorage.getItem(SESSION_KEY) === 'true';
}

export function clearAdminSession() {
  sessionStorage.removeItem(SESSION_KEY);
}
