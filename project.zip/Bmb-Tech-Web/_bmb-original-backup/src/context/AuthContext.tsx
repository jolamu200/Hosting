import { createContext, useContext, useEffect, useState, ReactNode } from 'react';
import type { Session, User } from '@supabase/supabase-js';
import { supabase } from '@/lib/supabaseClient';

interface AuthContextValue {
  session: Session | null;
  user: User | null;
  loading: boolean;
}

const AuthContext = createContext<AuthContextValue>({
  session: null,
  user: null,
  loading: true,
});

// Email/password signups get their `profiles` row created explicitly during
// the OTP-verify step (see Login.tsx). Google/GitHub sign-ins skip that
// screen entirely, so without this, those accounts would have no profiles
// row at all — which is why editing a username (or anything else on the
// Profile page) silently failed for them: there was no existing row for
// the update to match, and the client isn't allowed to freely insert one
// via RLS. This makes sure a row exists for EVERY signed-in user, however
// they signed up, generating a safe placeholder username from their OAuth
// profile so the NOT NULL/unique constraint is satisfied.
const ensureProfileExists = async (user: User) => {
  const { data: existing } = await supabase
    .from('profiles')
    .select('id')
    .eq('id', user.id)
    .maybeSingle();

  if (existing) return;

  const meta = user.user_metadata || {};
  const baseName =
    (meta.user_name as string) ||
    (meta.preferred_username as string) ||
    (meta.full_name as string)?.replace(/\s+/g, '').toLowerCase() ||
    user.email?.split('@')[0] ||
    'user';
  const cleanBase = baseName.toLowerCase().replace(/[^a-z0-9_]/g, '').slice(0, 14) || 'user';
  const candidateUsername = `${cleanBase}${Math.floor(1000 + Math.random() * 9000)}`;

  await supabase.from('profiles').upsert({
    id: user.id,
    full_name: (meta.full_name as string) || (meta.name as string) || '',
    username: candidateUsername,
    avatar_url: (meta.avatar_url as string) || (meta.picture as string) || null,
    updated_at: new Date().toISOString(),
  });
};

export const AuthProvider = ({ children }: { children: ReactNode }) => {
  const [session, setSession] = useState<Session | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    // Get the current session on first load
    supabase.auth.getSession().then(({ data: { session } }) => {
      setSession(session);
      setLoading(false);
      if (session?.user) ensureProfileExists(session.user).catch(() => {});
    });

    // Keep session in sync with login/logout/token refresh events
    const { data: listener } = supabase.auth.onAuthStateChange((_event, session) => {
      setSession(session);
      setLoading(false);
      if (session?.user) ensureProfileExists(session.user).catch(() => {});
    });

    return () => {
      listener.subscription.unsubscribe();
    };
  }, []);

  return (
    <AuthContext.Provider value={{ session, user: session?.user ?? null, loading }}>
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => useContext(AuthContext);
