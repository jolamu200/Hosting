import { createRoot } from "react-dom/client";
import App from "./App.tsx";
import "./index.css";

// Register Service Worker for PWA support, and make sure a new deploy
// actually reaches people who already have the app open or installed —
// this is what used to require force-closing and reopening the app.
if ("serviceWorker" in navigator) {
  window.addEventListener("load", () => {
    navigator.serviceWorker
      .register("/sw.js")
      .then((registration) => {
        console.log("SW registered:", registration.scope);

        // A new service worker was found — once it finishes installing and
        // is sitting there "waiting" (because an old one is still active),
        // tell it to take over right away and reload so the new build is
        // what the person sees, automatically, no manual refresh needed.
        registration.addEventListener("updatefound", () => {
          const newWorker = registration.installing;
          if (!newWorker) return;

          newWorker.addEventListener("statechange", () => {
            if (newWorker.state === "installed" && navigator.serviceWorker.controller) {
              newWorker.postMessage("SKIP_WAITING");
            }
          });
        });

        // Ask the browser to check for a new service worker every few
        // minutes while the app is open, instead of only on a fresh load —
        // this is what makes updates reach people who leave the app open
        // (or installed and backgrounded) for a long time.
        setInterval(() => {
          registration.update();
        }, 5 * 60 * 1000);
      })
      .catch((error) => {
        console.error("SW registration failed:", error);
      });

    // Once the new service worker takes control, reload once so every tab
    // ends up running the new build's JS/CSS instead of a stale bundle.
    let hasReloaded = false;
    navigator.serviceWorker.addEventListener("controllerchange", () => {
      if (hasReloaded) return;
      hasReloaded = true;
      window.location.reload();
    });
  });
}

createRoot(document.getElementById("root")!).render(<App />);
