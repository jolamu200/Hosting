export interface CoinPackage {
  id: string;
  label: string;
  coins: number;
  bonus?: number;
  priceLocal: number;
  bestValue?: boolean;
}

export interface TopupCountry {
  code: 'tanzania' | 'kenya' | 'nigeria' | 'cameroon' | 'worldwide';
  name: string;
  flagEmoji: string;
  currency: string;
  methodLabels: string[];
  // Only Tanzania is wired to a live payment provider right now. Every
  // other country renders a "Coming soon" screen instead of the coin list.
  active: boolean;
  rateLabel: string;      // e.g. "1 Coin = TZS 100"
  ratePerCoin: number;    // local currency units per coin, used by the calculator
  minCoins: number;
  packages: CoinPackage[];
}

export const topupCountries: TopupCountry[] = [
  {
    code: 'tanzania',
    name: 'Tanzania',
    flagEmoji: '🇹🇿',
    currency: 'TZS',
    methodLabels: ['M-Pesa', 'Manual Pay'],
    active: true,
    rateLabel: '1 Coin = TZS 100',
    ratePerCoin: 100,
    minCoins: 3,
    packages: [
      { id: 'starter', label: 'Starter', coins: 10, priceLocal: 1000 },
      { id: 'basic', label: 'Basic', coins: 20, priceLocal: 2000 },
      { id: 'standard', label: 'Standard', coins: 30, priceLocal: 3000 },
      { id: 'pro', label: 'Pro', coins: 55, bonus: 5, priceLocal: 5500, bestValue: true },
      { id: 'elite', label: 'Elite', coins: 110, bonus: 10, priceLocal: 11000 },
      { id: 'ultimate', label: 'Ultimate', coins: 220, bonus: 20, priceLocal: 22000 },
    ],
  },
  {
    code: 'kenya',
    name: 'Kenya',
    flagEmoji: '🇰🇪',
    currency: 'KES',
    methodLabels: ['M-Pesa STK', 'Airtel Money', 'Visa / Mastercard'],
    active: false,
    rateLabel: '',
    ratePerCoin: 0,
    minCoins: 0,
    packages: [],
  },
  {
    code: 'nigeria',
    name: 'Nigeria',
    flagEmoji: '🇳🇬',
    currency: 'NGN',
    methodLabels: ['Zap / OPay', 'Card', 'Transfer / USSD'],
    active: false,
    rateLabel: '',
    ratePerCoin: 0,
    minCoins: 0,
    packages: [],
  },
  {
    code: 'cameroon',
    name: 'Cameroon',
    flagEmoji: '🇨🇲',
    currency: 'XAF',
    methodLabels: ['MTN / Orange MoMo', 'Fapshi'],
    active: false,
    rateLabel: '',
    ratePerCoin: 0,
    minCoins: 0,
    packages: [],
  },
  {
    code: 'worldwide',
    name: 'Worldwide',
    flagEmoji: '🌍',
    currency: 'USD',
    methodLabels: ['Visa', 'Mastercard'],
    active: false,
    rateLabel: '',
    ratePerCoin: 0,
    minCoins: 0,
    packages: [],
  },
];

export const getTopupCountry = (code: string) =>
  topupCountries.find((c) => c.code === code);
