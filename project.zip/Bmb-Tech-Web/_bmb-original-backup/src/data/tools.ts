import { Video, Facebook, Code, Users, Upload, Sparkles, Film, Globe, ImageOff, Contact, LucideIcon } from 'lucide-react';

export interface Tool {
  icon: LucideIcon;
  title: string;
  description: string;
  url?: string;
  isComingSoon?: boolean;
  tech?: string;
  isNew?: boolean;
  slug?: string;
}

export const tools: Tool[] = [
  {
    icon: Video,
    title: 'YouTube Downloader',
    description: 'Download high-quality videos from YouTube with ease. Fast, secure, and reliable.',
    url: 'https://bmb-music.zone.id/',
    tech: 'Html + CSS + JavaScript',
    slug: 'youtube-download',
  },
  {
    icon: Facebook,
    title: 'Facebook Downloader',
    description: 'Save your favorite Facebook videos in multiple quality options instantly.',
    url: 'https://bmb-fb-dl-site.vercel.app/',
    tech: 'Htnl + Css + JavaScript',
    slug: 'facebook-download',
  },
  {
    icon: Code,
    title: 'Bmb Movie Web site',
    description: 'Live smarter.',
    url: 'http://movie-site-tz.zone.id/',
    tech: 'Html +Css + JavaScript',
    slug: 'bmb-movie-website',
  },
  {
    icon: Users,
    title: 'Social Media Download',
    description: 'Social Download videos without watermark.',
    url: 'https://bmbtech-site.vercel.app/',
    tech: 'Next.js + Vite + React + Css',
    slug: 'social-media-download',
  },
  {
    icon: Video,
    title: 'TikTok Downloader',
    description: 'Download TikTok videos without watermarks in seconds.',
    url: 'https://bmb-tiktok.vercel.app/',
    tech: 'React + Vite',
    slug: 'tiktok-download',
  },
  {
    icon: Upload,
    title: 'File-to-URL Uploader',
    description: 'Upload files and get shareable URLs instantly. Simple and fast.',
    url: 'https://url.bmbxmd.workers.dev',
    tech: 'Next.js + API',
    slug: 'file-to-url',
  },
  {
    icon: Film,
    title: 'Bmb Tech Ai',
    description: 'Enjoy getting answers from bmb tech ai technology.',
    url: 'https://bmb-ai.vercel.app/',
    tech: 'Next.js + AI',
    slug: 'bmb-tech-ai',
  },
  {
    icon: Globe,
    title: 'Bmb Web site',
    description: 'Extract data from websites efficiently with our powerful scraping tool.',
    url: 'https://bmb-tech-website-code.vercel.app/',
    tech: 'Next.js + API',
    slug: 'bmb-website',
  },
  {
    icon: ImageOff,
    title: 'download APK file',
    description: 'Get to download files that are not available in the Play Store .',
    url: 'https://bmb-apk-site-wine.vercel.app/',
    tech: 'Next.js + AI',
    slug: 'apk-download',
  },
  {
    icon: Film,
    title: 'Bmb Tech Movies',
    description: 'Get all kinds of movies, enjoy life and movies.',
    url: 'https://bmb-movies.vercel.app',
    tech: 'Next.js + Streaming',
    isNew: true,
    slug: 'bmb-movies',
  },
  {
    icon: Contact,
    title: 'VCF Contact',
    description: 'Join the community VCF directory — register your number and get added to the shared contact file.',
    url: 'https://vcf.bmbtech.site',
    tech: 'Next.js + API',
    isNew: true,
    slug: 'vcf-contact',
  },
  {
    icon: Sparkles,
    title: 'More Tools Coming',
    description: 'Exciting new tools are in development. Stay tuned for innovation!',
    isComingSoon: true,
  },
];
