import { useEffect } from 'react';
import { useSearchParams, useNavigate } from 'react-router-dom';

// /signup?ref=CODE — captures the referral code from a shared link, stores
// it locally, then sends the visitor to the Home page. When they sign up
// (Login.tsx, Sign Up tab), the stored code is picked up automatically.
const SignupRedirect = () => {
  const [searchParams] = useSearchParams();
  const navigate = useNavigate();

  useEffect(() => {
    const ref = searchParams.get('ref');
    if (ref) {
      localStorage.setItem('bmb_referral_code', ref);
    }
    navigate('/', { replace: true });
  }, [searchParams, navigate]);

  return null;
};

export default SignupRedirect;
