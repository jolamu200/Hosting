import { useEffect, useRef } from 'react';
import {
  Github, Settings, ShieldCheck, Rocket, Activity, Server, Users,
  Code, Bot as BotIcon, Zap, ArrowRight,
} from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import TechBackground from '@/components/TechBackground';
import HeroLoader from '@/components/HeroLoader';
import Footer from '@/components/Footer';

const steps = [
  {
    icon: Github,
    step: '01',
    title: 'Connect GitHub',
    description: 'Sign in and paste any public bot repo URL, or pick one from our catalog. We read app.json automatically.',
  },
  {
    icon: Settings,
    step: '02',
    title: 'Set env vars & deploy',
    description: 'Configure your session ID and settings in a simple form. Hit Deploy — live build logs stream straight to your browser.',
  },
  {
    icon: ShieldCheck,
    step: '03',
    title: 'Run on autopilot',
    description: 'Your bot runs 24/7 on Bmb Hosting. Pause, resume, view logs, and restart — all from your dashboard.',
  },
];

const features = [
  {
    icon: Github,
    title: 'GitHub-native deploys',
    description: 'Paste any public repo URL or browse our catalog. Auto-reads app.json for env vars. Zero config needed.',
  },
  {
    icon: Activity,
    title: 'Live build logs',
    description: 'Real-time log streaming to your browser as your bot builds. Instant success/fail status, full deploy history.',
  },
  {
    icon: Server,
    title: 'Bot hosting',
    description: 'Every bot runs on managed cloud infrastructure. Pause, resume, and restart with one tap — no server knowledge needed.',
  },
  {
    icon: Users,
    title: 'Community & support',
    description: 'Join the Community Chat to ask questions, share tips, and get help from other bot creators.',
  },
];

const audiences = [
  {
    icon: Code,
    title: 'Developers',
    description: 'Ship your own bots and tools from GitHub in seconds — no server management required.',
  },
  {
    icon: BotIcon,
    title: 'Bot Creators',
    description: 'Deploy WhatsApp bots straight from a repo, with health checks and auto-restarts built in.',
  },
  {
    icon: Zap,
    title: 'Startups',
    description: 'Move fast — get an idea from GitHub to a live bot in minutes, not days.',
  },
];

const Index = () => {
  const navigate = useNavigate();
  const sectionsRef = useRef<(HTMLDivElement | null)[]>([]);

  useEffect(() => {
    const handleScroll = () => {
      sectionsRef.current.forEach((section) => {
        if (!section) return;

        const rect = section.getBoundingClientRect();
        const windowHeight = window.innerHeight;

        if (rect.top < windowHeight * 0.9 && rect.bottom > 0) {
          section.classList.add('animate-in');
        }
      });
    };

    setTimeout(handleScroll, 100);

    window.addEventListener('scroll', handleScroll, { passive: true });
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const setSectionRef = (index: number) => (el: HTMLDivElement | null) => {
    sectionsRef.current[index] = el;
  };

  return (
    <div className="min-h-screen bg-background text-foreground relative" style={{ overflowX: 'hidden', overflowY: 'auto' }}>
      <TechBackground />

      {/* Hero Section - unfolds first */}
      <section id="home" className="relative flex items-center justify-center px-4 pt-16 pb-12 md:min-h-[85vh] md:py-16 animate-unfold">
        <div className="relative z-10">
          <HeroLoader />
        </div>
      </section>

      {/* Deploy in three steps - scroll unfold */}
      <section ref={setSectionRef(0)} className="relative px-4 py-16 scroll-unfold">
        <div className="max-w-4xl mx-auto">
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-bold text-foreground mb-3">Deploy in three steps</h2>
            <p className="text-muted-foreground">No server knowledge needed. If you can paste a URL, you can deploy.</p>
          </div>

          <div className="space-y-8">
            {steps.map((s) => (
              <div key={s.step} className="flex flex-col items-center text-center">
                <div className="w-14 h-14 rounded-full border border-primary/40 bg-primary/10 flex items-center justify-center mb-3">
                  <s.icon className="w-6 h-6 text-primary" />
                </div>
                <p className="text-xs text-muted-foreground font-mono mb-1">{s.step}</p>
                <h3 className="text-lg font-bold text-foreground mb-2">{s.title}</h3>
                <p className="text-sm text-muted-foreground max-w-md leading-relaxed">{s.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Everything you need to ship - scroll unfold */}
      <section ref={setSectionRef(1)} className="relative px-4 py-16 scroll-unfold">
        <div className="max-w-5xl mx-auto">
          <div className="text-center mb-4">
            <p className="text-xs font-bold tracking-widest text-secondary uppercase mb-2">Platform Features</p>
            <h2 className="text-3xl md:text-4xl font-bold text-foreground mb-3">Everything you need to ship</h2>
            <p className="text-muted-foreground">A complete bot hosting platform — not just a deploy button.</p>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 mt-10">
            {features.map((f) => (
              <div key={f.title} className="gradient-border p-6">
                <div className="w-10 h-10 rounded-xl bg-primary/10 border border-primary/30 flex items-center justify-center mb-4">
                  <f.icon className="w-5 h-5 text-primary" />
                </div>
                <h3 className="font-bold text-foreground mb-1.5">{f.title}</h3>
                <p className="text-sm text-muted-foreground leading-relaxed">{f.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Built for teams of every size - scroll unfold */}
      <section className="relative px-4 py-16 scroll-unfold">
        <div className="max-w-5xl mx-auto">
          <div className="text-center mb-10">
            <p className="text-xs font-bold tracking-widest text-secondary uppercase mb-2">Who It's For</p>
            <h2 className="text-3xl md:text-4xl font-bold text-foreground mb-3">Built for builders of every kind</h2>
            <p className="text-muted-foreground">From solo bot creators to growing communities, Bmb Hosting scales with you.</p>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            {audiences.map((a) => (
              <div key={a.title} className="gradient-border p-6">
                <div className="w-10 h-10 rounded-xl bg-secondary/10 border border-secondary/30 flex items-center justify-center mb-4">
                  <a.icon className="w-5 h-5 text-secondary" />
                </div>
                <h3 className="font-bold text-foreground mb-1.5">{a.title}</h3>
                <p className="text-sm text-muted-foreground leading-relaxed">{a.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Ready to go live CTA - scroll unfold */}
      <section ref={setSectionRef(2)} className="relative px-4 py-16 scroll-unfold">
        <div className="max-w-2xl mx-auto text-center gradient-border p-10">
          <h2 className="text-2xl md:text-3xl font-bold text-foreground mb-3">Ready to go live?</h2>
          <p className="text-muted-foreground mb-6">Sign in and deploy your first bot in under a minute.</p>
          <button
            onClick={() => navigate('/my-bots')}
            className="inline-flex items-center gap-2 px-6 py-3 rounded-xl bg-gradient-to-r from-primary to-secondary text-primary-foreground font-semibold hover:opacity-90 transition-opacity"
          >
            Start for free
            <ArrowRight className="w-4 h-4" />
          </button>
        </div>
      </section>

      {/* Footer - scroll unfold */}
      <Footer />
    </div>
  );
};

export default Index;
