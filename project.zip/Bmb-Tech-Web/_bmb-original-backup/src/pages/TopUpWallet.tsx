import { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Wallet, ChevronRight, Coins, ArrowUpRight, Loader2 } from 'lucide-react';
import TechBackground from '@/components/TechBackground';
import FloatingMenu from '@/components/FloatingMenu';
import BackButton from '@/components/BackButton';
import Footer from '@/components/Footer';
import { topupCountries } from '@/data/topupCountries';
import { supabase } from '@/lib/supabaseClient';
import { useAuth } from '@/context/AuthContext';

// Gradient per country card — purely cosmetic, matches the reference design.
const cardGradients: Record<string, string> = {
  tanzania: 'from-cyan-500 to-teal-400',
  kenya: 'from-emerald-500 to-green-400',
  nigeria: 'from-green-600 to-lime-500',
  cameroon: 'from-amber-500 to-red-500',
  worldwide: 'from-indigo-500 to-purple-500',
};

interface RecentTopup {
  id: string;
  coins: number;
  amount: number;
  currency: string;
  status: string;
  created_at: string;
}

const TopUpWallet = () => {
  const navigate = useNavigate();
  const { user } = useAuth();
  const [balance, setBalance] = useState(0);
  const [recent, setRecent] = useState<RecentTopup[]>([]);
  const [loadingWallet, setLoadingWallet] = useState(true);

  useEffect(() => {
    const load = async () => {
      if (!user) return;
      setLoadingWallet(true);

      const [{ data: profile }, { data: topups }] = await Promise.all([
        supabase.from('profiles').select('ph_balance').eq('id', user.id).single(),
        supabase
          .from('coin_topups')
          .select('id, coins, amount, currency, status, created_at')
          .eq('user_id', user.id)
          .order('created_at', { ascending: false })
          .limit(5),
      ]);

      setBalance(profile?.ph_balance || 0);
      setRecent(topups || []);
      setLoadingWallet(false);
    };
    load();
  }, [user]);

  const formatDate = (iso: string) =>
    new Date(iso).toLocaleDateString(undefined, { month: 'short', day: 'numeric' });

  return (
    <div className="min-h-screen bg-background text-foreground relative">
      <TechBackground />
      <FloatingMenu />

      <div className="relative z-10 max-w-xl mx-auto px-4 pt-24 pb-16">
        <BackButton className="mb-4" />

        <div className="flex flex-col items-center text-center mb-6">
          <div className="w-16 h-16 rounded-2xl bg-primary/10 border border-primary/40 flex items-center justify-center mb-4">
            <Wallet className="w-8 h-8 text-primary" />
          </div>
          <h1 className="text-2xl font-bold text-foreground mb-1">Top Up Wallet</h1>
          <p className="text-sm text-muted-foreground">
            Choose your country — or pay with Visa / Mastercard worldwide
          </p>
        </div>

        {/* Balance + what you've paid so far */}
        <div className="gradient-border p-5 mb-8 bg-gradient-to-br from-primary/10 to-secondary/10">
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center gap-3">
              <div className="w-11 h-11 rounded-xl bg-gradient-to-br from-primary to-secondary flex items-center justify-center shrink-0">
                <Coins className="w-5 h-5 text-primary-foreground" />
              </div>
              <div>
                <p className="text-2xl font-bold text-foreground leading-none">{balance}</p>
                <p className="text-xs text-muted-foreground mt-1">Coins balance</p>
              </div>
            </div>
          </div>

          {loadingWallet ? (
            <div className="flex items-center justify-center gap-2 py-4 text-xs text-muted-foreground">
              <Loader2 className="w-3.5 h-3.5 animate-spin" />
              Loading your top-ups...
            </div>
          ) : recent.length > 0 ? (
            <div className="border-t border-border/40 pt-3 space-y-2.5">
              <p className="text-[11px] font-semibold text-muted-foreground uppercase tracking-wide">Recent top-ups</p>
              {recent.map((t) => (
                <div key={t.id} className="flex items-center justify-between text-xs">
                  <div className="flex items-center gap-2">
                    <ArrowUpRight className={`w-3.5 h-3.5 ${t.status === 'completed' ? 'text-success' : t.status === 'failed' ? 'text-destructive' : 'text-warning'}`} />
                    <span className="text-foreground">{formatDate(t.created_at)}</span>
                    <span className="text-muted-foreground capitalize">· {t.status}</span>
                  </div>
                  <span className={`font-semibold ${t.status === 'completed' ? 'text-success' : 'text-muted-foreground'}`}>
                    +{t.coins} coins
                  </span>
                </div>
              ))}
            </div>
          ) : (
            <p className="border-t border-border/40 pt-3 text-xs text-muted-foreground">
              No top-ups yet — pick a country below to get started.
            </p>
          )}
        </div>

        <div className="space-y-4">
          {topupCountries.map((country) => (
            <div key={country.code} className="gradient-border p-5">
              <button
                onClick={() => navigate(`/topup/${country.code}`)}
                className="w-full flex items-center justify-between gap-3 mb-3"
              >
                <div className="flex items-center gap-3 text-left">
                  <span className="text-3xl leading-none">{country.flagEmoji}</span>
                  <div>
                    <p className="font-bold text-foreground">{country.name}</p>
                    <p className="text-xs text-muted-foreground">
                      {country.currency} · {country.methodLabels.length > 0 ? 'Mobile · Card' : ''}
                    </p>
                  </div>
                </div>
                <ChevronRight className="w-5 h-5 text-muted-foreground shrink-0" />
              </button>

              <div className="flex flex-wrap gap-1.5 mb-4">
                {country.methodLabels.map((m) => (
                  <span
                    key={m}
                    className="text-[11px] px-2.5 py-1 rounded-full bg-muted/40 text-muted-foreground"
                  >
                    {m}
                  </span>
                ))}
              </div>

              <button
                onClick={() => navigate(`/topup/${country.code}`)}
                className={`w-full py-3 rounded-xl bg-gradient-to-r ${cardGradients[country.code] || 'from-primary to-secondary'} text-white text-sm font-bold`}
              >
                Select {country.name} →
              </button>
            </div>
          ))}
        </div>

        <p className="text-center text-xs text-muted-foreground mt-8">
          Coins are credited to your Bmb Tech wallet within minutes after payment confirmation.
        </p>
      </div>
      <Footer />
    </div>
  );
};

export default TopUpWallet;
