import { useState } from 'react';
import { Loader2, Send, CheckCircle2 } from 'lucide-react';
import { supabase } from '@/lib/supabaseClient';
import { useAuth } from '@/context/AuthContext';
import FloatingMenu from '@/components/FloatingMenu';
import TechBackground from '@/components/TechBackground';
import BackButton from '@/components/BackButton';
import Footer from '@/components/Footer';

const RequestBot = () => {
  const { user } = useAuth();

  const [repoUrl, setRepoUrl] = useState('');
  const [pairCodeUrl, setPairCodeUrl] = useState('');
  const [repoName, setRepoName] = useState('');
  const [description, setDescription] = useState('');
  const [reason, setReason] = useState('');

  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState('');
  const [submitted, setSubmitted] = useState(false);

  const handleSubmit = async () => {
    setError('');

    if (!repoUrl.trim() || !pairCodeUrl.trim()) {
      setError('The GitHub repository link and pair code link are both required.');
      return;
    }
    if (!user) {
      setError('You need to be signed in to request a bot.');
      return;
    }

    setSubmitting(true);
    const { error: insertError } = await supabase.from('bot_requests').insert({
      user_id: user.id,
      repo_url: repoUrl.trim(),
      pair_code_url: pairCodeUrl.trim(),
      repo_name: repoName.trim() || null,
      description: description.trim() || null,
      reason: reason.trim() || null,
    });
    setSubmitting(false);

    if (insertError) {
      setError('Failed to submit your request: ' + insertError.message);
      return;
    }

    setSubmitted(true);
  };

  return (
    <div className="min-h-screen bg-background text-foreground relative">
      <TechBackground />
      <FloatingMenu />

      <div className="relative z-10 max-w-xl mx-auto px-4 py-20">
        <BackButton className="mb-4" />
        <div className="mb-6">
          <h1 className="text-2xl md:text-3xl font-bold text-foreground mb-1">Request a Bot</h1>
          <p className="text-sm text-muted-foreground">
            Know a great WhatsApp bot repo? Submit it below — the admin will review and add it to
            the catalog if approved.
          </p>
        </div>

        {submitted ? (
          <div className="gradient-border p-6 text-center space-y-3">
            <CheckCircle2 className="w-10 h-10 text-success mx-auto" />
            <p className="font-semibold text-foreground">Request submitted</p>
            <p className="text-sm text-muted-foreground">
              Thanks — the admin will review your submission and get back to you.
            </p>
          </div>
        ) : (
          <div className="gradient-border p-5 space-y-4">
            {error && (
              <div className="px-4 py-3 rounded-xl bg-destructive/10 border border-destructive/40 text-destructive text-sm">
                {error}
              </div>
            )}

            <div>
              <label className="text-xs font-semibold text-muted-foreground tracking-wide uppercase mb-1.5 block">
                GitHub Repository URL *
              </label>
              <input
                type="text"
                value={repoUrl}
                onChange={(e) => setRepoUrl(e.target.value)}
                placeholder="https://github.com/user/repo"
                className="w-full px-3 py-2.5 rounded-lg bg-background/50 border border-border/60 text-foreground text-sm placeholder:text-muted-foreground focus:outline-none focus:border-primary/60 transition-colors"
              />
            </div>

            <div>
              <label className="text-xs font-semibold text-muted-foreground tracking-wide uppercase mb-1.5 block">
                Pair Code URL *
              </label>
              <input
                type="text"
                value={pairCodeUrl}
                onChange={(e) => setPairCodeUrl(e.target.value)}
                placeholder="https://example.com/pair-code"
                className="w-full px-3 py-2.5 rounded-lg bg-background/50 border border-border/60 text-foreground text-sm placeholder:text-muted-foreground focus:outline-none focus:border-primary/60 transition-colors"
              />
              <p className="text-xs text-muted-foreground mt-1">
                Link where users can generate their pair code for this bot
              </p>
            </div>

            <div>
              <label className="text-xs font-semibold text-muted-foreground tracking-wide uppercase mb-1.5 block">
                Repository Name
              </label>
              <input
                type="text"
                value={repoName}
                onChange={(e) => setRepoName(e.target.value)}
                placeholder="e.g. My Awesome Bot"
                className="w-full px-3 py-2.5 rounded-lg bg-background/50 border border-border/60 text-foreground text-sm placeholder:text-muted-foreground focus:outline-none focus:border-primary/60 transition-colors"
              />
            </div>

            <div>
              <label className="text-xs font-semibold text-muted-foreground tracking-wide uppercase mb-1.5 block">
                Description
              </label>
              <input
                type="text"
                value={description}
                onChange={(e) => setDescription(e.target.value)}
                placeholder="Brief description of what this bot does"
                className="w-full px-3 py-2.5 rounded-lg bg-background/50 border border-border/60 text-foreground text-sm placeholder:text-muted-foreground focus:outline-none focus:border-primary/60 transition-colors"
              />
            </div>

            <div>
              <label className="text-xs font-semibold text-muted-foreground tracking-wide uppercase mb-1.5 block">
                Reason for Suggestion
              </label>
              <input
                type="text"
                value={reason}
                onChange={(e) => setReason(e.target.value)}
                placeholder="Why should this bot be added?"
                className="w-full px-3 py-2.5 rounded-lg bg-background/50 border border-border/60 text-foreground text-sm placeholder:text-muted-foreground focus:outline-none focus:border-primary/60 transition-colors"
              />
            </div>

            <button
              onClick={handleSubmit}
              disabled={submitting}
              className="w-full flex items-center justify-center gap-2 py-3 rounded-xl bg-gradient-to-r from-primary to-secondary text-primary-foreground font-semibold hover:opacity-90 transition-opacity disabled:opacity-50"
            >
              {submitting ? <Loader2 className="w-4 h-4 animate-spin" /> : <Send className="w-4 h-4" />}
              Submit Request
            </button>
          </div>
        )}
      </div>
      <Footer />
    </div>
  );
};

export default RequestBot;
