import { useState } from 'react';
import PlatformLoading from '@/components/PlatformLoading';
import DiscoverApps from './DiscoverApps';

// Shows the branded "initializing platform" loading screen for a few
// seconds before revealing the Discover Apps search page.
const DiscoverAppsGate = () => {
  const [ready, setReady] = useState(false);

  if (!ready) {
    return <PlatformLoading onDone={() => setReady(true)} />;
  }

  return <DiscoverApps />;
};

export default DiscoverAppsGate;
