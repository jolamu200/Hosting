import { useNavigate } from 'react-router-dom';
import { ArrowLeft, Newspaper } from 'lucide-react';
import TechBackground from '@/components/TechBackground';
import Footer from '@/components/Footer';

const posts = [
  {
    title: 'Welcome to the Bmb Tech Blog',
    tag: 'NEWS',
    date: 'August 2026',
    author: 'Bmb Tech Team',
    excerpt:
      "This is where we'll share platform updates, new features, and behind-the-scenes notes on building Bmb Tech Hosting.",
  },
];

const Blog = () => {
  const navigate = useNavigate();

  return (
    <div className="min-h-screen bg-background text-foreground relative">
      <TechBackground />

      <div className="relative z-10 max-w-3xl mx-auto px-4 py-8">
        <button
          onClick={() => navigate(-1)}
          className="flex items-center gap-2 text-sm text-muted-foreground hover:text-foreground transition-colors mb-6"
        >
          <ArrowLeft className="w-4 h-4" />
          Back
        </button>

        <div className="rounded-2xl bg-gradient-to-r from-primary to-secondary p-8 mb-10 text-center">
          <p className="flex items-center justify-center gap-2 text-primary-foreground/80 text-sm font-semibold tracking-widest uppercase mb-2">
            <Newspaper className="w-4 h-4" />
            Bmb Tech Blog
          </p>
          <h1 className="text-2xl md:text-3xl font-bold text-primary-foreground">
            Updates, engineering notes, and platform news
          </h1>
        </div>

        <div className="space-y-6">
          {posts.map((post) => (
            <article key={post.title} className="gradient-border p-6">
              <h2 className="text-lg font-bold text-foreground mb-2">{post.title}</h2>
              <p className="text-xs text-muted-foreground mb-3">
                <span className="px-2 py-0.5 rounded-full bg-primary/10 text-primary font-semibold mr-2">
                  {post.tag}
                </span>
                {post.date} · {post.author}
              </p>
              <p className="text-sm text-muted-foreground leading-relaxed">{post.excerpt}</p>
            </article>
          ))}
        </div>
      </div>

      <Footer />
    </div>
  );
};

export default Blog;
