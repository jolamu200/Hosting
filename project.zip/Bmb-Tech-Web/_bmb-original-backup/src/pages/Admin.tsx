import { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Loader2, Inbox, MessageSquare, Bot as BotIcon, Users, KeyRound, Server } from 'lucide-react';
import { supabase } from '@/lib/supabaseClient';
import { isAdminLoggedIn } from '@/lib/adminAuth';
import { useAuth } from '@/context/AuthContext';
import TechBackground from '@/components/TechBackground';
import AdminBotList from '@/components/AdminBotList';
import AdminBotDeployments from '@/components/AdminBotDeployments';
import AdminMessageCard from '@/components/AdminMessageCard';
import AdminUsers from '@/components/AdminUsers';
import AdminApiKeys from '@/components/AdminApiKeys';
import BackButton from '@/components/BackButton';

interface ContactMessage {
  id: string;
  name: string;
  email: string | null;
  phone: string | null;
  message: string;
  created_at: string;
}

const Admin = () => {
  const navigate = useNavigate();
  const { user, loading: authLoading } = useAuth();
  const [tab, setTab] = useState<'messages' | 'bots' | 'deployments' | 'users' | 'api_keys'>('messages');
  const [messages, setMessages] = useState<ContactMessage[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [checkingAccess, setCheckingAccess] = useState(true);
  const [hasAccess, setHasAccess] = useState(false);

  useEffect(() => {
    // Two ways in: the password-based admin session (unrelated to any
    // account), or being logged in as the site Owner.
    if (isAdminLoggedIn()) {
      setHasAccess(true);
      setCheckingAccess(false);
      return;
    }

    if (authLoading) return; // wait for the auth session to resolve

    if (!user) {
      navigate('/');
      return;
    }

    supabase
      .from('profiles')
      .select('role')
      .eq('id', user.id)
      .single()
      .then(({ data }) => {
        if (data?.role === 'owner') {
          setHasAccess(true);
        } else {
          navigate('/');
        }
        setCheckingAccess(false);
      });
  }, [user, authLoading, navigate]);

  useEffect(() => {
    if (!hasAccess) return;

    const loadMessages = async () => {
      const { data, error: fetchError } = await supabase
        .from('contact_messages')
        .select('id, name, email, phone, message, created_at')
        .order('created_at', { ascending: false });

      if (fetchError) {
        setError('Failed to load messages: ' + fetchError.message);
      } else {
        setMessages(data || []);
      }
      setLoading(false);
    };

    loadMessages();
  }, [hasAccess]);

  if (checkingAccess) {
    return (
      <div className="min-h-screen bg-background text-foreground relative flex items-center justify-center">
        <TechBackground />
        <p className="relative z-10 text-muted-foreground text-sm font-mono tracking-widest">
          CHECKING ACCESS...
        </p>
      </div>
    );
  }

  if (!hasAccess) return null;

  return (
    <div className="min-h-screen bg-background text-foreground relative">
      <TechBackground />

      <div className="relative z-10 max-w-4xl mx-auto px-4 py-10">
        <BackButton className="mb-4" fallback="/" />
        <div className="flex items-center justify-between mb-6">
          <div>
            <p className="text-primary font-mono text-xs tracking-widest mb-1">ADMIN</p>
            <h1 className="text-2xl md:text-3xl font-bold gradient-text tracking-wider">
              Dashboard
            </h1>
          </div>
        </div>

        {/* Tabs */}
        <div className="flex gap-2 mb-6 border-b border-border/50 overflow-x-auto scrollbar-none">
          <button
            onClick={() => setTab('messages')}
            className={`flex items-center gap-2 px-4 py-3 text-sm font-medium border-b-2 transition-colors shrink-0 whitespace-nowrap ${
              tab === 'messages'
                ? 'border-primary text-primary'
                : 'border-transparent text-muted-foreground hover:text-foreground'
            }`}
          >
            <MessageSquare className="w-4 h-4" />
            Messages
          </button>
          <button
            onClick={() => setTab('bots')}
            className={`flex items-center gap-2 px-4 py-3 text-sm font-medium border-b-2 transition-colors shrink-0 whitespace-nowrap ${
              tab === 'bots'
                ? 'border-primary text-primary'
                : 'border-transparent text-muted-foreground hover:text-foreground'
            }`}
          >
            <BotIcon className="w-4 h-4" />
            Bots
          </button>
          <button
            onClick={() => setTab('deployments')}
            className={`flex items-center gap-2 px-4 py-3 text-sm font-medium border-b-2 transition-colors shrink-0 whitespace-nowrap ${
              tab === 'deployments'
                ? 'border-primary text-primary'
                : 'border-transparent text-muted-foreground hover:text-foreground'
            }`}
          >
            <Server className="w-4 h-4" />
            Deployments
          </button>
          <button
            onClick={() => setTab('users')}
            className={`flex items-center gap-2 px-4 py-3 text-sm font-medium border-b-2 transition-colors shrink-0 whitespace-nowrap ${
              tab === 'users'
                ? 'border-primary text-primary'
                : 'border-transparent text-muted-foreground hover:text-foreground'
            }`}
          >
            <Users className="w-4 h-4" />
            Users
          </button>
          <button
            onClick={() => setTab('api_keys')}
            className={`flex items-center gap-2 px-4 py-3 text-sm font-medium border-b-2 transition-colors shrink-0 whitespace-nowrap ${
              tab === 'api_keys'
                ? 'border-primary text-primary'
                : 'border-transparent text-muted-foreground hover:text-foreground'
            }`}
          >
            <KeyRound className="w-4 h-4" />
            API Keys
          </button>
        </div>

        {tab === 'messages' && (
          <>
            {loading && (
              <div className="flex items-center justify-center gap-2 py-20 text-muted-foreground">
                <Loader2 className="w-5 h-5 animate-spin" />
                Loading messages...
              </div>
            )}

            {error && (
              <div className="px-4 py-3 rounded-xl bg-destructive/10 border border-destructive/40 text-destructive text-sm mb-4">
                {error}
              </div>
            )}

            {!loading && !error && messages.length === 0 && (
              <div className="flex flex-col items-center justify-center gap-3 py-20 text-center">
                <Inbox className="w-10 h-10 text-muted-foreground" />
                <p className="text-muted-foreground">No messages yet.</p>
              </div>
            )}

            <div className="space-y-4">
              {messages.map((msg) => (
                <AdminMessageCard
                  key={msg.id}
                  message={msg}
                  onDeleted={(id) => setMessages(prev => prev.filter(m => m.id !== id))}
                  onUpdated={(updated) => setMessages(prev => prev.map(m => m.id === updated.id ? updated : m))}
                />
              ))}
            </div>
          </>
        )}

        {tab === 'bots' && (
          <div>
            <h2 className="text-sm font-semibold text-muted-foreground tracking-wide uppercase mb-3">
              Bot Catalog
            </h2>
            <AdminBotList />
          </div>
        )}

        {tab === 'deployments' && <AdminBotDeployments />}

        {tab === 'users' && <AdminUsers />}

        {tab === 'api_keys' && <AdminApiKeys />}
      </div>
    </div>
  );
};

export default Admin;
