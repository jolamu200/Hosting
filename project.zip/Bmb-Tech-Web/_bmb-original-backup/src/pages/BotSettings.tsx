import { useEffect, useState, useRef, useCallback } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import {
  Loader2, Trash2, X, AlertCircle,
  CheckCircle2, Pencil, RefreshCw, Pause, Play,
  Copy, Check, Github, MoreVertical,
  LayoutGrid, Sliders, Upload, Activity as ActivityIcon,
  Clock, Users, Settings as SettingsIcon,
} from 'lucide-react';
import { supabase } from '@/lib/supabaseClient';
import { useAuth } from '@/context/AuthContext';
import FloatingMenu from '@/components/FloatingMenu';
import TechBackground from '@/components/TechBackground';
import BackButton from '@/components/BackButton';
import Footer from '@/components/Footer';

interface DeployedApp {
  id: string;
  bot_id: string | null;
  bot_name: string;
  heroku_app_name: string;
  app_url: string | null;
  status: string;
  build_id: string | null;
  env_vars: Record<string, string> | null;
  repo_full_name: string | null;
  auto_deploy_enabled: boolean;
  auto_deploy_branch: string | null;
  created_at: string;
}

interface ActivityRow {
  id: string;
  action: string;
  detail: string | null;
  created_at: string;
}

const LOG_LINE_OPTIONS = [50, 100, 200];
const TABS = [
  { key: 'overview', label: 'Overview', icon: LayoutGrid },
  { key: 'resources', label: 'Resources', icon: Sliders },
  { key: 'deploy', label: 'Deploy', icon: Upload },
  { key: 'metrics', label: 'Metrics', icon: ActivityIcon },
  { key: 'activity', label: 'Activity', icon: Clock },
  { key: 'access', label: 'Access', icon: Users },
  { key: 'settings', label: 'Settings', icon: SettingsIcon },
] as const;

type TabKey = typeof TABS[number]['key'];

const BotSettings = () => {
  const { appId } = useParams();
  const navigate = useNavigate();
  const { user } = useAuth();

  const [app, setApp] = useState<DeployedApp | null>(null);
  const [loading, setLoading] = useState(true);
  const [liveState, setLiveState] = useState<'active' | 'inactive' | null>(null);
  const [tab, setTab] = useState<TabKey>('overview');
  const [moreOpen, setMoreOpen] = useState(false);

  const [togglingDyno, setTogglingDyno] = useState(false);
  const [restarting, setRestarting] = useState(false);
  const [restartedFlash, setRestartedFlash] = useState(false);
  const [actionError, setActionError] = useState('');

  // Logs
  const [logsText, setLogsText] = useState('');
  const [logsLoading, setLogsLoading] = useState(false);
  const [logLines, setLogLines] = useState(50);
  const [autoRefresh, setAutoRefresh] = useState(true);
  const [logsCopied, setLogsCopied] = useState(false);
  const logsIntervalRef = useRef<ReturnType<typeof setInterval> | null>(null);

  // Edit / config
  const [editAppName, setEditAppName] = useState('');
  const [editEnvValues, setEditEnvValues] = useState<Record<string, string>>({});
  const [editSaving, setEditSaving] = useState(false);
  const [editError, setEditError] = useState('');
  const [editSuccess, setEditSuccess] = useState('');
  const [configRevealed, setConfigRevealed] = useState(false);

  // Auto Deploy / GitHub connect
  const [githubConnected, setGithubConnected] = useState<boolean | null>(null);
  const [githubLogin, setGithubLogin] = useState<string | null>(null);
  const [disconnectingAccount, setDisconnectingAccount] = useState(false);
  const [repoSearch, setRepoSearch] = useState('');
  const [repoResults, setRepoResults] = useState<{ fullName: string; name: string; private: boolean }[]>([]);
  const [reposLoading, setReposLoading] = useState(false);
  const [connectingRepo, setConnectingRepo] = useState<string | null>(null);
  const [autoDeployToggling, setAutoDeployToggling] = useState(false);
  const [autoDeployBranch, setAutoDeployBranch] = useState('main');

  // Activity feed (recorded locally — Heroku's own activity log isn't
  // exposed to third-party apps, so this reflects actions taken from here)
  const [activity, setActivity] = useState<ActivityRow[]>([]);

  // Delete
  const [deleteConfirmInput, setDeleteConfirmInput] = useState('');
  const [deleting, setDeleting] = useState(false);
  const [deleteError, setDeleteError] = useState('');
  const [showDeleteConfirm, setShowDeleteConfirm] = useState(false);

  const loadApp = useCallback(async () => {
    if (!user || !appId) return;

    // Reset everything tied to the previous bot first — without this,
    // navigating from one bot's settings page straight to another's (e.g.
    // via the back button and a different bot) could briefly, or
    // persistently if a fetch below fails, show the previous bot's
    // repo/auto-deploy state as if it belonged to the new one.
    setApp(null);
    setLiveState(null);
    setGithubConnected(null);
    setRepoResults([]);
    setActivity([]);
    setTab('overview');

    setLoading(true);
    const { data } = await supabase
      .from('deployed_apps')
      .select('id, bot_id, bot_name, heroku_app_name, app_url, status, build_id, env_vars, repo_full_name, auto_deploy_enabled, auto_deploy_branch, created_at')
      .eq('id', appId)
      .eq('user_id', user.id)
      .maybeSingle();

    setApp(data);
    setLoading(false);

    if (data?.status === 'live') {
      try {
        const res = await fetch(`/api/heroku-dyno?appName=${data.heroku_app_name}`);
        const info = await res.json();
        if (res.ok) setLiveState(info.state === 'up' ? 'active' : 'inactive');
      } catch {
        // leave unknown
      }
    }
  }, [user, appId]);

  useEffect(() => {
    loadApp();
  }, [loadApp]);

  useEffect(() => {
    if (!appId) return;
    supabase
      .from('bot_activity')
      .select('id, action, detail, created_at')
      .eq('deployed_app_id', appId)
      .order('created_at', { ascending: false })
      .limit(30)
      .then(({ data }) => setActivity(data || []));
  }, [appId]);

  const logActivity = async (action: string, detail?: string) => {
    if (!appId) return;
    const { data } = await supabase
      .from('bot_activity')
      .insert({ deployed_app_id: appId, action, detail: detail || null })
      .select('id, action, detail, created_at')
      .single();
    if (data) setActivity(prev => [data, ...prev]);
  };

  // ---------------- Dyno actions ----------------
  const handleToggleDyno = async () => {
    if (!app) return;
    const action = liveState === 'inactive' ? 'resume' : 'pause';
    setTogglingDyno(true);
    setActionError('');

    try {
      const res = await fetch('/api/heroku-dyno', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ appName: app.heroku_app_name, action }),
      });
      const data = await res.json();
      if (res.ok) {
        setLiveState(data.state === 'up' ? 'active' : 'inactive');
        logActivity(action === 'pause' ? 'Paused' : 'Resumed');
      } else {
        setActionError(data.error || 'Failed to update dyno state.');
      }
    } catch {
      setActionError('Failed to update dyno state.');
    }
    setTogglingDyno(false);
  };

  const handleRestart = async () => {
    if (!app) return;
    setRestarting(true);
    setActionError('');

    try {
      const res = await fetch('/api/heroku-dyno', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ appName: app.heroku_app_name, action: 'restart' }),
      });
      const data = await res.json();
      if (res.ok) {
        setLiveState('active');
        setRestartedFlash(true);
        setTimeout(() => setRestartedFlash(false), 2500);
        logActivity('Restarted all dynos');
      } else {
        setActionError(data.error || 'Failed to restart the bot.');
      }
    } catch {
      setActionError('Failed to restart the bot.');
    }
    setRestarting(false);
    setMoreOpen(false);
  };

  // ---------------- Logs ----------------
  const fetchLogs = useCallback(async (lines: number) => {
    if (!app) return;
    setLogsLoading(true);
    try {
      const res = await fetch(`/api/heroku-app-logs?appName=${app.heroku_app_name}&lines=${lines}`);
      const data = await res.json();
      setLogsText(res.ok ? data.logs : data.error || 'Failed to load logs.');
    } catch (err: any) {
      setLogsText(err.message || 'Failed to load logs.');
    }
    setLogsLoading(false);
  }, [app]);

  useEffect(() => {
    if (tab !== 'overview' || !app) return;
    fetchLogs(logLines);
  }, [tab, app, logLines, fetchLogs]);

  useEffect(() => {
    if (logsIntervalRef.current) clearInterval(logsIntervalRef.current);
    if (tab === 'overview' && autoRefresh && app) {
      logsIntervalRef.current = setInterval(() => fetchLogs(logLines), 5000);
    }
    return () => {
      if (logsIntervalRef.current) clearInterval(logsIntervalRef.current);
    };
  }, [tab, autoRefresh, logLines, app, fetchLogs]);

  const handleCopyLogs = () => {
    if (!logsText) return;
    navigator.clipboard.writeText(logsText).then(() => {
      setLogsCopied(true);
      setTimeout(() => setLogsCopied(false), 2000);
    });
  };

  // ---------------- Edit / config vars ----------------
  useEffect(() => {
    if (app) {
      setEditAppName(app.heroku_app_name);
      setEditEnvValues(app.env_vars || {});
    }
  }, [app]);

  const handleSaveConfig = async () => {
    if (!app) return;
    setEditSaving(true);
    setEditError('');
    setEditSuccess('');

    try {
      const res = await fetch('/api/heroku-update-config', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ appName: app.heroku_app_name, envVars: editEnvValues }),
      });
      const data = await res.json();

      if (!res.ok) {
        setEditError(data.error || 'Failed to update config vars.');
      } else {
        await supabase.from('deployed_apps').update({ env_vars: editEnvValues }).eq('id', app.id);
        setApp(prev => (prev ? { ...prev, env_vars: editEnvValues } : prev));
        setEditSuccess('Config vars updated — the bot restarted automatically.');
        logActivity('Updated config vars');
      }
    } catch (err: any) {
      setEditError(err.message || 'Failed to update config vars.');
    }
    setEditSaving(false);
  };

  // ---------------- Auto Deploy / GitHub connect ----------------
  const checkGithubConnection = useCallback(async () => {
    if (!user) return;
    try {
      const res = await fetch(`/api/github-auto-deploy?step=repos&userId=${user.id}`);
      if (res.status === 404) {
        setGithubConnected(false);
        return;
      }
      const data = await res.json();
      if (res.ok) {
        setGithubConnected(true);
        setRepoResults(data.repos || []);
        setGithubLogin(data.githubLogin || null);
      } else {
        setGithubConnected(false);
      }
    } catch {
      setGithubConnected(false);
    }
  }, [user]);

  useEffect(() => {
    if (tab === 'deploy') {
      setAutoDeployBranch(app?.auto_deploy_branch || 'main');
      checkGithubConnection();
    }
  }, [tab, app, checkGithubConnection]);

  const handleConnectGithub = () => {
    if (!user || !app) return;
    window.location.href = `/api/github-auto-deploy?step=start&userId=${user.id}`;
  };

  const handleDisconnectAccount = async () => {
    if (!user) return;
    setDisconnectingAccount(true);
    try {
      const res = await fetch('/api/github-auto-deploy?step=disconnect-account', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ userId: user.id }),
      });
      if (res.ok) {
        setGithubConnected(false);
        setGithubLogin(null);
        setRepoResults([]);
        setApp(prev => (prev ? { ...prev, repo_full_name: null, auto_deploy_enabled: false } : prev));
      }
    } catch {
      // best-effort
    }
    setDisconnectingAccount(false);
  };

  const searchRepos = async (query: string) => {
    if (!user) return;
    setReposLoading(true);
    try {
      const res = await fetch(`/api/github-auto-deploy?step=repos&userId=${user.id}&q=${encodeURIComponent(query)}`);
      const data = await res.json();
      if (res.ok) setRepoResults(data.repos || []);
    } catch {
      // best-effort
    }
    setReposLoading(false);
  };

  const handleConnectRepo = async (repoFullName: string) => {
    if (!user || !app) return;
    setConnectingRepo(repoFullName);
    setActionError('');

    try {
      const res = await fetch('/api/github-auto-deploy?step=connect', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ userId: user.id, appId: app.id, repoFullName, branch: autoDeployBranch }),
      });
      const data = await res.json();

      if (!res.ok) {
        setActionError(data.error || 'Failed to connect this repo.');
      } else {
        setApp(prev => (prev ? { ...prev, repo_full_name: repoFullName, auto_deploy_enabled: true, auto_deploy_branch: autoDeployBranch } : prev));
        logActivity('Connected to GitHub', repoFullName);
      }
    } catch {
      setActionError('Failed to connect this repo.');
    }
    setConnectingRepo(null);
  };

  const handleDisableAutoDeploy = async () => {
    if (!user || !app) return;
    setAutoDeployToggling(true);
    setActionError('');

    try {
      const res = await fetch('/api/github-auto-deploy?step=connect', {
        method: 'DELETE',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ userId: user.id, appId: app.id }),
      });
      const data = await res.json();

      if (!res.ok) {
        setActionError(data.error || 'Failed to disable auto deploy.');
      } else {
        setApp(prev => (prev ? { ...prev, auto_deploy_enabled: false } : prev));
        logActivity('Disabled automatic deploys');
      }
    } catch {
      setActionError('Failed to disable auto deploy.');
    }
    setAutoDeployToggling(false);
  };

  const handleDisconnectRepo = async () => {
    if (!user || !app) return;
    setAutoDeployToggling(true);
    setActionError('');

    try {
      // Same endpoint as disabling auto-deploy — it already removes the
      // webhook and clears auto_deploy_enabled. We additionally clear
      // repo_full_name here so the UI goes all the way back to "not
      // connected" for this bot, matching Heroku's own "Disconnect...".
      const res = await fetch('/api/github-auto-deploy?step=connect', {
        method: 'DELETE',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ userId: user.id, appId: app.id }),
      });
      const data = await res.json();

      if (!res.ok) {
        setActionError(data.error || 'Failed to disconnect this repo.');
      } else {
        await supabase.from('deployed_apps').update({ repo_full_name: null }).eq('id', app.id);
        setApp(prev => (prev ? { ...prev, repo_full_name: null, auto_deploy_enabled: false } : prev));
        logActivity('Disconnected from GitHub');
      }
    } catch {
      setActionError('Failed to disconnect this repo.');
    }
    setAutoDeployToggling(false);
  };

  // ---------------- Delete ----------------
  const handleDelete = async () => {
    if (!app) return;
    setDeleting(true);
    setDeleteError('');

    try {
      const res = await fetch('/api/heroku-app-manage', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ action: 'delete', appName: app.heroku_app_name }),
      });
      const data = await res.json();

      if (!res.ok) {
        setDeleteError(data.error || 'Failed to delete the bot.');
      } else {
        await supabase.from('deployed_apps').delete().eq('id', app.id);
        navigate('/my-bots');
      }
    } catch (err: any) {
      setDeleteError(err.message || 'Failed to delete the bot.');
    }
    setDeleting(false);
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <Loader2 className="w-6 h-6 animate-spin text-primary" />
      </div>
    );
  }

  if (!app) {
    return (
      <div className="min-h-screen bg-background text-foreground relative">
        <TechBackground />
        <FloatingMenu />
        <div className="relative z-10 max-w-2xl mx-auto px-4 py-20 text-center">
          <BackButton className="mb-4" />
          <p className="text-muted-foreground">Bot not found.</p>
        </div>
        <Footer />
      </div>
    );
  }

  const statusColor = liveState === 'inactive' ? 'text-warning' : app.status === 'live' ? 'text-success' : app.status === 'failed' ? 'text-destructive' : 'text-muted-foreground';

  return (
    <div className="min-h-screen bg-background text-foreground relative">
      <TechBackground />
      <FloatingMenu />

      <div className="relative z-10 max-w-3xl mx-auto px-4 py-20">
        <BackButton className="mb-4" fallback="/my-bots" />

        {/* App header — mirrors Heroku's own app header */}
        <div className="gradient-border p-4 mb-4">
          <div className="flex items-start justify-between gap-3 mb-1">
            <div className="min-w-0">
              <p className="text-[11px] text-muted-foreground font-mono tracking-widest uppercase mb-1">Bmb Hosting</p>
              <h1 className="text-xl font-bold text-foreground truncate">{app.heroku_app_name}</h1>
              {app.repo_full_name && (
                <p className="flex items-center gap-1.5 text-xs text-muted-foreground mt-1">
                  <Github className="w-3.5 h-3.5" />
                  {app.repo_full_name}
                </p>
              )}
            </div>
            <div className="flex items-center gap-2 shrink-0">
              <a
                href={app.app_url || '#'}
                target="_blank"
                rel="noopener noreferrer"
                className="px-3 py-1.5 rounded-lg border border-border/60 text-xs font-semibold text-foreground hover:bg-muted/40 transition-colors"
              >
                Open app
              </a>
              <div className="relative">
                <button
                  onClick={() => setMoreOpen((v) => !v)}
                  className={`flex items-center gap-1 px-3 py-1.5 rounded-lg border text-xs font-semibold transition-colors ${
                    moreOpen ? 'border-primary/60 text-primary bg-primary/10' : 'border-border/60 text-foreground hover:bg-muted/40'
                  }`}
                >
                  More
                  <MoreVertical className="w-3.5 h-3.5" />
                </button>
                {moreOpen && (
                  <>
                    <div className="fixed inset-0 z-40" onClick={() => setMoreOpen(false)} />
                    <div className="absolute right-0 top-full mt-1 w-48 z-50 gradient-border p-1.5 bg-background">
                      <button
                        onClick={() => { setTab('overview'); setMoreOpen(false); }}
                        className="w-full flex items-center gap-2 px-3 py-2 rounded-lg text-xs text-foreground hover:bg-muted/40 transition-colors text-left"
                      >
                        <ActivityIcon className="w-3.5 h-3.5" />
                        View logs
                      </button>
                      <button
                        onClick={() => { setTab('deploy'); setMoreOpen(false); }}
                        className="w-full flex items-center gap-2 px-3 py-2 rounded-lg text-xs text-foreground hover:bg-muted/40 transition-colors text-left"
                      >
                        <Github className="w-3.5 h-3.5" />
                        View webhooks
                      </button>
                      <button
                        onClick={handleRestart}
                        disabled={restarting}
                        className="w-full flex items-center gap-2 px-3 py-2 rounded-lg text-xs text-foreground hover:bg-muted/40 transition-colors text-left disabled:opacity-50"
                      >
                        {restarting ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <RefreshCw className="w-3.5 h-3.5" />}
                        Restart all dynos
                      </button>
                      <button
                        onClick={() => { setTab('settings'); setMoreOpen(false); }}
                        className="w-full flex items-center gap-2 px-3 py-2 rounded-lg text-xs text-destructive hover:bg-destructive/10 transition-colors text-left"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                        Delete app...
                      </button>
                    </div>
                  </>
                )}
              </div>
            </div>
          </div>
          <p className={`flex items-center gap-1.5 text-xs font-semibold ${statusColor}`}>
            <span className="w-1.5 h-1.5 rounded-full bg-current" />
            {liveState === 'inactive' ? 'Paused' : app.status === 'live' ? 'Running' : app.status === 'building' ? 'Building' : app.status === 'failed' ? 'Failed' : app.status}
          </p>
        </div>

        {actionError && (
          <div className="flex items-center gap-2 px-3 py-2.5 rounded-xl bg-destructive/10 border border-destructive/40 text-destructive text-xs mb-4">
            <AlertCircle className="w-4 h-4 shrink-0" />
            {actionError}
          </div>
        )}

        {/* Tabs */}
        <div className="flex flex-wrap justify-center gap-1 mb-5 border-b border-border/50 pb-px">
          {TABS.map(({ key, label, icon: Icon }) => (
            <button
              key={key}
              onClick={() => setTab(key)}
              className={`flex items-center gap-1.5 px-3 py-2 text-xs font-semibold border-b-2 transition-colors ${
                tab === key ? 'border-primary text-primary' : 'border-transparent text-muted-foreground hover:text-foreground'
              }`}
            >
              <Icon className="w-3.5 h-3.5" />
              {label}
            </button>
          ))}
        </div>

        {/* ---------------- Overview tab ---------------- */}
        {tab === 'overview' && (
          <div className="space-y-4">
            <div className="grid grid-cols-2 gap-3">
              <button
                onClick={handleToggleDyno}
                disabled={togglingDyno}
                className={`flex items-center justify-center gap-2 py-2.5 rounded-xl border text-sm font-semibold transition-colors disabled:opacity-60 ${
                  liveState === 'inactive' ? 'border-success/40 text-success hover:bg-success/10' : 'border-warning/40 text-warning hover:bg-warning/10'
                }`}
              >
                {togglingDyno ? <Loader2 className="w-4 h-4 animate-spin" /> : liveState === 'inactive' ? <Play className="w-4 h-4" /> : <Pause className="w-4 h-4" />}
                {liveState === 'inactive' ? 'Resume' : 'Pause'}
              </button>
              <button
                onClick={handleRestart}
                disabled={restarting || liveState === 'inactive'}
                className="flex items-center justify-center gap-2 py-2.5 rounded-xl border border-primary/40 text-primary text-sm font-semibold hover:bg-primary/10 transition-colors disabled:opacity-40"
              >
                {restarting ? <Loader2 className="w-4 h-4 animate-spin" /> : restartedFlash ? <CheckCircle2 className="w-4 h-4" /> : <RefreshCw className="w-4 h-4" />}
                {restartedFlash ? 'Restarted' : 'Restart'}
              </button>
            </div>

            <div>
              <div className="flex items-center justify-between mb-2">
                <p className="text-sm font-semibold text-foreground">Logs</p>
                <div className="flex items-center gap-2">
                  <select
                    value={logLines}
                    onChange={(e) => setLogLines(Number(e.target.value))}
                    className="text-xs bg-background/50 border border-border/60 rounded-lg px-2 py-1 text-foreground"
                  >
                    {LOG_LINE_OPTIONS.map((n) => (
                      <option key={n} value={n}>{n} lines</option>
                    ))}
                  </select>
                  <button
                    onClick={() => setAutoRefresh((v) => !v)}
                    className={`text-xs px-2 py-1 rounded-lg border transition-colors ${autoRefresh ? 'border-success/40 text-success' : 'border-border/50 text-muted-foreground'}`}
                  >
                    {autoRefresh ? 'Auto' : 'Paused'}
                  </button>
                  <button onClick={handleCopyLogs} className="text-xs px-2 py-1 rounded-lg border border-border/50 text-muted-foreground hover:text-foreground transition-colors">
                    {logsCopied ? <Check className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
                  </button>
                </div>
              </div>
              <div className="gradient-border p-3 max-h-96 overflow-y-auto">
                {logsLoading && !logsText ? (
                  <div className="flex items-center justify-center gap-2 py-8 text-muted-foreground text-xs">
                    <Loader2 className="w-3.5 h-3.5 animate-spin" />
                    Loading logs...
                  </div>
                ) : (
                  <pre className="text-[11px] font-mono text-foreground/80 whitespace-pre-wrap break-words">{logsText || 'No logs yet.'}</pre>
                )}
              </div>
            </div>
          </div>
        )}

        {/* ---------------- Resources tab ---------------- */}
        {tab === 'resources' && (
          <div className="space-y-4">
            <div className="gradient-border p-4">
              <p className="text-sm font-semibold text-foreground mb-3">Basic Dynos</p>
              <div className="flex items-center justify-between gap-2">
                <div className="min-w-0">
                  <p className="text-xs font-mono text-foreground truncate">web</p>
                  <p className="text-[11px] text-muted-foreground truncate">node index.js</p>
                </div>
                <span className={`shrink-0 text-xs font-semibold ${liveState === 'inactive' ? 'text-warning' : 'text-success'}`}>
                  {liveState === 'inactive' ? 'OFF' : 'ON'}
                </span>
              </div>
            </div>
            <div className="gradient-border p-4">
              <p className="text-sm font-semibold text-foreground mb-1">Add-on Services</p>
              <p className="text-xs text-muted-foreground">There are no add-ons for this app.</p>
            </div>
          </div>
        )}

        {/* ---------------- Deploy tab ---------------- */}
        {tab === 'deploy' && (
          <div className="space-y-4">
            <div>
              <p className="text-sm font-semibold text-foreground mb-1">Deployment method</p>
              <div className="gradient-border p-4 flex items-center gap-3">
                <Github className="w-5 h-5 text-foreground" />
                <div className="min-w-0">
                  <p className="text-sm text-foreground">GitHub</p>
                  <p className="text-xs text-muted-foreground">
                    {app.repo_full_name ? 'Connected' : 'Connect to GitHub'}
                  </p>
                </div>
                {app.repo_full_name && <CheckCircle2 className="w-4 h-4 text-success ml-auto shrink-0" />}
              </div>
            </div>

            {githubConnected === null && (
              <div className="flex items-center justify-center gap-2 py-8 text-muted-foreground text-sm">
                <Loader2 className="w-4 h-4 animate-spin" />
                Checking GitHub connection...
              </div>
            )}

            {githubConnected === false && (
              <div className="gradient-border p-4 space-y-3">
                <p className="text-sm font-semibold text-foreground">Connect to GitHub</p>
                <p className="text-xs text-muted-foreground">
                  Connect this app to GitHub to enable code diffs and deploys.
                </p>
                <button
                  onClick={handleConnectGithub}
                  className="w-full flex items-center justify-center gap-2 py-2.5 rounded-xl bg-gradient-to-r from-primary to-secondary text-primary-foreground text-sm font-semibold hover:opacity-90 transition-opacity"
                >
                  <Github className="w-4 h-4" />
                  Connect to GitHub
                </button>
              </div>
            )}

            {githubConnected === true && (
              <div className="flex items-center justify-between gap-2 px-4 py-3 rounded-xl bg-muted/20 text-xs border border-border/40">
                <span className="text-muted-foreground">
                  Connected as <span className="font-mono text-foreground">@{githubLogin || '...'}</span>
                </span>
                <button
                  onClick={handleDisconnectAccount}
                  disabled={disconnectingAccount}
                  className="flex items-center gap-1 px-2.5 py-1.5 rounded-lg border border-destructive/40 text-destructive hover:bg-destructive/10 disabled:opacity-50 shrink-0 transition-colors"
                >
                  {disconnectingAccount ? 'Disconnecting...' : 'Disconnect GitHub'}
                </button>
              </div>
            )}

            {githubConnected === true && !app.repo_full_name && (
              <div className="gradient-border p-4 space-y-3">
                <p className="text-sm font-semibold text-foreground">Search for a repository to connect to</p>
                <div className="flex gap-2">
                  <input
                    type="text"
                    value={repoSearch}
                    onChange={(e) => setRepoSearch(e.target.value)}
                    onKeyDown={(e) => e.key === 'Enter' && searchRepos(repoSearch)}
                    placeholder="e.g. repo-name"
                    className="flex-1 px-3 py-2 rounded-lg bg-background/50 border border-border/60 text-foreground text-sm placeholder:text-muted-foreground focus:outline-none focus:border-primary/60"
                  />
                  <button
                    onClick={() => searchRepos(repoSearch)}
                    disabled={reposLoading}
                    className="px-4 py-2 rounded-lg bg-primary/15 text-primary text-sm font-semibold hover:bg-primary/25 transition-colors disabled:opacity-50"
                  >
                    {reposLoading ? <Loader2 className="w-4 h-4 animate-spin" /> : 'Search'}
                  </button>
                </div>

                <div>
                  <label className="text-[11px] font-semibold text-muted-foreground uppercase tracking-wide mb-1 block">Branch to deploy</label>
                  <input
                    type="text"
                    value={autoDeployBranch}
                    onChange={(e) => setAutoDeployBranch(e.target.value)}
                    placeholder="main"
                    className="w-full px-3 py-2 rounded-lg bg-background/50 border border-border/60 text-foreground text-sm font-mono placeholder:text-muted-foreground focus:outline-none focus:border-primary/60"
                  />
                </div>

                <div className="space-y-1.5 max-h-56 overflow-y-auto">
                  {reposLoading && (
                    <div className="flex items-center justify-center gap-2 py-6 text-muted-foreground text-sm">
                      <Loader2 className="w-4 h-4 animate-spin" />
                      Loading repos...
                    </div>
                  )}
                  {!reposLoading && repoResults.length === 0 && (
                    <p className="text-xs text-muted-foreground text-center py-6">No repositories found.</p>
                  )}
                  {!reposLoading && repoResults.map((repo) => (
                    <div key={repo.fullName} className="flex items-center justify-between gap-2 px-3 py-2 rounded-lg border border-border/50">
                      <span className="text-xs font-mono text-foreground truncate">{repo.fullName}</span>
                      <button
                        onClick={() => handleConnectRepo(repo.fullName)}
                        disabled={connectingRepo === repo.fullName || !autoDeployBranch.trim()}
                        className="shrink-0 px-3 py-1 rounded-lg border border-primary/50 text-primary text-[11px] font-semibold hover:bg-primary/10 transition-colors disabled:opacity-50"
                      >
                        {connectingRepo === repo.fullName ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : 'Connect'}
                      </button>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {githubConnected === true && app.repo_full_name && (
              <>
                <div>
                  <p className="text-sm font-semibold text-foreground mb-1">App connected to GitHub</p>
                  <p className="text-xs text-muted-foreground mb-2">
                    Code diffs, manual and auto deploys are available for this app.
                  </p>
                  <div className="gradient-border p-4 space-y-2">
                    <div className="flex items-center justify-between gap-2">
                      <p className="text-xs text-foreground">
                        Connected to <span className="font-mono text-primary">{app.repo_full_name}</span>
                      </p>
                      <button
                        onClick={handleDisconnectRepo}
                        disabled={autoDeployToggling}
                        className="shrink-0 px-3 py-1.5 rounded-lg border border-destructive/50 text-destructive text-[11px] font-semibold hover:bg-destructive/10 transition-colors disabled:opacity-50"
                      >
                        {autoDeployToggling ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : 'Disconnect...'}
                      </button>
                    </div>
                  </div>
                </div>

                <div>
                  <p className="text-sm font-semibold text-foreground mb-1">Automatic deploys</p>
                  <p className="text-xs text-muted-foreground mb-2">
                    Enables a chosen branch to be automatically deployed to this app.
                  </p>

                  {app.auto_deploy_enabled ? (
                    <div className="rounded-xl border border-success/40 bg-success/10 p-4 space-y-3">
                      <p className="flex items-center gap-2 text-success text-sm font-semibold">
                        <CheckCircle2 className="w-4 h-4" />
                        Automatic deploys from <span className="font-mono">{app.auto_deploy_branch || 'main'}</span> are enabled
                      </p>
                      <p className="text-xs text-muted-foreground">
                        Every push to <span className="font-mono">{app.auto_deploy_branch || 'main'}</span> — including
                        syncing a fork with the original repo — rebuilds this bot automatically.
                      </p>
                      <button
                        onClick={handleDisableAutoDeploy}
                        disabled={autoDeployToggling}
                        className="w-full flex items-center justify-center gap-2 py-2 rounded-lg border border-destructive/50 text-destructive text-xs font-semibold hover:bg-destructive/10 transition-colors disabled:opacity-60"
                      >
                        {autoDeployToggling ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <X className="w-3.5 h-3.5" />}
                        Disable Automatic Deploys
                      </button>
                    </div>
                  ) : (
                    <div className="gradient-border p-4 space-y-3">
                      <p className="text-xs text-muted-foreground">
                        Every push to the branch you specify here will deploy a new version of this app.
                      </p>
                      <div>
                        <label className="text-[11px] font-semibold text-muted-foreground uppercase tracking-wide mb-1 block">Branch to deploy</label>
                        <input
                          type="text"
                          value={autoDeployBranch}
                          onChange={(e) => setAutoDeployBranch(e.target.value)}
                          placeholder="main"
                          className="w-full px-3 py-2 rounded-lg bg-background/50 border border-border/60 text-foreground text-sm font-mono placeholder:text-muted-foreground focus:outline-none focus:border-primary/60"
                        />
                      </div>
                      <button
                        onClick={() => handleConnectRepo(app.repo_full_name!)}
                        disabled={autoDeployToggling || !autoDeployBranch.trim()}
                        className="w-full flex items-center justify-center gap-2 py-2.5 rounded-xl bg-gradient-to-r from-primary to-secondary text-primary-foreground text-sm font-semibold hover:opacity-90 transition-opacity disabled:opacity-60"
                      >
                        {autoDeployToggling ? <Loader2 className="w-4 h-4 animate-spin" /> : <CheckCircle2 className="w-4 h-4" />}
                        Enable Automatic Deploys
                      </button>
                    </div>
                  )}
                </div>
              </>
            )}
          </div>
        )}

        {/* ---------------- Metrics tab ---------------- */}
        {tab === 'metrics' && (
          <div className="space-y-4">
            <div className="gradient-border p-4">
              <p className="text-sm font-semibold text-foreground mb-3">web · 1 dyno</p>
              <div className="grid grid-cols-2 gap-3">
                <div className="rounded-xl border border-border/50 p-3">
                  <p className="text-[11px] text-muted-foreground mb-1">Dyno state</p>
                  <p className={`text-sm font-semibold ${liveState === 'inactive' ? 'text-warning' : 'text-success'}`}>
                    {liveState === 'inactive' ? 'Paused' : 'Running'}
                  </p>
                </div>
                <div className="rounded-xl border border-border/50 p-3">
                  <p className="text-[11px] text-muted-foreground mb-1">Build status</p>
                  <p className={`text-sm font-semibold ${app.status === 'live' ? 'text-success' : app.status === 'failed' ? 'text-destructive' : 'text-muted-foreground'}`}>
                    {app.status === 'live' ? 'Succeeded' : app.status === 'building' ? 'Building' : app.status === 'failed' ? 'Failed' : app.status}
                  </p>
                </div>
              </div>
            </div>
            <p className="text-xs text-muted-foreground text-center px-4">
              Detailed memory, response time, and throughput graphs aren't available through Bmb Hosting yet —
              check the Overview tab for live logs in the meantime.
            </p>
          </div>
        )}

        {/* ---------------- Activity tab ---------------- */}
        {tab === 'activity' && (
          <div className="space-y-2">
            <p className="text-sm font-semibold text-foreground mb-1">Activity Feed</p>
            {activity.length === 0 && (
              <p className="text-xs text-muted-foreground text-center py-10">No activity recorded yet.</p>
            )}
            {activity.map((row) => (
              <div key={row.id} className="gradient-border p-3">
                <p className="text-sm text-foreground">{row.action}</p>
                {row.detail && <p className="text-xs text-muted-foreground mt-0.5">{row.detail}</p>}
                <p className="text-[11px] text-muted-foreground mt-1">{new Date(row.created_at).toLocaleString()}</p>
              </div>
            ))}
          </div>
        )}

        {/* ---------------- Access tab ---------------- */}
        {tab === 'access' && (
          <div className="gradient-border p-4">
            <p className="text-sm font-semibold text-foreground mb-3">Collaborators</p>
            <div className="flex items-center justify-between gap-2 py-2">
              <span className="text-sm text-foreground truncate">{user?.email}</span>
              <span className="text-[11px] text-muted-foreground shrink-0">Owner</span>
            </div>
            <p className="text-xs text-muted-foreground mt-3">Only you can manage this bot right now.</p>
          </div>
        )}

        {/* ---------------- Settings tab ---------------- */}
        {tab === 'settings' && (
          <div className="space-y-4">
            <div className="gradient-border p-4 space-y-3">
              <p className="text-sm font-semibold text-foreground">App Information</p>
              <div>
                <label className="text-[11px] font-semibold text-muted-foreground uppercase tracking-wide mb-1 block">App Name</label>
                <input
                  type="text"
                  value={editAppName}
                  disabled
                  className="w-full px-3 py-2 rounded-lg bg-background/30 border border-border/50 text-muted-foreground text-sm font-mono"
                />
              </div>
              {app.repo_full_name && (
                <div>
                  <label className="text-[11px] font-semibold text-muted-foreground uppercase tracking-wide mb-1 block">GitHub Repo</label>
                  <p className="text-sm text-foreground font-mono">{app.repo_full_name}</p>
                </div>
              )}
            </div>

            <div className="gradient-border p-4 space-y-3">
              <div className="flex items-center justify-between">
                <p className="text-sm font-semibold text-foreground">Config Vars</p>
                <button
                  onClick={() => setConfigRevealed((v) => !v)}
                  className="text-xs px-2 py-1 rounded-lg border border-border/50 text-muted-foreground hover:text-foreground transition-colors"
                >
                  {configRevealed ? 'Hide' : 'Reveal Config Vars'}
                </button>
              </div>

              {configRevealed && (
                <div className="space-y-2">
                  {Object.entries(editEnvValues).map(([key, value]) => (
                    <div key={key} className="flex items-center gap-2">
                      <span className="text-xs font-mono text-muted-foreground w-1/3 truncate">{key}</span>
                      <input
                        type="text"
                        value={value}
                        onChange={(e) => setEditEnvValues(prev => ({ ...prev, [key]: e.target.value }))}
                        className="flex-1 px-2 py-1.5 rounded-lg bg-background/50 border border-border/60 text-foreground text-xs font-mono focus:outline-none focus:border-primary/60"
                      />
                    </div>
                  ))}
                  {Object.keys(editEnvValues).length === 0 && (
                    <p className="text-xs text-muted-foreground">No config vars set.</p>
                  )}

                  {editError && <p className="text-xs text-destructive">{editError}</p>}
                  {editSuccess && <p className="text-xs text-success">{editSuccess}</p>}

                  <button
                    onClick={handleSaveConfig}
                    disabled={editSaving}
                    className="w-full flex items-center justify-center gap-2 py-2 rounded-lg bg-primary/15 text-primary text-xs font-semibold hover:bg-primary/25 transition-colors disabled:opacity-50"
                  >
                    {editSaving ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <Pencil className="w-3.5 h-3.5" />}
                    Save Config Vars
                  </button>
                </div>
              )}
            </div>

            <div className="gradient-border p-4 border-destructive/40">
              <p className="text-sm font-semibold text-destructive mb-1">Delete App</p>
              <p className="text-xs text-muted-foreground mb-3">Deleting your app is irreversible.</p>

              {!showDeleteConfirm ? (
                <button
                  onClick={() => setShowDeleteConfirm(true)}
                  className="flex items-center gap-2 px-4 py-2 rounded-lg border border-destructive/50 text-destructive text-xs font-semibold hover:bg-destructive/10 transition-colors"
                >
                  <Trash2 className="w-3.5 h-3.5" />
                  Delete app...
                </button>
              ) : (
                <div className="space-y-2">
                  <p className="text-xs text-muted-foreground">
                    Type <span className="font-mono text-foreground">{app.heroku_app_name}</span> to confirm.
                  </p>
                  <input
                    type="text"
                    value={deleteConfirmInput}
                    onChange={(e) => setDeleteConfirmInput(e.target.value)}
                    className="w-full px-3 py-2 rounded-lg bg-background/50 border border-border/60 text-foreground text-sm font-mono focus:outline-none focus:border-destructive/60"
                  />
                  {deleteError && <p className="text-xs text-destructive">{deleteError}</p>}
                  <div className="flex gap-2">
                    <button
                      onClick={handleDelete}
                      disabled={deleting || deleteConfirmInput !== app.heroku_app_name}
                      className="flex-1 flex items-center justify-center gap-2 py-2 rounded-lg bg-destructive text-destructive-foreground text-xs font-semibold hover:opacity-90 transition-opacity disabled:opacity-50"
                    >
                      {deleting ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <Trash2 className="w-3.5 h-3.5" />}
                      Confirm Delete
                    </button>
                    <button
                      onClick={() => { setShowDeleteConfirm(false); setDeleteConfirmInput(''); setDeleteError(''); }}
                      className="px-4 py-2 rounded-lg border border-border/50 text-muted-foreground text-xs hover:text-foreground transition-colors"
                    >
                      Cancel
                    </button>
                  </div>
                </div>
              )}
            </div>
          </div>
        )}
      </div>

      <Footer />
    </div>
  );
};

export default BotSettings;
