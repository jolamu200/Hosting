import { useNavigate } from 'react-router-dom';
import { ArrowLeft, ShieldCheck } from 'lucide-react';
import TechBackground from '@/components/TechBackground';

const Terms = () => {
  const navigate = useNavigate();

  return (
    <div className="min-h-screen bg-background text-foreground relative">
      <TechBackground />

      <div className="relative z-10 max-w-2xl mx-auto px-4 py-8">
        <button
          onClick={() => navigate(-1)}
          className="flex items-center gap-2 text-sm text-muted-foreground hover:text-foreground transition-colors mb-6"
        >
          <ArrowLeft className="w-4 h-4" />
          Back
        </button>

        <div className="rounded-2xl bg-gradient-to-r from-primary to-secondary p-6 mb-8">
          <div className="flex items-center gap-2 text-primary-foreground mb-1">
            <ShieldCheck className="w-6 h-6" />
            <h1 className="text-2xl font-bold">Terms of Service</h1>
          </div>
          <p className="text-primary-foreground/80 text-sm">Last updated: August 6, 2026</p>
        </div>

        <div className="space-y-6 text-sm text-muted-foreground leading-relaxed">
          <section>
            <h2 className="text-base font-semibold text-foreground mb-2">1. Acceptance of Terms</h2>
            <p>
              By accessing or using Bmb Tech ("the Service"), you agree to be bound by these Terms
              of Service. If you do not agree to these terms, please do not use the Service. These
              terms apply to all visitors, users, and others who access or use the Service.
            </p>
          </section>

          <section>
            <h2 className="text-base font-semibold text-foreground mb-2">2. Description of Service</h2>
            <p>
              Bmb Tech is a cloud-based platform that allows users to deploy, manage, and monitor
              WhatsApp bots. The Service includes bot deployment via Heroku infrastructure, a
              community chat, media tools, and related utilities.
            </p>
          </section>

          <section>
            <h2 className="text-base font-semibold text-foreground mb-2">3. User Accounts &amp; Registration</h2>
            <p>
              To access the Service, you must create an account using a valid email address or a
              supported Google/GitHub sign-in. You are responsible for maintaining the
              confidentiality of your account credentials. You must be at least 13 years of age to
              use the Service. You agree to provide accurate, current, and complete information
              during registration and to update such information as necessary.
            </p>
          </section>

          <section>
            <h2 className="text-base font-semibold text-foreground mb-2">4. Bot Deployment &amp; Usage</h2>
            <p>
              Bots deployed through Bmb Tech must comply with WhatsApp's Terms of Service and
              Community Guidelines. You are solely responsible for the content and behavior of
              your deployed bots. Bmb Tech does not guarantee uninterrupted uptime for individual
              bots and is not liable for losses caused by bot downtime or platform outages.
            </p>
          </section>

          <section>
            <h2 className="text-base font-semibold text-foreground mb-2">5. Prohibited Activities</h2>
            <p>
              You agree not to use the Service to: (a) deploy bots that send spam, unsolicited
              messages, or engage in harassment; (b) distribute malware, viruses, or malicious
              code; (c) attempt to gain unauthorized access to other accounts or systems; (d)
              engage in fraud, deception, or impersonation; (e) violate any applicable local,
              national, or international law or regulation; (f) exploit, harm, or attempt to
              exploit or harm minors.
            </p>
          </section>

          <section>
            <h2 className="text-base font-semibold text-foreground mb-2">6. Intellectual Property</h2>
            <p>
              The Service and its original content, features, and functionality are and will
              remain the exclusive property of Bmb Tech and its licensors. Our trademarks and
              trade dress may not be used in connection with any product or service without prior
              written consent from Bmb Tech.
            </p>
          </section>

          <section>
            <h2 className="text-base font-semibold text-foreground mb-2">7. Account Suspension &amp; Termination</h2>
            <p>
              Bmb Tech reserves the right to suspend or terminate your account at any time,
              without prior notice or liability, for any reason, including if you breach these
              Terms. Upon termination, your right to use the Service will immediately cease.
            </p>
          </section>

          <section>
            <h2 className="text-base font-semibold text-foreground mb-2">8. Disclaimer of Warranties</h2>
            <p>
              The Service is provided on an "AS IS" and "AS AVAILABLE" basis without warranties of
              any kind, either express or implied. Bmb Tech does not warrant that the Service will
              be uninterrupted, error-free, or free of viruses or other harmful components.
            </p>
          </section>

          <section>
            <h2 className="text-base font-semibold text-foreground mb-2">9. Limitation of Liability</h2>
            <p>
              To the maximum extent permitted by law, Bmb Tech shall not be liable for any
              indirect, incidental, special, consequential, or punitive damages, including loss of
              profits, data, or goodwill, arising out of or in connection with your use of the
              Service.
            </p>
          </section>

          <section>
            <h2 className="text-base font-semibold text-foreground mb-2">10. Changes to Terms</h2>
            <p>
              Bmb Tech reserves the right to modify these Terms at any time. We will provide
              notice of significant changes by updating the "Last updated" date at the top of this
              page. Your continued use of the Service after changes constitutes acceptance of the
              new Terms.
            </p>
          </section>

          <section>
            <h2 className="text-base font-semibold text-foreground mb-2">11. Contact Us</h2>
            <p>
              If you have any questions about these Terms of Service, please contact us through
              the community chat on the platform or reach out via our official WhatsApp channel.
            </p>
          </section>
        </div>

        <p className="text-center text-xs text-muted-foreground mt-10 mb-4">
          © 2024 – 2026 Bmb Tech. All rights reserved.
        </p>
      </div>
    </div>
  );
};

export default Terms;
