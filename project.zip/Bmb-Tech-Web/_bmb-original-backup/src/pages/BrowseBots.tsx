import { useEffect, useRef, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import {
  Loader2, Bot as BotIcon, User, Users, Copy, Check, ArrowRight, Coins, Search, Inbox, X,
  Pencil, Trash2, Save, AlertCircle, Plus, Link as LinkIcon,
} from 'lucide-react';
import { supabase } from '@/lib/supabaseClient';
import { useAuth } from '@/context/AuthContext';
import FloatingMenu from '@/components/FloatingMenu';
import TechBackground from '@/components/TechBackground';
import BackButton from '@/components/BackButton';
import Footer from '@/components/Footer';
import AdminAddBot from '@/components/AdminAddBot';
import AdminBotRequests from '@/components/AdminBotRequests';

interface BotRow {
  id: string;
  name: string;
  slug: string;
  description: string;
  logo_url: string | null;
  creator_name: string;
  price_label: string | null;
  deploy_count: number;
  rank_badge: string | null;
  session_link?: string | null;
  repo_full_name?: string | null;
  repo_synced_at?: string | null;
}

// How long (ms) a press has to be held before it counts as a long-press
// and opens the owner's Edit/Delete menu, instead of a normal tap.
const LONG_PRESS_MS = 450;

const BrowseBots = () => {
  const navigate = useNavigate();
  const { user } = useAuth();
  const [bots, setBots] = useState<BotRow[]>([]);
  const [loading, setLoading] = useState(true);
  const [copiedSlug, setCopiedSlug] = useState<string | null>(null);
  const [searchQuery, setSearchQuery] = useState('');
  const [isOwner, setIsOwner] = useState(false);
  const [showBotRequests, setShowBotRequests] = useState(false);
  const [showAddBot, setShowAddBot] = useState(false);

  // Owner long-press menu: which bot was pressed, and edit-modal state.
  const [actionBot, setActionBot] = useState<BotRow | null>(null);
  const [editBot, setEditBot] = useState<BotRow | null>(null);
  const [deletingId, setDeletingId] = useState<string | null>(null);
  const pressTimerRef = useRef<ReturnType<typeof setTimeout> | null>(null);
  const longPressFiredRef = useRef(false);

  useEffect(() => {
    if (!user) return;
    supabase
      .from('profiles')
      .select('role')
      .eq('id', user.id)
      .single()
      .then(({ data }) => setIsOwner(data?.role === 'owner'));
  }, [user]);

  const filteredBots = bots.filter((bot) => {
    const q = searchQuery.trim().toLowerCase();
    if (!q) return true;
    return (
      bot.name.toLowerCase().includes(q) ||
      bot.description?.toLowerCase().includes(q) ||
      bot.creator_name?.toLowerCase().includes(q)
    );
  });

  useEffect(() => {
    const load = async () => {
      const { data } = await supabase
        .from('bots_catalog')
        .select('id, name, slug, description, logo_url, creator_name, price_label, deploy_count, rank_badge, session_link, repo_full_name, repo_synced_at')
        .eq('is_active', true)
        .order('deploy_count', { ascending: false });

      setBots(data || []);
      setLoading(false);

      // Quietly keep each bot's deploy config (env vars needed, RAM/disk,
      // tags) in sync with its GitHub repo's app.json, so if the repo
      // owner changes something there, it shows up here without anyone
      // having to manually re-add the bot. Display fields the owner
      // curates by hand (name, description, logo, price) are left alone —
      // only the technical deploy config is ever auto-refreshed.
      const SIX_HOURS = 6 * 60 * 60 * 1000;
      (data || []).forEach((bot: any) => {
        if (!bot.repo_full_name) return;
        const lastSynced = bot.repo_synced_at ? new Date(bot.repo_synced_at).getTime() : 0;
        if (Date.now() - lastSynced < SIX_HOURS) return;

        fetch(`/api/github-app-json?repo=${encodeURIComponent(bot.repo_full_name)}`)
          .then((res) => (res.ok ? res.json() : null))
          .then((result) => {
            if (!result?.app_json) return;
            const aj = result.app_json;
            // Same object → array conversion AdminAddBot uses when a bot is
            // first added — app.json's "env" is a plain object keyed by
            // var name, but every page that renders env vars (BotDetail,
            // BotSettings) expects an array of { key, description,
            // required, value }. Storing the raw object here (as an
            // earlier version of this sync did) broke every bot it
            // touched with a ".forEach is not a function" crash.
            const envSchema = Object.entries(aj.env || {}).map(([key, val]: [string, any]) => ({
              key,
              description: val?.description,
              required: val?.required !== false,
              value: val?.value,
            }));
            return supabase
              .from('bots_catalog')
              .update({
                repo_url: result.repo_url || null,
                env_schema: envSchema,
                tags: Array.isArray(aj.keywords) ? aj.keywords : undefined,
                ram_mb: typeof aj.formation?.web?.quantity === 'number' ? aj.formation.web.quantity : undefined,
                repo_synced_at: new Date().toISOString(),
              })
              .eq('id', bot.id);
          })
          .catch(() => {
            // best-effort background sync — a failed refresh just tries
            // again next time this page loads
          });
      });
    };

    load();
  }, []);

  const handleCopy = (slug: string) => {
    const link = `${window.location.origin}/deploy/${slug}`;
    navigator.clipboard.writeText(link).then(() => {
      setCopiedSlug(slug);
      setTimeout(() => setCopiedSlug(null), 2000);
    });
  };

  // Long-press (touch or mouse) on a bot card opens the owner's
  // Edit/Delete menu. A normal tap/click is left alone.
  const handlePressStart = (bot: BotRow) => {
    if (!isOwner) return;
    longPressFiredRef.current = false;
    pressTimerRef.current = setTimeout(() => {
      longPressFiredRef.current = true;
      if (navigator.vibrate) navigator.vibrate(15);
      setActionBot(bot);
    }, LONG_PRESS_MS);
  };

  const handlePressEnd = () => {
    if (pressTimerRef.current) clearTimeout(pressTimerRef.current);
  };

  const handleDeleteBot = async (id: string) => {
    setDeletingId(id);
    const { error } = await supabase.from('bots_catalog').delete().eq('id', id);
    setDeletingId(null);
    if (!error) {
      setBots(prev => prev.filter(b => b.id !== id));
      setActionBot(null);
    }
  };

  return (
    <div className="min-h-screen bg-background text-foreground relative">
      <TechBackground />
      <FloatingMenu />

      <div className="relative z-10 max-w-3xl mx-auto px-4 py-20">
        <BackButton className="mb-4" />

        {isOwner && (
          <div className="flex items-center justify-between gap-3 mb-4">
            <button
              onClick={() => setShowBotRequests(true)}
              className="flex items-center gap-1.5 px-3 py-2 rounded-lg border border-border/60 text-xs font-semibold text-foreground hover:bg-muted/40 transition-colors"
            >
              <Inbox className="w-3.5 h-3.5" />
              Bot Requests
            </button>
            <button
              onClick={() => setShowAddBot(true)}
              className="flex items-center gap-1.5 px-3 py-2 rounded-lg bg-gradient-to-r from-primary to-secondary text-primary-foreground text-xs font-semibold hover:opacity-90 transition-opacity"
            >
              <Plus className="w-3.5 h-3.5" />
              Add Bot
            </button>
          </div>
        )}

        {isOwner && (
          <p className="text-[11px] text-muted-foreground mb-4 -mt-2">Hold a bot card to edit or delete it</p>
        )}

        <div className="mb-8">
          <h1 className="text-2xl md:text-3xl font-bold text-foreground mb-1">Available Bots</h1>
          <p className="text-sm text-muted-foreground">
            {bots.length} bot{bots.length === 1 ? '' : 's'} ready for deployment
          </p>
        </div>

        {!loading && bots.length > 0 && (
          <div className="relative mb-6">
            <Search className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search bots..."
              className="w-full pl-10 pr-4 py-3 rounded-xl bg-card/60 border border-border/50 text-foreground text-sm placeholder:text-muted-foreground focus:outline-none focus:border-primary/60 transition-colors"
            />
          </div>
        )}

        {loading && (
          <div className="flex items-center justify-center gap-2 py-20 text-muted-foreground">
            <Loader2 className="w-5 h-5 animate-spin" />
            Loading bots...
          </div>
        )}

        {!loading && bots.length === 0 && (
          <div className="flex flex-col items-center justify-center gap-3 py-20 text-center">
            <BotIcon className="w-10 h-10 text-muted-foreground" />
            <p className="text-muted-foreground">No bots available yet. Check back soon.</p>
          </div>
        )}

        {!loading && bots.length > 0 && filteredBots.length === 0 && (
          <div className="flex flex-col items-center justify-center gap-3 py-20 text-center">
            <Search className="w-10 h-10 text-muted-foreground" />
            <p className="text-muted-foreground">No bots match "{searchQuery}".</p>
          </div>
        )}

        <div className="grid grid-cols-2 gap-3">
          {filteredBots.map((bot, index) => (
            <div
              key={bot.id}
              className="gradient-border overflow-hidden flex flex-col select-none"
              onMouseDown={() => handlePressStart(bot)}
              onMouseUp={handlePressEnd}
              onMouseLeave={handlePressEnd}
              onTouchStart={() => handlePressStart(bot)}
              onTouchEnd={handlePressEnd}
              onTouchCancel={handlePressEnd}
              onContextMenu={(e) => { if (isOwner) e.preventDefault(); }}
            >
              {/* Banner image */}
              <div className="relative aspect-video bg-background/40">
                {bot.logo_url ? (
                  <img src={bot.logo_url} alt={bot.name} className="w-full h-full object-cover" />
                ) : (
                  <div className="w-full h-full flex items-center justify-center">
                    <BotIcon className="w-10 h-10 text-muted-foreground" />
                  </div>
                )}
                <span className="absolute top-1.5 left-1.5 w-6 h-6 rounded-full bg-background/80 backdrop-blur-sm border border-border/50 flex items-center justify-center text-[10px] font-bold text-foreground">
                  #{index + 1}
                </span>
                {bot.rank_badge && (
                  <div className="absolute bottom-0 inset-x-0 py-1 text-center text-[10px] font-bold tracking-wide bg-gradient-to-r from-orange-500 to-red-500 text-white">
                    {bot.rank_badge}
                  </div>
                )}
              </div>

              {/* Content */}
              <div className="p-2.5 flex-1 flex flex-col">
                <p className="font-bold text-foreground text-sm truncate">{bot.name}</p>
                <p className="flex items-center gap-1 text-[11px] text-muted-foreground mt-0.5 mb-1.5">
                  <User className="w-2.5 h-2.5" />
                  {bot.creator_name}
                </p>
                <p className="flex items-center gap-1 text-[11px] text-muted-foreground mb-1.5">
                  <Users className="w-2.5 h-2.5" />
                  {bot.deploy_count} active
                </p>
                <p className="text-[11px] text-muted-foreground leading-snug line-clamp-2 mb-2 flex-1">
                  {bot.description}
                </p>

                {bot.price_label && (
                  <p className="flex items-center gap-1 text-[11px] text-success mb-2">
                    <Coins className="w-3 h-3" />
                    {bot.price_label}
                  </p>
                )}

                <div className="flex items-center gap-1.5">
                  <button
                    onClick={() => handleCopy(bot.slug)}
                    className="w-8 h-8 shrink-0 flex items-center justify-center rounded-lg border border-border/50 text-muted-foreground hover:text-foreground hover:bg-muted/40 transition-colors"
                    aria-label="Copy deploy link"
                  >
                    {copiedSlug === bot.slug ? (
                      <Check className="w-3.5 h-3.5 text-success" />
                    ) : (
                      <Copy className="w-3.5 h-3.5" />
                    )}
                  </button>
                  <button
                    onClick={() => navigate(`/bots/${bot.slug}`)}
                    className="flex-1 flex items-center justify-center gap-1 py-2 rounded-lg bg-primary text-primary-foreground text-xs font-semibold hover:opacity-90 transition-opacity"
                  >
                    Deploy
                    <ArrowRight className="w-3 h-3" />
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>

      {isOwner && showAddBot && (
        <div
          className="fixed inset-0 z-[60] flex items-center justify-center bg-background/80 backdrop-blur-sm px-4"
          onClick={() => setShowAddBot(false)}
        >
          <div
            className="w-full max-w-lg max-h-[85vh] overflow-y-auto gradient-border p-6"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="flex items-center justify-between mb-4">
              <p className="flex items-center gap-2 font-semibold text-foreground">
                <Plus className="w-4 h-4 text-primary" />
                Add Bot
              </p>
              <button onClick={() => setShowAddBot(false)} className="text-muted-foreground hover:text-foreground">
                <X className="w-5 h-5" />
              </button>
            </div>
            <AdminAddBot
              onAdded={(bot) => {
                setBots(prev => [bot, ...prev]);
                setShowAddBot(false);
              }}
            />
          </div>
        </div>
      )}

      {isOwner && showBotRequests && (
        <div
          className="fixed inset-0 z-[60] flex items-center justify-center bg-background/80 backdrop-blur-sm px-4"
          onClick={() => setShowBotRequests(false)}
        >
          <div
            className="w-full max-w-lg max-h-[85vh] overflow-y-auto gradient-border p-6"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="flex items-center justify-between mb-4">
              <p className="flex items-center gap-2 font-semibold text-foreground">
                <Inbox className="w-4 h-4 text-primary" />
                Bot Requests
              </p>
              <button onClick={() => setShowBotRequests(false)} className="text-muted-foreground hover:text-foreground">
                <X className="w-5 h-5" />
              </button>
            </div>
            <AdminBotRequests />
          </div>
        </div>
      )}

      {/* Long-press action menu: owner picks Edit or Delete */}
      {actionBot && !editBot && (
        <div
          className="fixed inset-0 z-[65] flex items-end sm:items-center justify-center bg-background/80 backdrop-blur-sm px-4 pb-4 sm:pb-0"
          onClick={() => setActionBot(null)}
        >
          <div className="w-full max-w-sm gradient-border p-4" onClick={(e) => e.stopPropagation()}>
            <p className="font-semibold text-foreground truncate mb-3 px-1">{actionBot.name}</p>
            <div className="flex flex-col gap-1.5">
              <button
                onClick={() => setEditBot(actionBot)}
                className="flex items-center gap-2.5 px-3 py-3 rounded-xl hover:bg-muted/40 text-foreground text-sm font-medium transition-colors"
              >
                <Pencil className="w-4 h-4 text-primary" />
                Edit bot
              </button>
              <button
                onClick={() => handleDeleteBot(actionBot.id)}
                disabled={deletingId === actionBot.id}
                className="flex items-center gap-2.5 px-3 py-3 rounded-xl hover:bg-destructive/10 text-destructive text-sm font-medium transition-colors disabled:opacity-50"
              >
                {deletingId === actionBot.id ? (
                  <Loader2 className="w-4 h-4 animate-spin" />
                ) : (
                  <Trash2 className="w-4 h-4" />
                )}
                Delete bot
              </button>
              <button
                onClick={() => setActionBot(null)}
                className="px-3 py-3 rounded-xl border border-border/50 text-muted-foreground text-sm mt-1"
              >
                Cancel
              </button>
            </div>
          </div>
        </div>
      )}

      {editBot && (
        <EditBotModal
          bot={editBot}
          onClose={() => { setEditBot(null); setActionBot(null); }}
          onSaved={(updated) => {
            setBots(prev => prev.map(b => (b.id === updated.id ? { ...b, ...updated } : b)));
            setEditBot(null);
            setActionBot(null);
          }}
        />
      )}

      <Footer />
    </div>
  );
};

// Separate component so its form state doesn't clutter the main page.
const EditBotModal = ({
  bot,
  onClose,
  onSaved,
}: {
  bot: BotRow;
  onClose: () => void;
  onSaved: (updated: BotRow) => void;
}) => {
  const [name, setName] = useState(bot.name);
  const [description, setDescription] = useState(bot.description || '');
  const [creatorName, setCreatorName] = useState(bot.creator_name || '');
  const [priceLabel, setPriceLabel] = useState(bot.price_label || '');
  const [logoUrl, setLogoUrl] = useState(bot.logo_url || '');
  const [sessionLink, setSessionLink] = useState(bot.session_link || '');
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState('');

  const handleSave = async () => {
    setSaving(true);
    setError('');

    const updates = {
      name: name.trim(),
      description: description.trim(),
      creator_name: creatorName.trim(),
      price_label: priceLabel.trim() || null,
      logo_url: logoUrl.trim() || null,
      session_link: sessionLink.trim() || null,
    };

    const { error: saveError } = await supabase.from('bots_catalog').update(updates).eq('id', bot.id);
    setSaving(false);

    if (saveError) {
      setError(saveError.message);
      return;
    }

    onSaved({ ...bot, ...updates });
  };

  return (
    <div className="fixed inset-0 z-[70] flex items-center justify-center bg-background/80 backdrop-blur-sm px-4" onClick={onClose}>
      <div className="w-full max-w-sm max-h-[85vh] overflow-y-auto gradient-border p-6" onClick={(e) => e.stopPropagation()}>
        <div className="flex items-center justify-between mb-4">
          <p className="flex items-center gap-2 font-semibold text-foreground">
            <Pencil className="w-4 h-4 text-primary" />
            Edit Bot
          </p>
          <button onClick={onClose} className="text-muted-foreground hover:text-foreground">
            <X className="w-5 h-5" />
          </button>
        </div>

        {error && (
          <div className="flex items-center gap-2 px-3 py-2.5 rounded-xl bg-destructive/10 border border-destructive/40 text-destructive text-xs mb-3">
            <AlertCircle className="w-4 h-4 shrink-0" />
            {error}
          </div>
        )}

        <div className="space-y-4">
          <div>
            <label className="text-xs font-semibold text-muted-foreground tracking-wide uppercase mb-1.5 block">Name</label>
            <input
              type="text"
              value={name}
              onChange={(e) => setName(e.target.value)}
              className="w-full px-4 py-2.5 rounded-xl bg-background/50 border border-border/60 text-foreground text-sm focus:outline-none focus:border-primary/60 transition-colors"
            />
          </div>
          <div>
            <label className="text-xs font-semibold text-muted-foreground tracking-wide uppercase mb-1.5 block">Description</label>
            <textarea
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              rows={3}
              className="w-full px-4 py-2.5 rounded-xl bg-background/50 border border-border/60 text-foreground text-sm focus:outline-none focus:border-primary/60 transition-colors resize-none"
            />
          </div>
          <div>
            <label className="text-xs font-semibold text-muted-foreground tracking-wide uppercase mb-1.5 block">Creator name</label>
            <input
              type="text"
              value={creatorName}
              onChange={(e) => setCreatorName(e.target.value)}
              className="w-full px-4 py-2.5 rounded-xl bg-background/50 border border-border/60 text-foreground text-sm focus:outline-none focus:border-primary/60 transition-colors"
            />
          </div>
          <div>
            <label className="text-xs font-semibold text-muted-foreground tracking-wide uppercase mb-1.5 block">Price label</label>
            <input
              type="text"
              value={priceLabel}
              onChange={(e) => setPriceLabel(e.target.value)}
              placeholder="e.g. 500 coins/mo"
              className="w-full px-4 py-2.5 rounded-xl bg-background/50 border border-border/60 text-foreground text-sm placeholder:text-muted-foreground focus:outline-none focus:border-primary/60 transition-colors"
            />
          </div>
          <div>
            <label className="text-xs font-semibold text-muted-foreground tracking-wide uppercase mb-1.5 block">Logo URL</label>
            <input
              type="text"
              value={logoUrl}
              onChange={(e) => setLogoUrl(e.target.value)}
              placeholder="https://..."
              className="w-full px-4 py-2.5 rounded-xl bg-background/50 border border-border/60 text-foreground text-sm placeholder:text-muted-foreground focus:outline-none focus:border-primary/60 transition-colors"
            />
          </div>
          <div>
            <label className="text-xs font-semibold text-muted-foreground tracking-wide uppercase mb-1.5 flex items-center gap-1.5">
              <LinkIcon className="w-3.5 h-3.5 text-primary" />
              Session ID Link
            </label>
            <input
              type="text"
              value={sessionLink}
              onChange={(e) => setSessionLink(e.target.value)}
              placeholder="https://example.com/get-session"
              className="w-full px-4 py-2.5 rounded-xl bg-background/50 border border-border/60 text-foreground text-sm placeholder:text-muted-foreground focus:outline-none focus:border-primary/60 transition-colors"
            />
            <p className="text-[11px] text-muted-foreground mt-1">
              Shown as a "Get Session ID" button on the deploy page. Leave blank to hide it.
            </p>
          </div>

          <button
            onClick={handleSave}
            disabled={saving}
            className="w-full flex items-center justify-center gap-2 py-3 rounded-xl bg-gradient-to-r from-primary to-secondary text-primary-foreground text-sm font-bold hover:opacity-90 transition-opacity disabled:opacity-60"
          >
            {saving ? <Loader2 className="w-4 h-4 animate-spin" /> : <Save className="w-4 h-4" />}
            Save Changes
          </button>
        </div>
      </div>
    </div>
  );
};

export default BrowseBots;
