import { useEffect } from 'react';
import { useParams } from 'react-router-dom';
import { tools } from '@/data/tools';
import NotFound from './NotFound';

const ToolRedirect = () => {
  const { slug } = useParams<{ slug: string }>();
  const tool = tools.find(t => t.slug === slug && t.url);

  useEffect(() => {
    if (tool?.url) {
      window.location.replace(tool.url);
    }
  }, [tool]);

  if (!tool?.url) {
    // No matching tool for this slug
    return <NotFound />;
  }

  // Briefly shown while the redirect happens
  return (
    <div className="min-h-screen bg-background text-foreground flex items-center justify-center px-4">
      <div className="text-center">
        <p className="text-primary font-mono text-sm tracking-widest mb-2">REDIRECTING</p>
        <p className="text-muted-foreground">Taking you to {tool.title}...</p>
      </div>
    </div>
  );
};

export default ToolRedirect;
