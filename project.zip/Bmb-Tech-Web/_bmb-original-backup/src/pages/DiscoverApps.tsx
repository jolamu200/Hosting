import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Search, Loader2, Star, GitFork, Rocket, AlertCircle, Home as HomeIcon } from 'lucide-react';
import FloatingMenu from '@/components/FloatingMenu';
import TechBackground from '@/components/TechBackground';
import BackButton from '@/components/BackButton';

interface SearchResult {
  repo_full_name: string;
  repo_url: string;
  name: string;
  description: string;
  logo_url: string | null;
  stars: number;
  forks: number;
  language: string | null;
  default_branch: string;
  env_schema: Record<string, any>;
}

const DiscoverApps = () => {
  const navigate = useNavigate();
  const [query, setQuery] = useState('whatsapp bot baileys');
  const [results, setResults] = useState<SearchResult[]>([]);
  const [totalCount, setTotalCount] = useState(0);
  const [page, setPage] = useState(1);
  const [loading, setLoading] = useState(false);
  const [searched, setSearched] = useState(false);
  const [error, setError] = useState('');

  const runSearch = async (searchPage: number) => {
    if (!query.trim()) return;

    setError('');
    setLoading(true);
    setSearched(true);

    try {
      const res = await fetch(`/api/github-search-bots?q=${encodeURIComponent(query)}&page=${searchPage}`);
      const data = await res.json();

      if (!res.ok) {
        setError(data.error || 'Search failed.');
        setResults([]);
      } else {
        setResults(data.results || []);
        setTotalCount(data.total_count || 0);
        setPage(searchPage);
      }
    } catch (err: any) {
      setError(err.message || 'Search failed.');
    }

    setLoading(false);
  };

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    runSearch(1);
  };

  const handleDeploy = (repo: SearchResult) => {
    // Pass the repo details via navigation state so BotDetail can render a
    // deploy form for it without needing a bots_catalog entry.
    navigate('/bots/github-deploy', {
      state: {
        repo_full_name: repo.repo_full_name,
        repo_url: repo.repo_url,
        name: repo.name,
        description: repo.description,
        logo_url: repo.logo_url,
        default_branch: repo.default_branch,
        env_schema: repo.env_schema,
      },
    });
  };

  const totalPages = Math.min(Math.ceil(totalCount / 10), 10); // GitHub search caps at 1000 results (~100 pages of 10, but we'll be conservative)

  return (
    <div className="min-h-screen bg-background text-foreground relative">
      <TechBackground />
      <FloatingMenu />

      <div className="relative z-10 max-w-2xl mx-auto px-4 py-20">
        <BackButton className="mb-4" />
        <div className="flex items-center justify-between mb-6">
          <div>
            <h1 className="text-2xl md:text-3xl font-bold text-foreground mb-1">Discover Apps</h1>
            <p className="text-sm text-muted-foreground">
              Search GitHub for WhatsApp bots and deploy them with one click.
            </p>
          </div>
        </div>

        <button
          onClick={() => navigate('/bots')}
          className="flex items-center gap-2 px-4 py-2.5 rounded-xl border border-border/60 text-sm text-foreground hover:bg-muted/40 transition-colors mb-6"
        >
          <HomeIcon className="w-4 h-4" />
          My Catalog
        </button>

        {/* Search box */}
        <form onSubmit={handleSearch} className="mb-6">
          <label className="text-xs font-semibold text-muted-foreground tracking-wide uppercase mb-1.5 block">
            Search
          </label>
          <div className="flex gap-2">
            <input
              type="text"
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              placeholder="whatsapp bot baileys"
              className="flex-1 px-4 py-3 rounded-xl bg-background/50 border border-border/60 text-foreground text-sm placeholder:text-muted-foreground focus:outline-none focus:border-primary/60 transition-colors"
            />
            <button
              type="submit"
              disabled={loading}
              className="flex items-center gap-2 px-5 py-3 rounded-xl bg-primary text-primary-foreground text-sm font-semibold hover:opacity-90 transition-opacity disabled:opacity-60"
            >
              {loading ? <Loader2 className="w-4 h-4 animate-spin" /> : <Search className="w-4 h-4" />}
              Search
            </button>
          </div>
        </form>

        {error && (
          <div className="flex items-center gap-2 px-4 py-3 rounded-xl bg-destructive/10 border border-destructive/40 text-destructive text-sm mb-6">
            <AlertCircle className="w-4 h-4 shrink-0" />
            {error}
          </div>
        )}

        {searched && !loading && !error && (
          <p className="text-xs text-muted-foreground mb-4">
            {results.length} results (page {page} of ~{Math.max(totalPages, 1)})
          </p>
        )}

        {loading && (
          <div className="flex items-center justify-center gap-2 py-16 text-muted-foreground">
            <Loader2 className="w-5 h-5 animate-spin" />
            Searching GitHub...
          </div>
        )}

        {!loading && searched && results.length === 0 && !error && (
          <div className="flex flex-col items-center justify-center gap-2 py-16 text-center text-muted-foreground">
            <p>No deployable bots found for that search.</p>
            <p className="text-xs">Try a different query, or make sure the repo has an app.json.</p>
          </div>
        )}

        <div className="space-y-4">
          {results.map((repo) => (
            <div key={repo.repo_full_name} className="gradient-border p-5">
              <div className="flex items-start justify-between gap-3 mb-3">
                <div className="flex items-center gap-3 min-w-0">
                  <div className="shrink-0 w-11 h-11 rounded-lg border border-border/50 bg-background/40 overflow-hidden flex items-center justify-center">
                    {repo.logo_url ? (
                      <img src={repo.logo_url} alt={repo.name} className="w-full h-full object-cover" />
                    ) : (
                      <Rocket className="w-5 h-5 text-primary" />
                    )}
                  </div>
                  <div className="min-w-0">
                    <p className="font-bold text-foreground truncate">{repo.name}</p>
                    <p className="text-xs text-muted-foreground truncate">by {repo.repo_full_name.split('/')[0]}</p>
                  </div>
                </div>
                <span className="shrink-0 flex items-center gap-1 px-2 py-1 rounded-full bg-warning/10 border border-warning/30 text-warning text-xs font-semibold">
                  <Star className="w-3 h-3 fill-current" />
                  {repo.stars >= 1000 ? `${(repo.stars / 1000).toFixed(1)}k` : repo.stars}
                </span>
              </div>

              <p className="text-sm text-muted-foreground leading-relaxed mb-3 line-clamp-2">
                {repo.description}
              </p>

              <div className="flex items-center gap-3 text-xs text-muted-foreground mb-4">
                {repo.language && (
                  <span className="flex items-center gap-1">
                    <span className="w-2 h-2 rounded-full bg-primary" />
                    {repo.language}
                  </span>
                )}
                <span className="flex items-center gap-1">
                  <GitFork className="w-3 h-3" />
                  {repo.forks}
                </span>
              </div>

              <button
                onClick={() => handleDeploy(repo)}
                className="w-full flex items-center justify-center gap-2 py-3 rounded-xl bg-gradient-to-r from-primary to-secondary text-primary-foreground text-sm font-semibold hover:opacity-90 transition-opacity"
              >
                <Rocket className="w-4 h-4" />
                Deploy to Bmb Tech
              </button>
            </div>
          ))}
        </div>

        {results.length > 0 && (
          <div className="flex items-center justify-between mt-6">
            <button
              onClick={() => runSearch(page - 1)}
              disabled={page <= 1 || loading}
              className="px-4 py-2 rounded-xl border border-border/50 text-sm text-foreground disabled:opacity-40 hover:bg-muted/40 transition-colors"
            >
              ← Previous
            </button>
            <span className="text-xs text-muted-foreground">Page {page} / {Math.max(totalPages, 1)}</span>
            <button
              onClick={() => runSearch(page + 1)}
              disabled={page >= totalPages || loading}
              className="px-4 py-2 rounded-xl border border-border/50 text-sm text-foreground disabled:opacity-40 hover:bg-muted/40 transition-colors"
            >
              Next →
            </button>
          </div>
        )}
      </div>
    </div>
  );
};

export default DiscoverApps;
