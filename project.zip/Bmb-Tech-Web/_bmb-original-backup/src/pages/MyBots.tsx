import { useEffect, useState } from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import {
  Rocket, X, AlertCircle, Bot as BotIcon, CheckCircle2, Plus,
  Activity, PauseCircle, Layers, MessageCircle, ListChecks, ChevronRight,
} from 'lucide-react';
import { supabase } from '@/lib/supabaseClient';
import { useAuth } from '@/context/AuthContext';
import FloatingMenu from '@/components/FloatingMenu';
import TechBackground from '@/components/TechBackground';
import BackButton from '@/components/BackButton';
import Footer from '@/components/Footer';

const MyBots = () => {
  const navigate = useNavigate();
  const location = useLocation();
  const { user } = useAuth();
  const [githubOauthBanner, setGithubOauthBanner] = useState<{ type: 'success' | 'error'; message: string } | null>(null);
  const [totalBots, setTotalBots] = useState(0);
  const [activeCount, setActiveCount] = useState(0);
  const [inactiveCount, setInactiveCount] = useState(0);
  const [unreadChat, setUnreadChat] = useState(0);

  useEffect(() => {
    const params = new URLSearchParams(location.search);
    const connected = params.get('github_connected');
    const errorMsg = params.get('github_error');

    if (connected) {
      setGithubOauthBanner({ type: 'success', message: 'GitHub connected. Open a bot\'s Auto Deploy panel to pick a repo.' });
      navigate('/my-bots', { replace: true });
    } else if (errorMsg) {
      setGithubOauthBanner({ type: 'error', message: errorMsg });
      navigate('/my-bots', { replace: true });
    }
  }, []);

  useEffect(() => {
    const loadCounts = async () => {
      if (!user) return;
      const { data } = await supabase
        .from('deployed_apps')
        .select('id, status, heroku_app_name')
        .eq('user_id', user.id)
        .neq('status', 'deleted');

      const apps = data || [];
      setTotalBots(apps.length);

      const liveApps = apps.filter(a => a.status === 'live');
      let active = 0;
      await Promise.all(
        liveApps.map(async (app) => {
          try {
            const res = await fetch(`/api/heroku-dyno?appName=${app.heroku_app_name}`);
            const info = await res.json();
            if (res.ok && info.state === 'up') active += 1;
          } catch {
            // best-effort — an app we can't reach just doesn't count as active
          }
        })
      );
      setActiveCount(active);
      setInactiveCount(apps.length - active);
    };
    loadCounts();
  }, [user]);

  // Same unread-count logic FloatingMenu already uses for its Community
  // Chat badge, so the two numbers always agree.
  useEffect(() => {
    if (!user) {
      setUnreadChat(0);
      return;
    }

    const refreshUnread = async () => {
      const { data: readState } = await supabase
        .from('chat_read_state')
        .select('last_read_at')
        .eq('user_id', user.id)
        .maybeSingle();
      const lastRead = readState?.last_read_at || new Date(0).toISOString();

      const { count } = await supabase
        .from('chat_messages')
        .select('id', { count: 'exact', head: true })
        .gt('created_at', lastRead)
        .neq('user_id', user.id);

      setUnreadChat(count || 0);
    };

    refreshUnread();

    const channel = supabase
      .channel('mybots-community-unread')
      .on('postgres_changes', { event: 'INSERT', schema: 'public', table: 'chat_messages' }, refreshUnread)
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
  }, [user]);

  return (
    <div className="min-h-screen bg-background text-foreground relative">
      <TechBackground />
      <FloatingMenu />

      <div className="relative z-10 max-w-2xl mx-auto px-4 py-20">
        <BackButton className="mb-4" />

        {githubOauthBanner && (
          <div
            className={`flex items-center justify-between gap-2 px-4 py-3 rounded-xl border mb-4 text-sm ${
              githubOauthBanner.type === 'success'
                ? 'bg-success/10 border-success/40 text-success'
                : 'bg-destructive/10 border-destructive/40 text-destructive'
            }`}
          >
            <span className="flex items-center gap-2">
              {githubOauthBanner.type === 'success' ? (
                <CheckCircle2 className="w-4 h-4 shrink-0" />
              ) : (
                <AlertCircle className="w-4 h-4 shrink-0" />
              )}
              {githubOauthBanner.message}
            </span>
            <button onClick={() => setGithubOauthBanner(null)} className="shrink-0">
              <X className="w-4 h-4" />
            </button>
          </div>
        )}

        {/* Header */}
        <div className="mb-6">
          <p className="flex items-center gap-1.5 text-primary text-xs font-mono tracking-widest mb-2">
            <BotIcon className="w-3.5 h-3.5" />
            WHATSAPP BOTS
          </p>
          <h1 className="text-2xl md:text-3xl font-bold text-foreground mb-1">Manage Bots</h1>
          <p className="text-sm text-muted-foreground">
            Deploy, monitor and control all your bots in one place.
          </p>
        </div>

        {/* Quick actions — three equal tiles, each its own accent colour
            drawn from the app's own palette rather than a copied scheme. */}
        <div className="grid grid-cols-3 gap-3 mb-6">
          <button
            onClick={() => navigate('/bots')}
            className="gradient-border p-4 flex flex-col items-center text-center gap-2.5 hover:opacity-90 transition-opacity bg-gradient-to-br from-primary/15 to-secondary/15"
          >
            <div className="w-11 h-11 rounded-xl bg-gradient-to-br from-primary to-secondary flex items-center justify-center">
              <Plus className="w-5 h-5 text-primary-foreground" />
            </div>
            <p className="text-xs font-semibold text-foreground leading-tight">Deploy New Bot</p>
          </button>

          <button
            onClick={() => navigate('/my-bots/deployments')}
            className="gradient-border p-4 flex flex-col items-center text-center gap-2.5 hover:opacity-90 transition-opacity bg-gradient-to-br from-cyan-500/15 to-blue-500/15"
          >
            <div className="w-11 h-11 rounded-xl bg-gradient-to-br from-cyan-500 to-blue-500 flex items-center justify-center">
              <ListChecks className="w-5 h-5 text-white" />
            </div>
            <p className="text-xs font-semibold text-foreground leading-tight">Bot Deployment</p>
          </button>

          <button
            onClick={() => navigate('/community')}
            className="relative gradient-border p-4 flex flex-col items-center text-center gap-2.5 hover:opacity-90 transition-opacity bg-gradient-to-br from-fuchsia-500/15 to-purple-500/15"
          >
            {unreadChat > 0 && (
              <span className="absolute top-2 right-2 min-w-[18px] h-[18px] px-1 rounded-full bg-destructive text-white text-[10px] font-bold flex items-center justify-center">
                {unreadChat > 9 ? '9+' : unreadChat}
              </span>
            )}
            <div className="w-11 h-11 rounded-xl bg-gradient-to-br from-fuchsia-500 to-purple-500 flex items-center justify-center">
              <MessageCircle className="w-5 h-5 text-white" />
            </div>
            <p className="text-xs font-semibold text-foreground leading-tight">Community Chat</p>
          </button>
        </div>

        {/* Stats */}
        <div className="grid grid-cols-3 gap-3 mb-6">
          <div className="gradient-border p-4 flex items-center gap-3">
            <div className="w-9 h-9 rounded-lg bg-primary/10 border border-primary/30 flex items-center justify-center shrink-0">
              <Layers className="w-4 h-4 text-primary" />
            </div>
            <div className="min-w-0">
              <p className="text-xl font-bold text-foreground leading-none">{totalBots}</p>
              <p className="text-[11px] text-muted-foreground mt-1">Total</p>
            </div>
          </div>

          <div className="gradient-border p-4 flex items-center gap-3">
            <div className="w-9 h-9 rounded-lg bg-success/10 border border-success/30 flex items-center justify-center shrink-0">
              <Activity className="w-4 h-4 text-success" />
            </div>
            <div className="min-w-0">
              <p className="text-xl font-bold text-success leading-none">{activeCount}</p>
              <p className="text-[11px] text-muted-foreground mt-1">Running</p>
            </div>
          </div>

          <div className="gradient-border p-4 flex items-center gap-3">
            <div className="w-9 h-9 rounded-lg bg-warning/10 border border-warning/30 flex items-center justify-center shrink-0">
              <PauseCircle className="w-4 h-4 text-warning" />
            </div>
            <div className="min-w-0">
              <p className="text-xl font-bold text-warning leading-none">{inactiveCount}</p>
              <p className="text-[11px] text-muted-foreground mt-1">Stopped</p>
            </div>
          </div>
        </div>

        {/* Shortcut into the full deployment list */}
        <button
          onClick={() => navigate('/my-bots/deployments')}
          className="w-full gradient-border p-4 flex items-center justify-between gap-3 hover:opacity-90 transition-opacity"
        >
          <div className="flex items-center gap-3">
            <Rocket className="w-4 h-4 text-primary" />
            <span className="text-sm font-semibold text-foreground">View all deployed bots</span>
          </div>
          <ChevronRight className="w-4 h-4 text-muted-foreground" />
        </button>
      </div>

      <Footer />
    </div>
  );
};

export default MyBots;
