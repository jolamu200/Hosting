import { useNavigate } from 'react-router-dom';
import { ArrowLeft, Rocket, Bot as BotIcon, Coins, Webhook, Key, FileText } from 'lucide-react';
import TechBackground from '@/components/TechBackground';
import Footer from '@/components/Footer';

const essentials = [
  { title: 'Getting Started', text: 'Create an account, connect GitHub, and deploy your first bot.' },
  { title: 'Deploying a Bot', text: 'Paste a repo link, fill in the env vars, and go live in minutes.' },
  { title: 'Auto Deploy', text: 'Connect a repo to GitHub and rebuild automatically on every push.' },
  { title: 'Coins & Payments', text: 'How the coin balance works and how to top up.' },
];

const features = [
  { icon: BotIcon, title: 'Bot Management', text: 'Pause, restart, edit env vars, and view logs for any deployed bot.' },
  { icon: Webhook, title: 'GitHub Webhooks', text: 'How auto-deploy hooks are created and what triggers a rebuild.' },
  { icon: Key, title: 'API Access', text: 'Use your API key to manage bots, check your wallet, and more programmatically.' },
  { icon: Coins, title: 'Referrals & Rewards', text: 'Earn coins by referring other users to the platform.' },
];

const Docs = () => {
  const navigate = useNavigate();

  return (
    <div className="min-h-screen bg-background text-foreground relative">
      <TechBackground />

      <div className="relative z-10 max-w-3xl mx-auto px-4 py-8">
        <button
          onClick={() => navigate(-1)}
          className="flex items-center gap-2 text-sm text-muted-foreground hover:text-foreground transition-colors mb-6"
        >
          <ArrowLeft className="w-4 h-4" />
          Back
        </button>

        <div className="text-center mb-12">
          <p className="flex items-center justify-center gap-2 text-primary text-sm font-mono tracking-widest uppercase mb-3">
            <FileText className="w-4 h-4" />
            Bmb Tech Docs
          </p>
          <h1 className="text-2xl md:text-3xl font-bold text-foreground">
            Learn about deploying, managing, and scaling bots on Bmb Tech.
          </h1>
        </div>

        <h2 className="text-lg font-bold text-foreground mb-4">Essentials</h2>
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 mb-10">
          {essentials.map((item) => (
            <div key={item.title} className="gradient-border p-4">
              <p className="font-semibold text-foreground text-sm mb-1">{item.title}</p>
              <p className="text-xs text-muted-foreground leading-relaxed">{item.text}</p>
            </div>
          ))}
        </div>

        <h2 className="text-lg font-bold text-foreground mb-4">Platform Features</h2>
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 mb-10">
          {features.map(({ icon: Icon, title, text }) => (
            <div key={title} className="gradient-border p-4">
              <Icon className="w-4 h-4 text-primary mb-2" />
              <p className="font-semibold text-foreground text-sm mb-1">{title}</p>
              <p className="text-xs text-muted-foreground leading-relaxed">{text}</p>
            </div>
          ))}
        </div>

        <div className="gradient-border p-6 text-center">
          <Key className="w-6 h-6 text-primary mx-auto mb-3" />
          <p className="font-semibold text-foreground mb-1">Looking for the API Reference?</p>
          <p className="text-sm text-muted-foreground mb-4">
            Full endpoint reference for managing bots, wallet, and payments programmatically.
          </p>
          <a
            href="/profile"
            className="inline-flex items-center gap-2 px-5 py-2.5 rounded-xl bg-gradient-to-r from-primary to-secondary text-primary-foreground text-sm font-semibold hover:opacity-90 transition-opacity"
          >
            <Rocket className="w-4 h-4" />
            Get your API Key
          </a>
        </div>
      </div>

      <Footer />
    </div>
  );
};

export default Docs;
