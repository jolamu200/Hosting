import { useEffect, useState } from 'react';
import { User, KeyRound, Palette, AlertTriangle, Camera } from 'lucide-react';
import { supabase } from '@/lib/supabaseClient';
import { useAuth } from '@/context/AuthContext';
import TechBackground from '@/components/TechBackground';
import FloatingMenu from '@/components/FloatingMenu';
import BackButton from '@/components/BackButton';
import ProfileInfoTab from '@/components/profile-tabs/ProfileInfoTab';
import SecurityTab from '@/components/profile-tabs/SecurityTab';
import AppearanceTab from '@/components/profile-tabs/AppearanceTab';
import DangerZoneTab from '@/components/profile-tabs/DangerZoneTab';
import Footer from '@/components/Footer';

interface ProfileData {
  full_name: string;
  username: string;
  phone: string;
  avatar_url: string | null;
  ph_balance: number;
  referral_code: string | null;
  created_at?: string;
}

type TabKey = 'profile' | 'security' | 'appearance' | 'danger';

const Profile = () => {
  const { user } = useAuth();
  const [tab, setTab] = useState<TabKey>('profile');
  const [profile, setProfile] = useState<ProfileData>({
    full_name: '',
    username: '',
    phone: '',
    avatar_url: null,
    ph_balance: 0,
    referral_code: null,
  });
  const [loading, setLoading] = useState(true);
  const [uploading, setUploading] = useState(false);

  useEffect(() => {
    if (!user) return;

    const loadProfile = async () => {
      const { data, error: loadError } = await supabase
        .from('profiles')
        .select('full_name, username, phone, avatar_url, ph_balance, referral_code, updated_at')
        .eq('id', user.id)
        .single();

      if (loadError && loadError.code !== 'PGRST116') {
        console.error('Failed to load profile:', loadError.message);
      }

      // Default the username from the email (e.g. "bmbtech@gmail.com" -> "bmbtech")
      // if one hasn't been set yet, so the field is never blank.
      const emailUsername = user.email ? user.email.split('@')[0] : '';
      const fallbackName = user.user_metadata?.full_name || user.user_metadata?.name || emailUsername || 'Your Name';

      const nextProfile: ProfileData = {
        full_name: data?.full_name || fallbackName,
        username: data?.username || emailUsername,
        phone: data?.phone || '',
        avatar_url: data?.avatar_url || user.user_metadata?.avatar_url || null,
        ph_balance: data?.ph_balance || 0,
        referral_code: data?.referral_code || null,
        created_at: user.created_at,
      };

      setProfile(nextProfile);
      setLoading(false);

      // If this profile row didn't exist yet or was missing a username, save
      // the defaults now so they persist and Save Changes has something real to edit.
      if (!data?.username || !data?.full_name) {
        await supabase.from('profiles').upsert({
          id: user.id,
          full_name: nextProfile.full_name,
          username: nextProfile.username,
          updated_at: new Date().toISOString(),
        });
      }
    };

    loadProfile();
  }, [user]);

  const handleAvatarUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file || !user) return;

    setUploading(true);
    const fileExt = file.name.split('.').pop();
    const filePath = `${user.id}/avatar.${fileExt}`;

    const { error: uploadError } = await supabase.storage
      .from('avatars')
      .upload(filePath, file, { upsert: true });

    if (!uploadError) {
      const { data: publicUrlData } = supabase.storage.from('avatars').getPublicUrl(filePath);
      const avatarUrl = `${publicUrlData.publicUrl}?t=${Date.now()}`;
      setProfile(prev => ({ ...prev, avatar_url: avatarUrl }));
      await supabase.from('profiles').update({ avatar_url: avatarUrl }).eq('id', user.id);
    }

    setUploading(false);
  };

  const initials = (profile.full_name || user?.email || 'U')
    .trim()
    .split(' ')
    .map(w => w[0])
    .join('')
    .slice(0, 2)
    .toUpperCase();

  const memberSince = profile.created_at
    ? new Date(profile.created_at).toLocaleDateString('en-US', { month: 'short', year: 'numeric' })
    : '—';

  const tabs: { key: TabKey; label: string; icon: typeof User }[] = [
    { key: 'profile', label: 'Profile', icon: User },
    { key: 'security', label: 'Security', icon: KeyRound },
    { key: 'appearance', label: 'Appearance', icon: Palette },
    { key: 'danger', label: 'Danger', icon: AlertTriangle },
  ];

  if (loading) {
    return (
      <div className="min-h-screen bg-background text-foreground relative flex items-center justify-center">
        <TechBackground />
        <p className="relative z-10 text-muted-foreground text-sm font-mono tracking-widest">
          LOADING...
        </p>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background text-foreground relative">
      <TechBackground />
      <FloatingMenu />

      <div className="relative z-10 max-w-xl mx-auto px-4 pt-24 pb-16">
        <BackButton className="mb-4" />
        {/* Avatar + name header */}
        <div className="flex flex-col items-center mb-6">
          <div className="relative">
            <div className="w-24 h-24 rounded-full border-2 border-primary/50 overflow-hidden flex items-center justify-center bg-card">
              {profile.avatar_url ? (
                <img src={profile.avatar_url} alt="Avatar" className="w-full h-full object-cover" />
              ) : (
                <span className="text-2xl font-bold text-primary">{initials}</span>
              )}
            </div>
            <label className="absolute bottom-0 right-0 w-9 h-9 rounded-full bg-primary flex items-center justify-center cursor-pointer hover:opacity-90 transition-opacity">
              <Camera className="w-4 h-4 text-primary-foreground" />
              <input
                type="file"
                accept="image/png,image/jpeg,image/webp,image/gif"
                onChange={handleAvatarUpload}
                className="hidden"
                disabled={uploading}
              />
            </label>
          </div>
          {uploading && <p className="text-xs text-muted-foreground mt-2">Uploading...</p>}
          <p className="text-lg font-bold text-foreground mt-3">{profile.full_name}</p>
          <p className="text-sm text-muted-foreground">{user?.email}</p>
        </div>

        {/* Stat cards */}
        <div className="grid grid-cols-3 gap-2 mb-6">
          <div className="gradient-border p-3 text-center">
            <p className="text-lg font-bold text-foreground">{profile.ph_balance}</p>
            <p className="text-[10px] text-muted-foreground mt-0.5">PH Balance</p>
          </div>
          <div className="gradient-border p-3 text-center">
            <p className="text-xs font-bold text-foreground font-mono truncate">{profile.referral_code || '—'}</p>
            <p className="text-[10px] text-muted-foreground mt-0.5">Referral Code</p>
          </div>
          <div className="gradient-border p-3 text-center">
            <p className="text-xs font-bold text-foreground">{memberSince}</p>
            <p className="text-[10px] text-muted-foreground mt-0.5">Member Since</p>
          </div>
        </div>

        {/* Tab switcher */}
        <div className="flex items-center gap-1 p-1 rounded-full bg-card/50 border border-border/40 mb-6 overflow-x-auto">
          {tabs.map(({ key, label, icon: Icon }) => (
            <button
              key={key}
              onClick={() => setTab(key)}
              className={`flex-1 flex items-center justify-center gap-1.5 px-3 py-2.5 rounded-full text-xs font-medium whitespace-nowrap transition-colors ${
                tab === key
                  ? key === 'danger'
                    ? 'bg-destructive text-white'
                    : 'bg-primary text-primary-foreground'
                  : 'text-muted-foreground hover:text-foreground'
              }`}
            >
              <Icon className="w-3.5 h-3.5" />
              <span className="hidden sm:inline">{label}</span>
            </button>
          ))}
        </div>

        {tab === 'profile' && <ProfileInfoTab profile={profile} setProfile={setProfile} />}
        {tab === 'security' && <SecurityTab />}
        {tab === 'appearance' && <AppearanceTab />}
        {tab === 'danger' && <DangerZoneTab />}
      </div>
      <Footer />
    </div>
  );
};

export default Profile;
