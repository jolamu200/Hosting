import FloatingMenu from '@/components/FloatingMenu';
import TechBackground from '@/components/TechBackground';
import ContactSupport from '@/components/ContactSupport';
import BackButton from '@/components/BackButton';
import Footer from '@/components/Footer';

const Contact = () => {
  return (
    <div className="min-h-screen bg-background text-foreground relative" style={{ overflowX: 'hidden', overflowY: 'auto' }}>
      <TechBackground />
      <FloatingMenu />

      <div className="relative z-10 max-w-2xl mx-auto px-4 pt-20">
        <BackButton />
      </div>

      {/* Contact Support Section */}
      <div className="relative flex items-center justify-center px-4 py-6">
        <ContactSupport />

        {/* Corner decorations */}
        <div className="absolute top-8 left-8 w-16 h-16 border-l-2 border-t-2 border-primary/50" />
        <div className="absolute top-8 right-8 w-16 h-16 border-r-2 border-t-2 border-primary/50" />
        <div className="absolute bottom-8 left-8 w-16 h-16 border-l-2 border-b-2 border-secondary/50" />
        <div className="absolute bottom-8 right-8 w-16 h-16 border-r-2 border-b-2 border-secondary/50" />
      </div>

      <Footer />
    </div>
  );
};

export default Contact;
