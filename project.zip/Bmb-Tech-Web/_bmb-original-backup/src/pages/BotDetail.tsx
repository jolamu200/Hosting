import { useEffect, useState, useRef } from 'react';
import { useParams, useNavigate, useLocation } from 'react-router-dom';
import {
  ArrowLeft, Loader2, ExternalLink, Github, KeyRound, AlertCircle,
  CheckCircle2, Rocket, Cpu, HardDrive, FileText, QrCode,
} from 'lucide-react';
import { supabase } from '@/lib/supabaseClient';
import { useAuth } from '@/context/AuthContext';
import FloatingMenu from '@/components/FloatingMenu';
import TechBackground from '@/components/TechBackground';

// Reads a fetch Response as JSON safely — if the server (or an upstream
// service like Heroku, when its team/account is over its limit) returns an
// HTML or plain-text error page instead of JSON, this returns a clean
// fallback object instead of letting `res.json()` throw a raw parser error
// like "Unexpected token 'A'..." straight onto the screen.
const safeJson = async (res: Response): Promise<{ error?: string; [key: string]: any }> => {
  const contentType = res.headers.get('content-type') || '';
  if (!contentType.includes('application/json')) {
    return { error: 'The deploy service is temporarily unavailable. Please try again shortly.' };
  }
  try {
    return await res.json();
  } catch {
    return { error: 'The deploy service is temporarily unavailable. Please try again shortly.' };
  }
};

interface EnvField {
  key: string;
  description?: string;
  required?: boolean;
  value?: string;
}

// app.json's "env" is normally an object keyed by var name, but a couple of
// paths (an older sync job, hand-edited data, etc.) may have written that
// raw object straight into bots_catalog.env_schema instead of converting it
// to the array shape every page here expects. Normalizing at the point of
// use means bad data in the table shows an empty env list instead of
// crashing the whole page with "(...).forEach is not a function".
const normalizeEnvSchema = (raw: unknown): EnvField[] => {
  if (Array.isArray(raw)) return raw as EnvField[];
  if (raw && typeof raw === 'object') {
    return Object.entries(raw as Record<string, any>).map(([key, val]) => ({
      key,
      description: val?.description,
      required: val?.required !== false,
      value: val?.value,
    }));
  }
  return [];
};

interface BotRow {
  id: string | null;
  name: string;
  slug: string;
  description: string;
  repo_url: string;
  repo_full_name: string;
  logo_url: string | null;
  banner_url: string | null;
  tags: string[];
  env_schema: EnvField[];
  ram_mb: number;
  disk_mb: number;
  default_branch?: string;
  session_link?: string | null;
}

type DeployStage = 'form' | 'deploying' | 'building' | 'done' | 'failed';

// Loads the owner-managed API keys (Admin > API Keys) as a { KEY_NAME: value }
// map, so a bot's env form can be pre-filled when a field name matches.
const loadAdminApiKeys = async (): Promise<Record<string, string>> => {
  const { data, error } = await supabase.from('admin_api_keys').select('key_name, key_value');
  if (error || !data) return {};
  const map: Record<string, string> = {};
  data.forEach((row: { key_name: string; key_value: string }) => {
    map[row.key_name] = row.key_value;
  });
  return map;
};

const BotDetail = () => {
  const { slug } = useParams<{ slug: string }>();
  const navigate = useNavigate();
  const location = useLocation();
  const { user } = useAuth();

  const [bot, setBot] = useState<BotRow | null>(null);
  const [loading, setLoading] = useState(true);
  const [retryKey, setRetryKey] = useState(0);
  const [error, setError] = useState('');

  const [appName, setAppName] = useState('');
  const [appNamePlaceholder, setAppNamePlaceholder] = useState('your-app-name');
  const appNameInputRef = useRef<HTMLInputElement | null>(null);

  // Lowercase only, letters/numbers/hyphens only, no spaces — typed or
  // pasted. Anything else (including a space bar press) is silently
  // dropped rather than accepted and then rejected later at submit time.
  const sanitizeAppName = (raw: string) =>
    raw.toLowerCase().replace(/[^a-z0-9-]/g, '').slice(0, 30);
  const [envValues, setEnvValues] = useState<Record<string, string>>({});
  const [stage, setStage] = useState<DeployStage>('form');
  const [buildStep, setBuildStep] = useState(0); // 0=create,1=configure,2=build,3=deploy
  const [buildOutput, setBuildOutput] = useState('');
  const [deployError, setDeployError] = useState('');
  const [appUrl, setAppUrl] = useState('');
  const [deployRowId, setDeployRowId] = useState<string | null>(null);
  const [limitReached, setLimitReached] = useState(false);
  const [isOwner, setIsOwner] = useState(false);
  const pollRef = useRef<ReturnType<typeof setInterval> | null>(null);
  const consoleEndRef = useRef<HTMLDivElement | null>(null);

  useEffect(() => {
    consoleEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [buildOutput]);

  // Check the 3-bot limit up front, on every page load, regardless of which
  // branch below sets up the bot data — so the warning shows before the
  // person even fills in the form. The site owner has no deploy limit.
  useEffect(() => {
    if (!user) return;

    supabase
      .from('profiles')
      .select('role')
      .eq('id', user.id)
      .single()
      .then(({ data }) => {
        const owner = data?.role === 'owner';
        setIsOwner(owner);

        if (owner) {
          setLimitReached(false);
          return;
        }

        supabase
          .from('deployed_apps')
          .select('id', { count: 'exact', head: true })
          .eq('user_id', user.id)
          .in('status', ['live', 'building'])
          .then(({ count }) => setLimitReached((count || 0) >= 3));
      });
  }, [user]);

  useEffect(() => {
    // Deploying directly from a GitHub search result (Discover Apps) —
    // the repo details arrive via navigation state, no catalog lookup needed.
    const navState = location.state as Partial<BotRow> & { default_branch?: string } | null;

    if (slug === 'github-deploy' && navState?.repo_full_name) {
      const envSchema: EnvField[] = Object.entries(navState.env_schema || {}).map(
        ([key, val]: [string, any]) => ({
          key,
          description: val?.description,
          required: val?.required !== false,
          value: val?.value,
        })
      );

      const repoSlug = navState.repo_full_name.split('/')[1]?.toLowerCase().replace(/[^a-z0-9]+/g, '-') || 'app';
      const randomSuffix = Math.random().toString(36).slice(2, 6);

      setBot({
        id: null,
        name: navState.name || navState.repo_full_name,
        slug: 'github-deploy',
        description: navState.description || '',
        repo_url: navState.repo_url || `https://github.com/${navState.repo_full_name}`,
        repo_full_name: navState.repo_full_name,
        logo_url: navState.logo_url || null,
        banner_url: null,
        tags: [],
        env_schema: envSchema,
        ram_mb: 256,
        disk_mb: 1024,
        default_branch: navState.default_branch || 'main',
      });
      setAppNamePlaceholder(`${repoSlug}-${randomSuffix}`.slice(0, 30));
      const defaults: Record<string, string> = {};
      envSchema.forEach((f) => {
        if (f.value) defaults[f.key] = f.value;
      });
      loadAdminApiKeys().then((adminKeys) => {
        const merged = { ...defaults };
        envSchema.forEach((f) => {
          if (!merged[f.key] && adminKeys[f.key]) merged[f.key] = adminKeys[f.key];
        });
        setEnvValues(merged);
      });
      setEnvValues(defaults);
      setLoading(false);
      return;
    }

    const load = async () => {
      try {
        // Guard against a genuinely stuck request (no response at all) —
        // without this, one hung network call left the spinner running
        // forever with no way out and no error shown.
        const withTimeout = <T,>(promise: Promise<T>, ms = 15000): Promise<T> =>
          Promise.race([
            promise,
            new Promise<T>((_, reject) => setTimeout(() => reject(new Error('timeout')), ms)),
          ]);

        const { data, error: fetchError } = await withTimeout(
          supabase.from('bots_catalog').select('*').eq('slug', slug).single()
        );

        if (fetchError || !data) {
          setError('Bot not found.');
          return;
        }

        const normalizedEnvSchema = normalizeEnvSchema(data.env_schema);
        setBot({ ...data, env_schema: normalizedEnvSchema });
        const randomSuffix = Math.random().toString(36).slice(2, 6);
        setAppNamePlaceholder(`${data.slug}-${randomSuffix}`.slice(0, 30));
        const defaults: Record<string, string> = {};
        normalizedEnvSchema.forEach((f: EnvField) => {
          if (f.value) defaults[f.key] = f.value;
        });
        const adminKeys = await withTimeout(loadAdminApiKeys()).catch(() => ({} as Record<string, string>));
        normalizedEnvSchema.forEach((f: EnvField) => {
          if (!defaults[f.key] && adminKeys[f.key]) defaults[f.key] = adminKeys[f.key];
        });
        setEnvValues(defaults);

        // Resume an in-progress deploy for this bot, if one exists — this is
        // what makes a page refresh (or navigating back) not lose progress.
        // Runs after the admin-key defaults above, and overwrites envValues
        // entirely with the saved state, so it always wins.
        if (user) {
          const { data: existing } = await withTimeout(
            supabase
              .from('deployed_apps')
              .select('id, heroku_app_name, build_id, build_step, env_vars')
              .eq('user_id', user.id)
              .eq('bot_id', data.id)
              .eq('status', 'building')
              .order('created_at', { ascending: false })
              .limit(1)
              .maybeSingle()
          ).catch(() => ({ data: null }));

          if (existing?.build_id) {
            setDeployRowId(existing.id);
            setAppName(existing.heroku_app_name);
            setEnvValues(existing.env_vars || {});
            setBuildStep(existing.build_step || 2);
            setStage('building');
            pollBuild(existing.heroku_app_name, existing.build_id, existing.id);
          }
        }
      } catch (err: any) {
        // A hung/failed request (or the timeout above firing) lands here —
        // show a real error with a retry option instead of spinning forever.
        // Log the raw error too so it shows up in the browser console for
        // debugging — the on-screen message stays short and human-readable.
        console.error('BotDetail load failed:', err);
        setError(
          err?.message === 'timeout'
            ? 'This is taking longer than expected. Check your connection and try again.'
            : `Something went wrong loading this bot${err?.message ? ` (${err.message})` : ''}. Please try again.`
        );
      } finally {
        setLoading(false);
      }
    };

    load();

    return () => {
      if (pollRef.current) clearInterval(pollRef.current);
    };
  }, [slug, retryKey]);

  const handleEnvChange = (key: string, value: string) => {
    setEnvValues(prev => ({ ...prev, [key]: value }));
  };

  const pollBuild = (name: string, buildId: string, rowId: string | null) => {
    pollRef.current = setInterval(async () => {
      try {
        const res = await fetch(`/api/heroku-build?appName=${name}&buildId=${buildId}`);
        const data = await safeJson(res);

        if (!res.ok) {
          setDeployError(data.error || 'Failed to check build status.');
          setStage('failed');
          if (pollRef.current) clearInterval(pollRef.current);
          if (rowId) await supabase.from('deployed_apps').update({ status: 'failed' }).eq('id', rowId);
          return;
        }

        if (data.output) setBuildOutput(data.output);

        if (data.status === 'succeeded') {
          setBuildStep(3);
          setAppUrl(data.appUrl);
          setStage('done');
          if (pollRef.current) clearInterval(pollRef.current);

          if (rowId) {
            await supabase
              .from('deployed_apps')
              .update({ app_url: data.appUrl, status: 'live', build_step: 3 })
              .eq('id', rowId);
          }

          if (bot?.id) {
            await supabase.rpc('increment_bot_deploy_count', { p_bot_id: bot.id });
          }
        } else if (data.status === 'failed') {
          setDeployError('Build failed. Check the logs for details.');
          setStage('failed');
          if (pollRef.current) clearInterval(pollRef.current);
          if (rowId) await supabase.from('deployed_apps').update({ status: 'failed' }).eq('id', rowId);
        } else {
          // still pending — nudge the step indicator forward so it doesn't look stuck
          setBuildStep(prev => (prev < 2 ? 2 : prev));
        }
      } catch (err: any) {
        setDeployError(err.message || 'Failed to check build status.');
        setStage('failed');
        if (pollRef.current) clearInterval(pollRef.current);
        if (rowId) await supabase.from('deployed_apps').update({ status: 'failed' }).eq('id', rowId);
      }
    }, 3000);
  };

  const handleDeploy = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!bot || !user) return;

    // The app name field no longer pre-fills a suggested value — the person
    // must type their own, so this is the one field that can genuinely be
    // empty at submit time. Catch it here with a clear message instead of
    // letting it fall through to a generic "Failed to start deployment."
    const trimmedAppName = appName.trim();
    if (!trimmedAppName) {
      setDeployError('Please enter an app name before deploying.');
      appNameInputRef.current?.focus();
      appNameInputRef.current?.scrollIntoView({ behavior: 'smooth', block: 'center' });
      return;
    }
    if (!/^[a-z][a-z0-9-]{2,28}[a-z0-9]$/.test(trimmedAppName)) {
      setDeployError('App name must be 4-30 characters: lowercase letters, numbers, and hyphens only, starting with a letter.');
      appNameInputRef.current?.focus();
      appNameInputRef.current?.scrollIntoView({ behavior: 'smooth', block: 'center' });
      return;
    }

    if (limitReached) {
      setDeployError('You have reached the limit of 3 deployed bots. Delete one to deploy a new bot.');
      return;
    }

    // Double-check right before deploying too, in case another deploy
    // finished in another tab since the page loaded. The owner has no limit.
    if (!isOwner) {
      const { count } = await supabase
        .from('deployed_apps')
        .select('id', { count: 'exact', head: true })
        .eq('user_id', user.id)
        .in('status', ['live', 'building']);

      if ((count || 0) >= 3) {
        setLimitReached(true);
        setDeployError('You have reached the limit of 3 deployed bots. Delete one to deploy a new bot.');
        return;
      }
    }

    // Check required fields
    const missing = (bot.env_schema || []).filter(
      f => f.required !== false && !envValues[f.key]
    );
    if (missing.length > 0) {
      setDeployError(`Please fill in: ${missing.map(f => f.key).join(', ')}`);
      return;
    }

    setDeployError('');
    setStage('deploying');
    setBuildStep(0);
    setTimeout(() => setBuildStep(1), 400);

    try {
      const res = await fetch('/api/heroku-create-app', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          appName: trimmedAppName,
          repoFullName: bot.repo_full_name,
          branch: bot.default_branch || 'main',
          envVars: envValues,
        }),
      });
      const data = await safeJson(res);

      if (!res.ok) {
        setDeployError(data.error || 'Failed to start deployment.');
        setStage('failed');
        return;
      }

      setBuildStep(2);
      setStage('building');
      setBuildOutput('');

      // Record this deploy in progress right away, so it survives refresh
      // and shows up in My Bots even before the build finishes.
      let rowId: string | null = null;
      if (user) {
        const { data: row, error: insertError } = await supabase
          .from('deployed_apps')
          .insert({
            user_id: user.id,
            bot_id: bot.id,
            bot_name: bot.name,
            heroku_app_name: data.appName,
            repo_full_name: bot.repo_full_name,
            build_id: data.buildId,
            status: 'building',
            build_step: 2,
            env_vars: envValues,
          })
          .select('id')
          .single();

        if (row) {
          rowId = row.id;
          setDeployRowId(row.id);
        } else if (insertError) {
          // The Heroku app was already created and IS deploying at this
          // point — this only means Bmb Hosting failed to save its own
          // record of it, which is what made past bots "vanish" from the
          // list even though they were really running. Surface it clearly
          // instead of failing silently, since the person still needs to
          // know their app name (data.appName) to find/manage it later.
          console.error('deployed_apps insert failed:', insertError.message);
          setDeployError(
            `Your bot is deploying under the name "${data.appName}", but saving it to your bot list failed (${insertError.message}). Save this name — you'll need it to find or delete this bot later.`
          );
        }
      }

      pollBuild(data.appName, data.buildId, rowId);
    } catch (err: any) {
      setDeployError(err.message || 'Failed to start deployment.');
      setStage('failed');
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-background text-foreground relative flex items-center justify-center">
        <TechBackground />
        <Loader2 className="relative z-10 w-6 h-6 text-primary animate-spin" />
      </div>
    );
  }

  if (error || !bot) {
    return (
      <div className="min-h-screen bg-background text-foreground relative flex items-center justify-center px-4">
        <TechBackground />
        <div className="relative z-10 text-center">
          <p className="text-muted-foreground mb-4">{error || 'Bot not found.'}</p>
          <div className="flex items-center justify-center gap-4">
            <button
              onClick={() => { setError(''); setLoading(true); setRetryKey((k) => k + 1); }}
              className="text-primary text-sm hover:underline"
            >
              Try Again
            </button>
            <button onClick={() => navigate('/bots')} className="text-muted-foreground text-sm hover:underline">
              Back to Browse Bots
            </button>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background text-foreground relative">
      <TechBackground />
      <FloatingMenu />

      <div className="relative z-10 max-w-2xl mx-auto px-4 py-20">
        <button
          onClick={() => navigate('/bots')}
          className="flex items-center gap-1.5 text-sm text-muted-foreground hover:text-foreground mb-6 transition-colors"
        >
          <ArrowLeft className="w-4 h-4" />
          Available Bots
        </button>

        {/* Bot header */}
        <div className="gradient-border p-6 mb-6">
          <div className="flex items-start gap-4 mb-4">
            <div className="shrink-0 w-16 h-16 rounded-xl border border-primary/40 bg-background/40 flex items-center justify-center overflow-hidden">
              {bot.logo_url ? (
                <img src={bot.logo_url} alt={bot.name} className="w-full h-full object-cover" />
              ) : (
                <Rocket className="w-7 h-7 text-primary" />
              )}
            </div>
            <div className="flex-1 min-w-0">
              <h1 className="text-xl font-bold text-foreground">{bot.name}</h1>
              <p className="text-sm text-muted-foreground mt-1">{bot.description}</p>
            </div>
          </div>

          <div className="flex flex-wrap items-center gap-2 mb-4">
            <span className="flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-background/50 border border-border/50 text-xs text-muted-foreground">
              <Cpu className="w-3.5 h-3.5" />
              {bot.ram_mb} MB RAM
            </span>
            <span className="flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-background/50 border border-border/50 text-xs text-muted-foreground">
              <HardDrive className="w-3.5 h-3.5" />
              {bot.disk_mb} MB Disk
            </span>
            <a
              href={bot.repo_url}
              target="_blank"
              rel="noopener noreferrer"
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-background/50 border border-border/50 text-xs text-muted-foreground hover:text-foreground transition-colors"
            >
              <Github className="w-3.5 h-3.5" />
              View Source
            </a>
          </div>

          {bot.tags?.length > 0 && (
            <div className="flex flex-wrap gap-1.5">
              {bot.tags.map((tag, i) => (
                <span key={i} className="text-[11px] px-2 py-1 rounded bg-primary/10 text-primary">
                  #{tag}
                </span>
              ))}
            </div>
          )}
        </div>

        {/* Get Session ID — only shown when the admin has configured a link for this bot */}
        {bot.session_link && (
          <a
            href={bot.session_link}
            target="_blank"
            rel="noopener noreferrer"
            className="flex items-center justify-center gap-2 w-full py-3.5 rounded-xl bg-primary text-primary-foreground text-sm font-semibold hover:opacity-90 transition-opacity mb-6"
          >
            <QrCode className="w-4 h-4" />
            Get Session ID
            <ExternalLink className="w-3.5 h-3.5" />
          </a>
        )}

        {/* Deploy form / progress */}
        <div className="gradient-border p-6">
          {stage === 'form' && limitReached && (
            <div className="flex flex-col items-center text-center py-4 gap-3">
              <div className="w-12 h-12 rounded-full bg-warning/10 border border-warning/40 flex items-center justify-center">
                <AlertCircle className="w-6 h-6 text-warning" />
              </div>
              <div>
                <p className="font-semibold text-foreground">Bot limit reached</p>
                <p className="text-xs text-muted-foreground mt-1">
                  You can have up to 3 deployed bots at a time. Delete one from My Bots to deploy a new one.
                </p>
              </div>
              <button
                onClick={() => navigate('/my-bots')}
                className="mt-1 px-5 py-2.5 rounded-xl bg-gradient-to-r from-primary to-secondary text-primary-foreground text-sm font-semibold hover:opacity-90 transition-opacity"
              >
                Go to My Bots
              </button>
            </div>
          )}

          {stage === 'form' && !limitReached && (
            <form onSubmit={handleDeploy} className="space-y-4">
              <h2 className="text-sm font-semibold text-muted-foreground tracking-wide uppercase mb-1">
                Deploy Configuration
              </h2>

              {deployError && (
                <div className="flex items-center gap-2 px-3 py-2.5 rounded-xl bg-destructive/10 border border-destructive/40 text-destructive text-xs">
                  <AlertCircle className="w-4 h-4 shrink-0" />
                  {deployError}
                </div>
              )}

              <div>
                <label className="text-xs font-semibold text-muted-foreground tracking-wide uppercase mb-1.5 block">
                  Your App Name
                </label>
                <input
                  ref={appNameInputRef}
                  type="text"
                  required
                  pattern="[a-z][a-z0-9-]{2,28}[a-z0-9]"
                  placeholder={appNamePlaceholder}
                  value={appName}
                  onChange={(e) => setAppName(sanitizeAppName(e.target.value))}
                  onKeyDown={(e) => {
                    if (e.key === ' ') e.preventDefault();
                  }}
                  autoCapitalize="none"
                  autoCorrect="off"
                  spellCheck={false}
                  className="w-full px-4 py-3 rounded-xl bg-background/50 border border-border/60 text-foreground text-sm font-mono focus:outline-none focus:border-primary/60 transition-colors"
                />
                <p className="text-[11px] text-muted-foreground mt-1">
                  Save this name — you will need it to recover or delete your bot later.
                </p>
              </div>

              {(bot.env_schema || []).map((field) => (
                <div key={field.key}>
                  <label className="text-xs font-semibold text-muted-foreground tracking-wide uppercase mb-1.5 flex items-center gap-1.5">
                    <KeyRound className="w-3 h-3" />
                    {field.key}
                    {field.required !== false && <span className="text-destructive">*</span>}
                    {envValues[field.key] && (
                      <span className="normal-case font-medium text-success/90 text-[10px] px-1.5 py-0.5 rounded-full bg-success/10">
                        Auto-filled
                      </span>
                    )}
                  </label>
                  <input
                    type="text"
                    required={field.required !== false}
                    value={envValues[field.key] || ''}
                    onChange={(e) => handleEnvChange(field.key, e.target.value)}
                    placeholder={field.description || field.key}
                    className="w-full px-4 py-3 rounded-xl bg-background/50 border border-border/60 text-foreground text-sm placeholder:text-muted-foreground focus:outline-none focus:border-primary/60 transition-colors"
                  />
                  {field.description && (
                    <p className="text-[11px] text-muted-foreground mt-1">{field.description}</p>
                  )}
                </div>
              ))}

              <button
                type="submit"
                className="w-full flex items-center justify-center gap-2 py-3.5 rounded-xl bg-gradient-to-r from-primary to-secondary text-primary-foreground font-bold tracking-wide hover:opacity-90 transition-opacity mt-2"
              >
                <Rocket className="w-4 h-4" />
                Deploy Bot
              </button>
            </form>
          )}

          {(stage === 'deploying' || stage === 'building') && (
            <div className="py-6">
              <div className="flex flex-col items-center text-center mb-6">
                <Loader2 className="w-8 h-8 text-primary animate-spin mb-3" />
                <p className="font-semibold text-foreground">
                  {stage === 'deploying' ? 'Creating your app...' : 'Building your bot...'}
                </p>
                <p className="text-xs text-muted-foreground mt-1">
                  This usually takes 30 seconds to 5 minutes depending on dependencies.
                </p>
              </div>

              <div className="space-y-2 mb-4">
                {['Create app', 'Configure environment', 'Build app', 'Deploy to Bmb Hosting'].map((label, i) => (
                  <div key={label} className="flex items-center gap-3 px-3 py-2">
                    {i < buildStep ? (
                      <CheckCircle2 className="w-4 h-4 text-success shrink-0" />
                    ) : i === buildStep ? (
                      <Loader2 className="w-4 h-4 text-primary animate-spin shrink-0" />
                    ) : (
                      <span className="w-4 h-4 rounded-full border border-border/60 shrink-0" />
                    )}
                    <span className={`text-sm ${i <= buildStep ? 'text-foreground' : 'text-muted-foreground'}`}>
                      {label}
                    </span>
                  </div>
                ))}
              </div>

              {buildOutput && (
                <div className="bg-black rounded-xl p-3 max-h-72 overflow-y-auto">
                  <pre className="text-[11px] text-success/90 whitespace-pre-wrap font-mono leading-relaxed">
                    {buildOutput}
                  </pre>
                  <div ref={consoleEndRef} />
                </div>
              )}
            </div>
          )}

          {stage === 'done' && (
            <div className="flex flex-col items-center justify-center py-6 gap-4 text-center">
              <CheckCircle2 className="w-10 h-10 text-success" />
              <div>
                <p className="font-semibold text-foreground">Your app was successfully deployed!</p>
                <p className="text-xs text-muted-foreground mt-1 font-mono">{appName}</p>
              </div>
              <div className="flex gap-3 w-full">
                <a
                  href={appUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex-1 flex items-center justify-center gap-2 py-3 rounded-xl border border-primary/50 text-primary text-sm font-medium hover:bg-primary/10 transition-colors"
                >
                  <ExternalLink className="w-4 h-4" />
                  View App
                </a>
                <button
                  onClick={() => navigate('/my-bots')}
                  className="flex-1 flex items-center justify-center gap-2 py-3 rounded-xl bg-gradient-to-r from-primary to-secondary text-primary-foreground text-sm font-semibold hover:opacity-90 transition-opacity"
                >
                  <FileText className="w-4 h-4" />
                  Manage Bots
                </button>
              </div>
            </div>
          )}

          {stage === 'failed' && (
            <div className="py-2">
              <div className="flex flex-col items-center justify-center py-6 gap-4 text-center">
                <AlertCircle className="w-10 h-10 text-destructive" />
                <div>
                  <p className="font-semibold text-foreground">Deployment failed</p>
                  <p className="text-xs text-muted-foreground mt-1">{deployError}</p>
                </div>
                <button
                  onClick={() => setStage('form')}
                  className="px-5 py-2.5 rounded-xl border border-border/60 text-sm text-foreground hover:bg-muted/40 transition-colors"
                >
                  Try Again
                </button>
              </div>

              {buildOutput && (
                <div className="bg-black rounded-xl p-3 max-h-72 overflow-y-auto">
                  <pre className="text-[11px] text-success/90 whitespace-pre-wrap font-mono leading-relaxed">
                    {buildOutput}
                  </pre>
                </div>
              )}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default BotDetail;
