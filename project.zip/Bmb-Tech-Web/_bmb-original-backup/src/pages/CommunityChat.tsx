import { useEffect, useRef, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import {
  ArrowLeft, Send, Users, ShieldAlert, X, Trash2, CornerUpLeft,
  Crown, ShieldCheck, Image as ImageIcon, Mic, Square, Loader2,
} from 'lucide-react';
import { supabase } from '@/lib/supabaseClient';
import { useAuth } from '@/context/AuthContext';
import TechBackground from '@/components/TechBackground';
import { useOnlineCount } from '@/hooks/useOnlineCount';

interface ChatMessageRow {
  id: string;
  user_id: string;
  message: string;
  reply_to_id: string | null;
  created_at: string;
}

// Turns bare URLs inside a chat message into clickable links, WhatsApp-style
// — everything else stays as plain text exactly as typed.
const URL_PATTERN = /(https?:\/\/[^\s]+)/g;
const renderMessageText = (text: string, mine: boolean) => {
  const parts = text.split(URL_PATTERN);
  return parts.map((part, i) =>
    part.startsWith('http://') || part.startsWith('https://') ? (
      <a
        key={i}
        href={part}
        target="_blank"
        rel="noopener noreferrer"
        onClick={(e) => e.stopPropagation()}
        className={`underline break-all ${mine ? 'text-primary-foreground' : 'text-primary'}`}
      >
        {part}
      </a>
    ) : (
      <span key={i}>{part}</span>
    )
  );
};

interface ProfileLite {
  id: string;
  username: string | null;
  full_name: string | null;
  avatar_url: string | null;
  role: string | null;
}

// Media messages are stored as plain text with a marker prefix so no
// database migration is needed — the "message" column keeps working as-is.
const IMAGE_PREFIX = '[[img]]';
const AUDIO_PREFIX = '[[audio]]';

// Storage bucket for uploaded chat photos/voice notes. Create a PUBLIC
// bucket named "chat-media" in Supabase Storage if it doesn't exist yet.
const CHAT_MEDIA_BUCKET = 'chat-media';

const CommunityChat = () => {
  const navigate = useNavigate();
  const { user } = useAuth();
  const onlineCount = useOnlineCount();

  const [messages, setMessages] = useState<ChatMessageRow[]>([]);
  const [profiles, setProfiles] = useState<Record<string, ProfileLite>>({});
  const [input, setInput] = useState('');
  const [replyTo, setReplyTo] = useState<ChatMessageRow | null>(null);
  const [sending, setSending] = useState(false);
  const [showMembers, setShowMembers] = useState(false);
  const [myRole, setMyRole] = useState<string | null>(null);
  const [uploadingMedia, setUploadingMedia] = useState(false);
  const [mediaError, setMediaError] = useState('');
  const [isRecording, setIsRecording] = useState(false);
  const [permissionPrompt, setPermissionPrompt] = useState<'photo' | 'voice' | null>(null);
  const [recordSeconds, setRecordSeconds] = useState(0);
  const endRef = useRef<HTMLDivElement | null>(null);
  const fileInputRef = useRef<HTMLInputElement | null>(null);
  const mediaRecorderRef = useRef<MediaRecorder | null>(null);
  const recordedChunksRef = useRef<Blob[]>([]);
  const recordTimerRef = useRef<ReturnType<typeof setInterval> | null>(null);

  const isOwner = myRole === 'owner';

  const loadProfilesFor = async (userIds: string[]) => {
    const missing = userIds.filter(id => !profiles[id]);
    if (missing.length === 0) return;

    const { data } = await supabase
      .from('profiles')
      .select('id, username, full_name, avatar_url, role')
      .in('id', missing);

    if (data) {
      setProfiles(prev => {
        const next = { ...prev };
        data.forEach(p => { next[p.id] = p; });
        return next;
      });
    }
  };

  useEffect(() => {
    if (!user) return;

    supabase
      .from('profiles')
      .select('role')
      .eq('id', user.id)
      .single()
      .then(({ data }) => setMyRole(data?.role || null));

    const loadMessages = async () => {
      const { data } = await supabase
        .from('chat_messages')
        .select('id, user_id, message, reply_to_id, created_at')
        .order('created_at', { ascending: true })
        .limit(200);

      if (data) {
        setMessages(data);
        loadProfilesFor(data.map(m => m.user_id));
      }
    };

    loadMessages();

    // Realtime subscription — new messages appear instantly for everyone
    const channel = supabase
      .channel('chat_messages_live')
      .on(
        'postgres_changes',
        { event: 'INSERT', schema: 'public', table: 'chat_messages' },
        (payload) => {
          const newMsg = payload.new as ChatMessageRow;
          setMessages(prev => [...prev, newMsg]);
          loadProfilesFor([newMsg.user_id]);
        }
      )
      .on(
        'postgres_changes',
        { event: 'DELETE', schema: 'public', table: 'chat_messages' },
        (payload) => {
          setMessages(prev => prev.filter(m => m.id !== payload.old.id));
        }
      )
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
  }, [user]);

  // Mark the community chat as "read" while on this page, so the unread
  // badge in the menu (which lives outside this page) clears and stays
  // clear. Stamped repeatedly, not just once, so messages that arrive
  // while someone is actively reading don't get counted as unread later.
  useEffect(() => {
    if (!user) return;

    const markReadNow = async () => {
      const { error } = await supabase
        .from('chat_read_state')
        .upsert({ user_id: user.id, last_read_at: new Date().toISOString() }, { onConflict: 'user_id' });
      if (error) console.error('chat_read_state upsert failed:', error.message);
    };

    markReadNow();
    const interval = setInterval(markReadNow, 4000);

    return () => {
      clearInterval(interval);
      markReadNow();
    };
  }, [user]);

  useEffect(() => {
    endRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  const handleSend = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!input.trim() || !user) return;

    setSending(true);
    const { error } = await supabase.from('chat_messages').insert({
      user_id: user.id,
      message: input.trim(),
      reply_to_id: replyTo?.id || null,
    });
    setSending(false);

    if (!error) {
      setInput('');
      setReplyTo(null);

      // Best-effort — a failed push send shouldn't block sending the
      // message itself, so this isn't awaited into the UI state above.
      notifyNewMessage(input.trim().slice(0, 120));
    }
  };

  const handleDelete = async (id: string) => {
    const { error } = await supabase.from('chat_messages').delete().eq('id', id);
    if (error) {
      alert('Could not delete this message: ' + error.message);
    }
  };

  const notifyNewMessage = (preview: string) => {
    if (!user) return;
    const senderName = displayName(user.id);
    const title = 'New community message';
    const body = `${senderName}: ${preview}`;

    // Bell-icon notification (top-right) — everyone sees it in their
    // dropdown even if they weren't online to receive the push.
    supabase.from('notifications').insert({ title, message: body, link: '/community' }).then(({ error }) => {
      if (error) console.error('notifications insert failed:', error.message);
    });

    fetch('/api/push-notifications?step=send', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        title,
        body,
        url: '/community',
        excludeUserId: user.id,
      }),
    })
      .then(async (res) => {
        if (!res.ok) {
          const data = await res.json().catch(() => ({}));
          console.error('Push send failed:', data?.error || res.status);
        }
      })
      .catch((err) => console.error('Push send request failed:', err));
  };

  const sendMediaMessage = async (prefixedMessage: string, preview: string) => {
    if (!user) return;
    const { error } = await supabase.from('chat_messages').insert({
      user_id: user.id,
      message: prefixedMessage,
      reply_to_id: replyTo?.id || null,
    });
    if (!error) {
      setReplyTo(null);
      notifyNewMessage(preview);
    } else {
      setMediaError('Could not send: ' + error.message);
    }
  };

  const handleImageSelect = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    e.target.value = '';
    if (!file || !user) return;

    setUploadingMedia(true);
    setMediaError('');
    const ext = file.name.split('.').pop() || 'jpg';
    const path = `${user.id}/${Date.now()}.${ext}`;

    const { error: uploadError } = await supabase.storage
      .from(CHAT_MEDIA_BUCKET)
      .upload(path, file, { contentType: file.type });

    if (!uploadError) {
      const { data } = supabase.storage.from(CHAT_MEDIA_BUCKET).getPublicUrl(path);
      await sendMediaMessage(`${IMAGE_PREFIX}${data.publicUrl}`, '📷 Photo');
    } else {
      setMediaError('Photo upload failed: ' + uploadError.message);
    }
    setUploadingMedia(false);
  };

  const startRecording = async () => {
    if (!user || isRecording) return;
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      const recorder = new MediaRecorder(stream);
      recordedChunksRef.current = [];

      recorder.ondataavailable = (e) => {
        if (e.data.size > 0) recordedChunksRef.current.push(e.data);
      };

      recorder.onstop = async () => {
        stream.getTracks().forEach((t) => t.stop());
        if (recordTimerRef.current) clearInterval(recordTimerRef.current);
        setIsRecording(false);
        setRecordSeconds(0);

        const blob = new Blob(recordedChunksRef.current, { type: 'audio/webm' });
        if (blob.size === 0) return;

        setUploadingMedia(true);
        const path = `${user.id}/${Date.now()}.webm`;
        const { error: uploadError } = await supabase.storage
          .from(CHAT_MEDIA_BUCKET)
          .upload(path, blob, { contentType: 'audio/webm' });

        if (!uploadError) {
          const { data } = supabase.storage.from(CHAT_MEDIA_BUCKET).getPublicUrl(path);
          await sendMediaMessage(`${AUDIO_PREFIX}${data.publicUrl}`, '🎤 Voice message');
        } else {
          setMediaError('Voice upload failed: ' + uploadError.message);
        }
        setUploadingMedia(false);
      };

      mediaRecorderRef.current = recorder;
      recorder.start();
      setIsRecording(true);
      setRecordSeconds(0);
      recordTimerRef.current = setInterval(() => setRecordSeconds((s) => s + 1), 1000);
    } catch (err: any) {
      setMediaError('Microphone access failed: ' + (err?.message || 'permission denied or unavailable'));
    }
  };

  const stopRecording = () => {
    mediaRecorderRef.current?.stop();
  };

  const cancelRecording = () => {
    if (mediaRecorderRef.current) {
      recordedChunksRef.current = [];
      mediaRecorderRef.current.onstop = () => {
        mediaRecorderRef.current?.stream.getTracks().forEach((t) => t.stop());
      };
      mediaRecorderRef.current.stop();
    }
    if (recordTimerRef.current) clearInterval(recordTimerRef.current);
    setIsRecording(false);
    setRecordSeconds(0);
  };

  const displayName = (uid: string) => {
    const p = profiles[uid];
    return p?.username || p?.full_name || 'User';
  };

  const roleLabel = (uid: string) => {
    if (!user) return null;
    const p = profiles[uid];
    if (!p?.role) return null;
    return p.role === 'owner' ? 'Owner' : 'Admin';
  };

  const findMessage = (id: string | null) => (id ? messages.find(m => m.id === id) : null);

  return (
    <div className="h-[100dvh] bg-background text-foreground relative flex flex-col overflow-hidden">
      <TechBackground />

      {/* Header */}
      <div className="relative z-10 shrink-0 flex items-center justify-between gap-3 px-4 pt-20 pb-3 border-b border-border/40">
        <button onClick={() => navigate('/my-bots')} className="text-muted-foreground hover:text-foreground shrink-0">
          <ArrowLeft className="w-5 h-5" />
        </button>
        <div className="flex-1 min-w-0">
          <p className="font-bold text-foreground truncate">Community Chat</p>
          <p className="text-xs text-muted-foreground truncate">Bmb Hosting members · Public room</p>
        </div>
        <button
          onClick={() => setShowMembers(true)}
          className="flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-card/60 border border-border/50 text-xs text-foreground shrink-0"
        >
          <Users className="w-3.5 h-3.5 text-success" />
          {onlineCount}
        </button>
      </div>

      {/* Messages */}
      <div className="relative z-10 flex-1 overflow-y-auto px-4 py-4 space-y-3">
        {messages.map((msg) => {
          const mine = msg.user_id === user?.id;
          const role = roleLabel(msg.user_id);
          const quoted = findMessage(msg.reply_to_id);
          const senderAvatar = profiles[msg.user_id]?.avatar_url;
          const senderInitials = displayName(msg.user_id).slice(0, 2).toUpperCase();

          return (
            <div key={msg.id} className={`flex items-end gap-2 ${mine ? 'flex-row-reverse' : 'flex-row'}`}>
              {!mine && (
                <div className="w-8 h-8 rounded-full bg-primary/10 border border-primary/30 flex items-center justify-center overflow-hidden shrink-0 mb-1">
                  {senderAvatar ? (
                    <img src={senderAvatar} alt="" className="w-full h-full object-cover" />
                  ) : (
                    <span className="text-[10px] font-bold text-primary">{senderInitials}</span>
                  )}
                </div>
              )}

              <div className={`flex flex-col ${mine ? 'items-end' : 'items-start'} min-w-0`}>
              {!mine && (
                <div className="flex items-center gap-1.5 mb-1 px-1">
                  <span className="text-xs font-semibold text-foreground">{displayName(msg.user_id)}</span>
                  {role && (
                    <span className={`flex items-center gap-0.5 px-1.5 py-0.5 rounded-full text-[10px] font-bold ${
                      role === 'Owner' ? 'bg-warning/20 text-warning' : 'bg-primary/20 text-primary'
                    }`}>
                      {role === 'Owner' ? <Crown className="w-2.5 h-2.5" /> : <ShieldCheck className="w-2.5 h-2.5" />}
                      {role}
                    </span>
                  )}
                  <span className="text-[10px] text-muted-foreground">
                    {new Date(msg.created_at).toLocaleDateString('en-US', { day: '2-digit', month: 'short' })}
                  </span>
                </div>
              )}

              <div className={`group max-w-full ${mine ? 'items-end' : 'items-start'} flex flex-col`}>
                {quoted && (
                  <div className="mb-1 px-3 py-1.5 rounded-xl bg-card/40 border-l-2 border-primary/50 text-xs text-muted-foreground max-w-full">
                    <p className="font-semibold text-foreground/80">{displayName(quoted.user_id)}</p>
                    <p className="truncate">{quoted.message}</p>
                  </div>
                )}

                {msg.message.startsWith(IMAGE_PREFIX) ? (
                  <div className={`relative rounded-2xl overflow-hidden max-w-[220px] ${mine ? 'rounded-br-sm' : 'rounded-bl-sm'}`}>
                    <img
                      src={msg.message.slice(IMAGE_PREFIX.length)}
                      alt="Shared photo"
                      className="w-full h-auto max-h-72 object-cover"
                    />
                  </div>
                ) : msg.message.startsWith(AUDIO_PREFIX) ? (
                  <div
                    className={`relative rounded-2xl px-3 py-2.5 min-w-[220px] ${
                      mine
                        ? 'bg-primary text-primary-foreground rounded-br-sm'
                        : 'bg-card border border-border/40 text-foreground rounded-bl-sm'
                    }`}
                  >
                    <audio controls src={msg.message.slice(AUDIO_PREFIX.length)} className="w-full h-9" />
                  </div>
                ) : (
                  <div
                    className={`relative rounded-2xl px-4 py-2.5 text-sm break-words ${
                      mine
                        ? 'bg-primary text-primary-foreground rounded-br-sm'
                        : 'bg-card border border-border/40 text-foreground rounded-bl-sm'
                    }`}
                  >
                    {renderMessageText(msg.message, mine)}
                  </div>
                )}

                <div className="flex items-center gap-3 mt-1 px-1 opacity-0 group-hover:opacity-100 transition-opacity">
                  <button
                    onClick={() => setReplyTo(msg)}
                    className="text-[10px] text-muted-foreground hover:text-foreground flex items-center gap-1"
                  >
                    <CornerUpLeft className="w-3 h-3" />
                    Reply
                  </button>
                  {(mine || isOwner) && (
                    <button
                      onClick={() => handleDelete(msg.id)}
                      className="text-[10px] text-destructive hover:underline flex items-center gap-1"
                    >
                      <Trash2 className="w-3 h-3" />
                      Delete
                    </button>
                  )}
                  {mine && (
                    <span className="text-[10px] text-primary-foreground/70">
                      {new Date(msg.created_at).toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit' })}
                    </span>
                  )}
                </div>
              </div>
              </div>
            </div>
          );
        })}
        <div ref={endRef} />
      </div>

      {/* Reply preview */}
      {replyTo && (
        <div className="relative z-10 shrink-0 flex items-center justify-between gap-3 px-4 py-2 bg-card/60 border-t border-border/40">
          <div className="min-w-0">
            <p className="text-xs font-semibold text-primary">Replying to {displayName(replyTo.user_id)}</p>
            <p className="text-xs text-muted-foreground truncate">{replyTo.message}</p>
          </div>
          <button onClick={() => setReplyTo(null)} className="text-muted-foreground hover:text-foreground shrink-0">
            <X className="w-4 h-4" />
          </button>
        </div>
      )}

      {/* Composer */}
      <div className="relative z-10 shrink-0 border-t border-border/40" style={{ paddingBottom: 'env(safe-area-inset-bottom)' }}>
        {mediaError && (
          <div className="flex items-center justify-between gap-2 px-4 py-2 bg-destructive/10 border-b border-destructive/30 text-destructive text-xs">
            <span className="truncate">{mediaError}</span>
            <button onClick={() => setMediaError('')} className="shrink-0">
              <X className="w-3.5 h-3.5" />
            </button>
          </div>
        )}
        {isRecording ? (
          <div className="flex items-center gap-3 px-4 py-3">
            <span className="w-2.5 h-2.5 rounded-full bg-destructive animate-pulse shrink-0" />
            <span className="flex-1 text-sm text-foreground">
              Recording... {String(Math.floor(recordSeconds / 60)).padStart(2, '0')}:{String(recordSeconds % 60).padStart(2, '0')}
            </span>
            <button
              type="button"
              onClick={cancelRecording}
              className="shrink-0 w-11 h-11 rounded-xl border border-border/60 flex items-center justify-center text-muted-foreground hover:text-foreground transition-colors"
              aria-label="Cancel recording"
            >
              <X className="w-4 h-4" />
            </button>
            <button
              type="button"
              onClick={stopRecording}
              className="shrink-0 w-11 h-11 rounded-xl bg-gradient-to-r from-primary to-secondary flex items-center justify-center text-primary-foreground"
              aria-label="Send voice message"
            >
              <Square className="w-4 h-4" />
            </button>
          </div>
        ) : (
          <form onSubmit={handleSend} className="flex items-end gap-2 px-4 py-3">
            <input
              ref={fileInputRef}
              type="file"
              accept="image/*"
              onChange={handleImageSelect}
              className="hidden"
            />
            <button
              type="button"
              onClick={() => {
                if (localStorage.getItem('bmb_photo_permission_seen')) {
                  fileInputRef.current?.click();
                } else {
                  setPermissionPrompt('photo');
                }
              }}
              disabled={uploadingMedia}
              className="shrink-0 w-11 h-11 rounded-xl border border-border/60 flex items-center justify-center text-muted-foreground hover:text-foreground transition-colors disabled:opacity-50"
              aria-label="Send a photo"
            >
              {uploadingMedia ? <Loader2 className="w-4 h-4 animate-spin" /> : <ImageIcon className="w-4 h-4" />}
            </button>

            <textarea
              value={input}
              onChange={(e) => setInput(e.target.value)}
              onKeyDown={(e) => {
                if (e.key === 'Enter' && !e.shiftKey) {
                  e.preventDefault();
                  handleSend(e);
                }
              }}
              rows={1}
              placeholder="Message... (Shift+Enter to send)"
              className="flex-1 px-4 py-2.5 rounded-xl bg-background/50 border border-border/60 text-foreground text-sm placeholder:text-muted-foreground focus:outline-none focus:border-primary/60 transition-colors resize-none max-h-24"
            />

            {input.trim() ? (
              <button
                type="submit"
                disabled={sending}
                className="shrink-0 w-11 h-11 rounded-xl bg-gradient-to-r from-primary to-secondary flex items-center justify-center text-primary-foreground disabled:opacity-50 transition-opacity"
                aria-label="Send message"
              >
                <Send className="w-4 h-4" />
              </button>
            ) : (
              <button
                type="button"
                onClick={() => {
                  if (localStorage.getItem('bmb_voice_permission_seen')) {
                    startRecording();
                  } else {
                    setPermissionPrompt('voice');
                  }
                }}
                disabled={uploadingMedia}
                className="shrink-0 w-11 h-11 rounded-xl bg-gradient-to-r from-primary to-secondary flex items-center justify-center text-primary-foreground disabled:opacity-50 transition-opacity"
                aria-label="Record a voice message"
              >
                <Mic className="w-4 h-4" />
              </button>
            )}
          </form>
        )}
      </div>

      {/* Members / manage admins modal */}
      {showMembers && (
        <MembersModal
          isOwner={isOwner}
          onClose={() => setShowMembers(false)}
        />
      )}

      {/* Explains WHY we need camera/photos or microphone access before the
          browser's own native permission popup appears — so that native
          prompt isn't the first thing a person sees out of nowhere. */}
      {permissionPrompt && (
        <div
          className="fixed inset-0 z-[75] flex items-center justify-center bg-background/80 backdrop-blur-sm px-4"
          onClick={() => setPermissionPrompt(null)}
        >
          <div className="relative w-full max-w-sm gradient-border p-6 text-center" onClick={(e) => e.stopPropagation()}>
            <button
              onClick={() => setPermissionPrompt(null)}
              className="absolute top-4 right-4 w-7 h-7 rounded-full flex items-center justify-center bg-muted/40 text-muted-foreground hover:text-foreground transition-colors"
            >
              <X className="w-4 h-4" />
            </button>

            <div className="w-14 h-14 rounded-2xl bg-gradient-to-br from-primary to-secondary flex items-center justify-center mx-auto mb-4">
              {permissionPrompt === 'photo' ? (
                <ImageIcon className="w-7 h-7 text-primary-foreground" />
              ) : (
                <Mic className="w-7 h-7 text-primary-foreground" />
              )}
            </div>

            <h2 className="text-lg font-bold text-foreground mb-2">
              {permissionPrompt === 'photo' ? 'Allow photo access' : 'Allow microphone access'}
            </h2>
            <p className="text-sm text-muted-foreground mb-5">
              {permissionPrompt === 'photo'
                ? 'To send a photo in the chat, Bmb Hosting needs access to your camera or gallery. Your browser will ask you to confirm next.'
                : 'To send a voice message, Bmb Hosting needs access to your microphone. Your browser will ask you to confirm next.'}
            </p>

            <button
              onClick={() => {
                const kind = permissionPrompt;
                setPermissionPrompt(null);
                // Only show this explainer the first time — after that, a
                // tap goes straight to the picker/recorder like normal.
                localStorage.setItem(`bmb_${kind}_permission_seen`, '1');
                if (kind === 'photo') fileInputRef.current?.click();
                else startRecording();
              }}
              className="w-full py-3 rounded-xl bg-gradient-to-r from-primary to-secondary text-primary-foreground text-sm font-bold hover:opacity-90 transition-opacity mb-2"
            >
              Continue
            </button>
            <button
              onClick={() => setPermissionPrompt(null)}
              className="text-sm text-muted-foreground hover:text-foreground transition-colors"
            >
              Not now
            </button>
          </div>
        </div>
      )}
    </div>
  );
};

// Separate component so its own state doesn't clutter the chat component.
const MembersModal = ({ isOwner, onClose }: { isOwner: boolean; onClose: () => void }) => {
  const [members, setMembers] = useState<ProfileLite[]>([]);
  const [loading, setLoading] = useState(true);
  const [selected, setSelected] = useState<ProfileLite | null>(null);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState('');

  useEffect(() => {
    supabase
      .from('profiles')
      .select('id, username, full_name, avatar_url, role')
      .order('username', { ascending: true })
      .then(({ data }) => {
        setMembers(data || []);
        setLoading(false);
      });
  }, []);

  const handleSetRole = async (userId: string, role: 'admin' | null) => {
    setSaving(true);
    setError('');

    const { data, error: updateError } = await supabase
      .from('profiles')
      .update({ role })
      .eq('id', userId)
      .select('id, role');

    setSaving(false);

    if (updateError) {
      setError(updateError.message);
      return;
    }
    if (!data || data.length === 0) {
      setError('Could not update this member — you may not have permission.');
      return;
    }

    setMembers(prev => prev.map(m => (m.id === userId ? { ...m, role } : m)));
    setSelected(null);
  };

  return (
    <div className="fixed inset-0 z-[60] flex items-center justify-center bg-background/80 backdrop-blur-sm px-4" onClick={onClose}>
      <div className="w-full max-w-sm max-h-[80vh] overflow-y-auto gradient-border p-5" onClick={(e) => e.stopPropagation()}>
        <div className="flex items-center justify-between mb-4">
          <p className="font-semibold text-foreground flex items-center gap-2">
            <Users className="w-4 h-4 text-primary" />
            Members
          </p>
          <button onClick={onClose} className="text-muted-foreground hover:text-foreground">
            <X className="w-5 h-5" />
          </button>
        </div>

        {loading ? (
          <p className="text-xs text-muted-foreground text-center py-8">Loading...</p>
        ) : (
          <div className="space-y-1.5">
            {members.map((m) => (
              <button
                key={m.id}
                onClick={() => isOwner && setSelected(m)}
                disabled={!isOwner || m.role === 'owner'}
                className="w-full flex items-center gap-3 p-2.5 rounded-xl hover:bg-muted/30 transition-colors disabled:hover:bg-transparent text-left"
              >
                <div className="w-8 h-8 rounded-full bg-primary/10 border border-primary/30 flex items-center justify-center overflow-hidden shrink-0">
                  {m.avatar_url ? (
                    <img src={m.avatar_url} alt="" className="w-full h-full object-cover" />
                  ) : (
                    <span className="text-[10px] font-bold text-primary">
                      {(m.username || m.full_name || 'U').slice(0, 2).toUpperCase()}
                    </span>
                  )}
                </div>
                <span className="text-sm text-foreground flex-1 truncate">{m.username || m.full_name}</span>
                {m.role === 'owner' && (
                  <span className="flex items-center gap-1 text-[10px] font-bold text-warning">
                    <Crown className="w-3 h-3" /> Owner
                  </span>
                )}
                {m.role === 'admin' && (
                  <span className="flex items-center gap-1 text-[10px] font-bold text-primary">
                    <ShieldCheck className="w-3 h-3" /> Admin
                  </span>
                )}
              </button>
            ))}
          </div>
        )}
      </div>

      {/* Promote/demote confirm */}
      {selected && (
        <div className="fixed inset-0 z-[70] flex items-center justify-center bg-background/80 backdrop-blur-sm px-4" onClick={() => setSelected(null)}>
          <div className="w-full max-w-xs gradient-border p-5" onClick={(e) => e.stopPropagation()}>
            <div className="flex items-center gap-2 mb-3">
              <ShieldAlert className="w-5 h-5 text-primary" />
              <p className="font-semibold text-foreground text-sm">{selected.username || selected.full_name}</p>
            </div>

            {error && (
              <p className="text-xs text-destructive mb-3">{error}</p>
            )}

            <div className="flex flex-col gap-2">
              {selected.role !== 'admin' ? (
                <button
                  onClick={() => handleSetRole(selected.id, 'admin')}
                  disabled={saving}
                  className="py-2.5 rounded-xl bg-gradient-to-r from-primary to-secondary text-primary-foreground text-sm font-semibold disabled:opacity-60"
                >
                  Make Admin
                </button>
              ) : (
                <button
                  onClick={() => handleSetRole(selected.id, null)}
                  disabled={saving}
                  className="py-2.5 rounded-xl border border-destructive/40 text-destructive text-sm font-semibold disabled:opacity-60"
                >
                  Remove Admin
                </button>
              )}
              <button onClick={() => setSelected(null)} className="py-2.5 rounded-xl border border-border/50 text-foreground text-sm">
                Cancel
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default CommunityChat;
