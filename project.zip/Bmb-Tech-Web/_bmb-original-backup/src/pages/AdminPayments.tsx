import { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Loader2, Receipt, Clock, CheckCircle2, XCircle } from 'lucide-react';
import { supabase } from '@/lib/supabaseClient';
import { useAuth } from '@/context/AuthContext';
import TechBackground from '@/components/TechBackground';
import BackButton from '@/components/BackButton';
import { topupCountries } from '@/data/topupCountries';

interface TopupRow {
  id: string;
  user_id: string;
  country: string;
  method: string;
  coins: number;
  amount: number;
  currency: string;
  phone: string | null;
  status: string;
  provider_ref: string | null;
  created_at: string;
}

interface ProfileLite {
  username: string | null;
  full_name: string | null;
}

const statusStyles: Record<string, string> = {
  completed: 'bg-success/15 text-success',
  pending: 'bg-warning/15 text-warning',
  failed: 'bg-destructive/15 text-destructive',
};

const statusIcons: Record<string, typeof Clock> = {
  completed: CheckCircle2,
  pending: Clock,
  failed: XCircle,
};

const AdminPayments = () => {
  const navigate = useNavigate();
  const { user, loading: authLoading } = useAuth();
  const [checkingAccess, setCheckingAccess] = useState(true);
  const [hasAccess, setHasAccess] = useState(false);

  const [activeCountry, setActiveCountry] = useState(
    topupCountries.find((c) => c.active)?.code || 'tanzania'
  );
  const [rows, setRows] = useState<TopupRow[]>([]);
  const [profiles, setProfiles] = useState<Record<string, ProfileLite>>({});
  const [loading, setLoading] = useState(true);

  // Strictly the real Owner account — the password-based admin session
  // (used elsewhere in /admin) does not grant access to this page.
  useEffect(() => {
    if (authLoading) return;
    if (!user) { navigate('/'); return; }

    supabase
      .from('profiles')
      .select('role')
      .eq('id', user.id)
      .single()
      .then(({ data }) => {
        if (data?.role === 'owner') {
          setHasAccess(true);
        } else {
          navigate('/');
        }
        setCheckingAccess(false);
      });
  }, [user, authLoading, navigate]);

  const currentCountry = topupCountries.find((c) => c.code === activeCountry);

  useEffect(() => {
    if (!hasAccess || !currentCountry?.active) {
      setRows([]);
      setLoading(false);
      return;
    }

    setLoading(true);
    supabase
      .from('coin_topups')
      .select('id, user_id, country, method, coins, amount, currency, phone, status, provider_ref, created_at')
      .eq('country', activeCountry)
      .order('created_at', { ascending: false })
      .then(async ({ data }) => {
        setRows(data || []);
        const userIds = [...new Set((data || []).map((r) => r.user_id))];
        if (userIds.length > 0) {
          const { data: profs } = await supabase
            .from('profiles')
            .select('id, username, full_name')
            .in('id', userIds);
          const map: Record<string, ProfileLite> = {};
          (profs || []).forEach((p: any) => { map[p.id] = p; });
          setProfiles(map);
        }
        setLoading(false);
      });
  }, [hasAccess, activeCountry, currentCountry]);

  if (checkingAccess) {
    return (
      <div className="min-h-screen bg-background text-foreground relative flex items-center justify-center">
        <TechBackground />
        <p className="relative z-10 text-muted-foreground text-sm font-mono tracking-widest">CHECKING ACCESS...</p>
      </div>
    );
  }

  if (!hasAccess) return null;

  return (
    <div className="min-h-screen bg-background text-foreground relative">
      <TechBackground />
      <div className="relative z-10 max-w-4xl mx-auto px-4 py-10">
        <BackButton className="mb-4" fallback="/admin" />

        <p className="text-primary font-mono text-xs tracking-widest mb-1">ADMIN · OWNER ONLY</p>
        <h1 className="text-2xl md:text-3xl font-bold gradient-text tracking-wider mb-6">Payments</h1>

        {/* Country tabs */}
        <div className="flex gap-2 mb-6 border-b border-border/50 overflow-x-auto scrollbar-none">
          {topupCountries.map((c) => (
            <button
              key={c.code}
              onClick={() => setActiveCountry(c.code)}
              className={`flex items-center gap-2 px-4 py-3 text-sm font-medium border-b-2 transition-colors shrink-0 whitespace-nowrap ${
                activeCountry === c.code
                  ? 'border-primary text-primary'
                  : 'border-transparent text-muted-foreground hover:text-foreground'
              }`}
            >
              <span>{c.flagEmoji}</span>
              {c.name}
            </button>
          ))}
        </div>

        {!currentCountry?.active ? (
          <div className="flex flex-col items-center justify-center gap-3 py-20 text-center">
            <Clock className="w-10 h-10 text-muted-foreground" />
            <p className="text-muted-foreground">
              Payments for {currentCountry?.name} aren't live yet — coming soon.
            </p>
          </div>
        ) : loading ? (
          <div className="flex items-center justify-center gap-2 py-20 text-muted-foreground">
            <Loader2 className="w-5 h-5 animate-spin" />
            Loading transactions...
          </div>
        ) : rows.length === 0 ? (
          <div className="flex flex-col items-center justify-center gap-3 py-20 text-center">
            <Receipt className="w-10 h-10 text-muted-foreground" />
            <p className="text-muted-foreground">No transactions yet for {currentCountry.name}.</p>
          </div>
        ) : (
          <div className="space-y-3">
            {rows.map((row) => {
              const StatusIcon = statusIcons[row.status] || Clock;
              const who = profiles[row.user_id];
              return (
                <div key={row.id} className="gradient-border p-4 flex items-center justify-between gap-3">
                  <div className="min-w-0">
                    <p className="font-semibold text-foreground truncate">
                      {who?.username ? `@${who.username}` : who?.full_name || 'Unknown user'}
                    </p>
                    <p className="text-xs text-muted-foreground font-mono">
                      {row.coins} Coins · {row.currency} {Number(row.amount).toLocaleString()} · {row.method}
                    </p>
                    {row.phone && (
                      <p className="text-[11px] text-muted-foreground">{row.phone}</p>
                    )}
                    <p className="text-[10px] text-muted-foreground mt-1">
                      {new Date(row.created_at).toLocaleString()}
                    </p>
                  </div>
                  <span className={`shrink-0 flex items-center gap-1 px-2.5 py-1 rounded-full text-[11px] font-bold ${statusStyles[row.status] || 'bg-muted text-muted-foreground'}`}>
                    <StatusIcon className="w-3 h-3" />
                    {row.status}
                  </span>
                </div>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
};

export default AdminPayments;
