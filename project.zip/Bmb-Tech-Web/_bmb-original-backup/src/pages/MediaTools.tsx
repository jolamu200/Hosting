import { tools } from '@/data/tools';
import FloatingMenu from '@/components/FloatingMenu';
import WebsiteStatus from '@/components/WebsiteStatus';
import TechBackground from '@/components/TechBackground';
import BackButton from '@/components/BackButton';
import Footer from '@/components/Footer';

const MediaTools = () => {
  return (
    <div className="min-h-screen bg-background text-foreground relative" style={{ overflowX: 'hidden', overflowY: 'auto' }}>
      <TechBackground />
      <FloatingMenu />

      <div className="pt-16">
        <div className="max-w-5xl mx-auto px-4 mb-2">
          <BackButton />
        </div>
        <WebsiteStatus tools={tools} />
      </div>
      <Footer />
    </div>
  );
};

export default MediaTools;
