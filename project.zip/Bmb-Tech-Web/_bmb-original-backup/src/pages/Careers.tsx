import { useNavigate } from 'react-router-dom';
import { ArrowLeft, Rocket, Heart, Globe, GraduationCap, Users, Sparkles } from 'lucide-react';
import TechBackground from '@/components/TechBackground';
import Footer from '@/components/Footer';

const benefits = [
  { icon: Globe, title: 'Remote-first culture', text: 'Work from anywhere — we care about output, not office hours.' },
  { icon: GraduationCap, title: 'Learning & growth', text: 'Room to pick up new tools, languages, and infrastructure skills on the job.' },
  { icon: Users, title: 'A tight-knit team', text: "Small enough that your work is seen, big enough that you're never alone on a hard problem." },
  { icon: Sparkles, title: 'Build what you use', text: 'Everyone here deploys bots and uses the platform daily — you feel the impact of your own work.' },
];

const Careers = () => {
  const navigate = useNavigate();

  return (
    <div className="min-h-screen bg-background text-foreground relative">
      <TechBackground />

      <div className="relative z-10 max-w-3xl mx-auto px-4 py-8">
        <button
          onClick={() => navigate(-1)}
          className="flex items-center gap-2 text-sm text-muted-foreground hover:text-foreground transition-colors mb-6"
        >
          <ArrowLeft className="w-4 h-4" />
          Back
        </button>

        <div className="rounded-2xl bg-gradient-to-r from-primary to-secondary p-8 mb-10 text-center">
          <p className="flex items-center justify-center gap-2 text-primary-foreground/80 text-sm font-semibold tracking-widest uppercase mb-2">
            <Rocket className="w-4 h-4" />
            Careers at Bmb Tech
          </p>
          <h1 className="text-2xl md:text-3xl font-bold text-primary-foreground">
            Help build the easiest way to host WhatsApp bots
          </h1>
        </div>

        <div className="space-y-4 text-sm text-muted-foreground leading-relaxed mb-12">
          <p>
            Bmb Tech Hosting is a small, fast-moving team building the Bmb Tech Project — a platform that lets
            anyone deploy, manage, and scale WhatsApp bots without touching a server. We handle the
            infrastructure so builders can focus on what their bots actually do.
          </p>
          <p>
            We're driven by a simple idea: deploying a bot should be as easy as pasting a GitHub link. Everything
            we build — from the coin system to auto-deploys — exists to make that true.
          </p>
        </div>

        <h2 className="text-xl font-bold text-foreground mb-5">Why work with us</h2>
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 mb-12">
          {benefits.map(({ icon: Icon, title, text }) => (
            <div key={title} className="gradient-border p-5">
              <Icon className="w-5 h-5 text-primary mb-3" />
              <p className="font-semibold text-foreground text-sm mb-1">{title}</p>
              <p className="text-xs text-muted-foreground leading-relaxed">{text}</p>
            </div>
          ))}
        </div>

        <div className="gradient-border p-6 text-center">
          <Heart className="w-6 h-6 text-primary mx-auto mb-3" />
          <p className="font-semibold text-foreground mb-1">No open positions right now</p>
          <p className="text-sm text-muted-foreground mb-4">
            We're not actively hiring at the moment, but we're always happy to hear from people who want to build
            with us. Reach out and introduce yourself.
          </p>
          <a
            href="/contact"
            className="inline-flex items-center gap-2 px-5 py-2.5 rounded-xl bg-gradient-to-r from-primary to-secondary text-primary-foreground text-sm font-semibold hover:opacity-90 transition-opacity"
          >
            Get in touch
          </a>
        </div>
      </div>

      <Footer />
    </div>
  );
};

export default Careers;
