import { useEffect, useState, useRef, useCallback } from 'react';
import { useNavigate } from 'react-router-dom';
import {
  Loader2, Rocket, FileText, Trash2, X, AlertCircle,
  Bot as BotIcon, CheckCircle2, Plus, Settings as SettingsIcon,
} from 'lucide-react';
import { supabase } from '@/lib/supabaseClient';
import { useAuth } from '@/context/AuthContext';
import FloatingMenu from '@/components/FloatingMenu';
import TechBackground from '@/components/TechBackground';
import BackButton from '@/components/BackButton';
import Footer from '@/components/Footer';

interface DeployedApp {
  id: string;
  bot_id: string | null;
  bot_name: string;
  heroku_app_name: string;
  app_url: string | null;
  status: string;
  build_id: string | null;
  env_vars: Record<string, string> | null;
  repo_full_name: string | null;
  auto_deploy_enabled: boolean;
  auto_deploy_branch: string | null;
  created_at: string;
}

const BotDeployment = () => {
  const navigate = useNavigate();
  const { user } = useAuth();
  const [apps, setApps] = useState<DeployedApp[]>([]);
  const [liveStatus, setLiveStatus] = useState<Record<string, 'active' | 'inactive'>>({});
  const [loading, setLoading] = useState(true);
  const [deletingId, setDeletingId] = useState<string | null>(null);

  const [buildFor, setBuildFor] = useState<DeployedApp | null>(null);
  const [buildOutput, setBuildOutput] = useState('');
  const [buildStatus, setBuildStatus] = useState<'pending' | 'succeeded' | 'failed'>('pending');
  const [showBuildLog, setShowBuildLog] = useState(true);
  const buildIntervalRef = useRef<ReturnType<typeof setInterval> | null>(null);

  const loadApps = async () => {
    if (!user) return;
    setLoading(true);
    const { data } = await supabase
      .from('deployed_apps')
      .select('id, bot_id, bot_name, heroku_app_name, app_url, status, build_id, env_vars, repo_full_name, auto_deploy_enabled, auto_deploy_branch, created_at')
      .eq('user_id', user.id)
      .neq('status', 'deleted')
      .order('created_at', { ascending: false });
    setApps(data || []);
    setLoading(false);

    // Fetch live active/inactive state, but only for apps that have actually
    // finished deploying — a still-building or failed app has no dyno yet.
    (data || []).forEach(async (app) => {
      if (app.status !== 'live') return;
      try {
        const res = await fetch(`/api/heroku-dyno?appName=${app.heroku_app_name}`);
        const info = await res.json();
        if (res.ok) {
          setLiveStatus(prev => ({ ...prev, [app.id]: info.state === 'up' ? 'active' : 'inactive' }));
        }
      } catch {
        // ignore — leave status unknown, card just won't show a dot
      }
    });
  };

  useEffect(() => {
    loadApps();
  }, [user]);

  const fetchBuild = useCallback(async (app: DeployedApp) => {
    if (!app.build_id) return;
    try {
      const res = await fetch(`/api/heroku-build?appName=${app.heroku_app_name}&buildId=${app.build_id}`);
      const data = await res.json();
      if (res.ok) {
        if (data.output) setBuildOutput(data.output);
        if (data.status) setBuildStatus(data.status);

        // Reflect a finished build back into the row + list so the card
        // updates without needing a full page reload.
        if (data.status === 'succeeded' || data.status === 'failed') {
          if (buildIntervalRef.current) clearInterval(buildIntervalRef.current);
          const newStatus = data.status === 'succeeded' ? 'live' : 'failed';
          await supabase
            .from('deployed_apps')
            .update({ status: newStatus, app_url: data.appUrl || null })
            .eq('id', app.id);
          setApps(prev =>
            prev.map(a => (a.id === app.id ? { ...a, status: newStatus, app_url: data.appUrl || a.app_url } : a))
          );

          // Bell-icon "update" notification for this deployment finishing.
          await supabase.from('notifications').insert({
            title: data.status === 'succeeded' ? 'Bot deployment update' : 'Bot deployment failed',
            message:
              data.status === 'succeeded'
                ? `${app.bot_name} (${app.heroku_app_name}) is now live.`
                : `${app.bot_name} (${app.heroku_app_name}) failed to build. Tap to view.`,
            link: '/my-bots/deployments',
          });
        }
      }
    } catch {
      // best-effort — the modal just won't update this one time
    }
  }, []);

  const openBuildView = (app: DeployedApp) => {
    setBuildFor(app);
    setBuildOutput('');
    setBuildStatus('pending');
    setShowBuildLog(true);
    fetchBuild(app);
  };

  const closeBuildView = () => {
    setBuildFor(null);
    if (buildIntervalRef.current) clearInterval(buildIntervalRef.current);
  };

  // Poll the build every 3s while the modal is open and it's still pending
  useEffect(() => {
    if (buildIntervalRef.current) clearInterval(buildIntervalRef.current);
    if (buildFor && buildStatus === 'pending') {
      buildIntervalRef.current = setInterval(() => fetchBuild(buildFor), 3000);
    }
    return () => {
      if (buildIntervalRef.current) clearInterval(buildIntervalRef.current);
    };
  }, [buildFor, buildStatus, fetchBuild]);

  const formatDate = (iso: string) =>
    new Date(iso).toLocaleDateString();

  const handleDeleteFailed = async (app: DeployedApp) => {
    setDeletingId(app.id);
    try {
      const res = await fetch('/api/heroku-app-manage', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ action: 'delete', appName: app.heroku_app_name }),
      });
      if (res.ok) {
        await supabase.from('deployed_apps').delete().eq('id', app.id);
        setApps(prev => prev.filter(a => a.id !== app.id));
      }
    } catch {
      // best-effort
    }
    setDeletingId(null);
  };

  return (
    <div className="min-h-screen bg-background text-foreground relative">
      <TechBackground />
      <FloatingMenu />

      <div className="relative z-10 max-w-2xl mx-auto px-4 py-20">
        <BackButton className="mb-4" />

        {/* Header */}
        <div className="flex items-center justify-between gap-3 mb-6">
          <div>
            <p className="flex items-center gap-1.5 text-primary text-xs font-mono tracking-widest mb-2">
              <BotIcon className="w-3.5 h-3.5" />
              WHATSAPP BOTS
            </p>
            <h1 className="text-2xl md:text-3xl font-bold text-foreground mb-1">Bot Deployment</h1>
            <p className="text-sm text-muted-foreground">
              Every bot you've deployed, with live status.
            </p>
          </div>
          <button
            onClick={() => navigate('/bots')}
            className="shrink-0 flex items-center gap-1.5 px-4 py-2.5 rounded-xl bg-gradient-to-r from-primary to-secondary text-primary-foreground text-sm font-semibold hover:opacity-90 transition-opacity"
          >
            <Plus className="w-4 h-4" />
            Deploy
          </button>
        </div>

        {loading && (
          <div className="flex items-center justify-center gap-2 py-20 text-muted-foreground">
            <Loader2 className="w-5 h-5 animate-spin" />
            Loading your bots...
          </div>
        )}

        {!loading && apps.length === 0 && (
          <div className="flex flex-col items-center justify-center gap-3 py-20 text-center">
            <Rocket className="w-10 h-10 text-muted-foreground" />
            <p className="text-muted-foreground">You haven't deployed any bots yet.</p>
            <button
              onClick={() => navigate('/bots')}
              className="mt-2 px-5 py-2.5 rounded-xl bg-gradient-to-r from-primary to-secondary text-primary-foreground text-sm font-semibold hover:opacity-90 transition-opacity"
            >
              Browse Bots
            </button>
          </div>
        )}

        <div className="space-y-4">
          {apps.map((app) => {
            const status = liveStatus[app.id];

            if (app.status === 'building' || app.status === 'failed') {
              const isFailed = app.status === 'failed';
              return (
                <div key={app.id} className="gradient-border overflow-hidden">
                  <div className={`h-1 ${isFailed ? 'bg-destructive' : 'bg-primary animate-pulse'}`} />
                  <div className="p-5">
                    <div className="flex items-center justify-between gap-3 mb-3">
                      <div className="flex items-center gap-3 min-w-0">
                        <div className="w-10 h-10 rounded-xl bg-primary/10 border border-primary/30 flex items-center justify-center shrink-0">
                          {isFailed ? (
                            <AlertCircle className="w-5 h-5 text-destructive" />
                          ) : (
                            <Loader2 className="w-5 h-5 text-primary animate-spin" />
                          )}
                        </div>
                        <div className="min-w-0">
                          <p className="font-semibold text-foreground truncate font-mono text-sm">{app.heroku_app_name}</p>
                          <p className="text-xs text-muted-foreground truncate">{app.bot_name}</p>
                        </div>
                      </div>
                      <span className={`shrink-0 text-xs font-medium ${isFailed ? 'text-destructive' : 'text-primary'}`}>
                        {isFailed ? 'Failed' : 'Building...'}
                      </span>
                    </div>

                    <div className="flex items-center gap-2">
                      <button
                        onClick={() => openBuildView(app)}
                        className="flex-1 flex items-center justify-center gap-1.5 py-2.5 rounded-lg border border-primary/40 text-primary text-xs font-medium hover:bg-primary/10 transition-colors"
                      >
                        <FileText className="w-3.5 h-3.5" />
                        View Build
                      </button>
                      <button
                        onClick={() => handleDeleteFailed(app)}
                        disabled={deletingId === app.id}
                        className="w-10 shrink-0 flex items-center justify-center py-2.5 rounded-lg border border-destructive/40 text-destructive hover:bg-destructive/10 transition-colors disabled:opacity-50"
                        aria-label="Remove"
                      >
                        {deletingId === app.id ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <Trash2 className="w-3.5 h-3.5" />}
                      </button>
                    </div>
                  </div>
                </div>
              );
            }

            return (
              <div key={app.id} className="gradient-border overflow-hidden">
                <div className={`h-1 ${status === 'inactive' ? 'bg-warning' : 'bg-success'}`} />
                <div className="p-5">
                  <div className="flex items-center justify-between gap-3 mb-3">
                    <div className="flex items-center gap-3 min-w-0">
                      <div className="relative shrink-0">
                        <div className="w-10 h-10 rounded-xl bg-primary/10 border border-primary/30 flex items-center justify-center">
                          <BotIcon className="w-5 h-5 text-primary" />
                        </div>
                        <span className={`absolute -bottom-0.5 -right-0.5 w-3 h-3 rounded-full border-2 border-background ${
                          status === 'inactive' ? 'bg-warning' : 'bg-success'
                        }`} />
                      </div>
                      <div className="min-w-0">
                        <p className="font-semibold text-foreground truncate font-mono text-sm">{app.heroku_app_name}</p>
                        <p className="text-xs text-muted-foreground truncate">{app.bot_name}</p>
                      </div>
                    </div>
                    <span className={`shrink-0 text-xs font-medium ${status === 'inactive' ? 'text-warning' : 'text-success'}`}>
                      {status === 'inactive' ? 'Server Stopped' : 'Server Running'}
                    </span>
                  </div>

                  <p className="text-[11px] text-muted-foreground mb-3 -mt-2">
                    This shows whether the server process is running, not whether it's
                    actually connected to WhatsApp — check Bot Settings → Logs to confirm that.
                  </p>

                  <div className="flex items-center justify-between text-xs text-muted-foreground mb-4">
                    <span>Created</span>
                    <span className="text-foreground">{formatDate(app.created_at)}</span>
                  </div>

                  <button
                    onClick={() => navigate(`/my-bots/${app.id}`)}
                    className="w-full flex items-center justify-center gap-2 py-2.5 rounded-lg border border-primary/40 text-primary text-sm font-semibold hover:bg-primary/10 transition-colors"
                  >
                    <SettingsIcon className="w-4 h-4" />
                    Bot Settings
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Build progress modal */}
      {buildFor && (
        <div
          className="fixed inset-0 z-[60] flex items-center justify-center bg-background/80 backdrop-blur-sm px-4"
          onClick={closeBuildView}
        >
          <div
            className="w-full max-w-lg max-h-[85vh] overflow-y-auto gradient-border p-6"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="flex items-center justify-between mb-5">
              <p className="font-semibold text-foreground text-sm font-mono">{buildFor.heroku_app_name}</p>
              <button onClick={closeBuildView} className="text-muted-foreground hover:text-foreground">
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Step list, Heroku-style */}
            <div className="space-y-1 mb-4">
              {['Create app', 'Configure environment', 'Build app', 'Deploy'].map((label, i) => {
                const stepDone = buildStatus === 'succeeded' || (buildStatus === 'pending' && i < 2);
                const stepFailed = buildStatus === 'failed' && i === 2;
                return (
                  <div key={label} className="flex items-center justify-between py-2 border-b border-border/30 last:border-0">
                    <span className={`text-sm ${stepDone || stepFailed ? 'text-foreground' : 'text-muted-foreground'}`}>
                      {label}
                    </span>
                    {stepFailed ? (
                      <AlertCircle className="w-4 h-4 text-destructive" />
                    ) : stepDone ? (
                      <CheckCircle2 className="w-4 h-4 text-success" />
                    ) : i === 2 && buildStatus === 'pending' ? (
                      <Loader2 className="w-4 h-4 text-primary animate-spin" />
                    ) : null}
                  </div>
                );
              })}
            </div>

            {/* Show/Hide build log toggle, like Heroku */}
            <button
              onClick={() => setShowBuildLog(!showBuildLog)}
              className="text-xs text-primary hover:underline mb-3"
            >
              {showBuildLog ? 'Hide build log' : 'Show build log'}
            </button>

            {showBuildLog && (
              <div className="bg-black rounded-xl p-3 max-h-72 overflow-y-auto mb-4">
                {buildOutput ? (
                  <pre className="text-[11px] text-success/90 whitespace-pre-wrap font-mono leading-relaxed">
                    {buildOutput}
                  </pre>
                ) : (
                  <p className="text-xs text-muted-foreground">Waiting for build output...</p>
                )}
              </div>
            )}

            {buildStatus === 'succeeded' && (
              <div className="flex items-center gap-2 px-3 py-2.5 rounded-xl bg-success/10 border border-success/40 text-success text-xs">
                <CheckCircle2 className="w-4 h-4 shrink-0" />
                Deployed successfully. This bot is now live.
              </div>
            )}
            {buildStatus === 'failed' && (
              <div className="flex items-center gap-2 px-3 py-2.5 rounded-xl bg-destructive/10 border border-destructive/40 text-destructive text-xs">
                <AlertCircle className="w-4 h-4 shrink-0" />
                Build failed. Check the log above for details.
              </div>
            )}
          </div>
        </div>
      )}

      <Footer />
    </div>
  );
};

export default BotDeployment;
