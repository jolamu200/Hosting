import { useEffect, useState } from 'react';
import { Eye, EyeOff, AlertCircle, ShieldCheck, Gift } from 'lucide-react';
import { supabase } from '@/lib/supabaseClient';
import profileImage from '@/assets/profile.jpg';
import TechBackground from '@/components/TechBackground';

type Mode = 'login' | 'signup' | 'verify-otp' | 'forgot-password' | 'reset-otp';

const Login = () => {
  const [mode, setMode] = useState<Mode>('login');

  // Login fields (email OR username)
  const [loginId, setLoginId] = useState('');
  const [password, setPassword] = useState('');

  // Sign up fields
  const [fullName, setFullName] = useState('');
  const [username, setUsername] = useState('');
  const [email, setEmail] = useState('');
  const [signupPassword, setSignupPassword] = useState('');
  const [referralCode, setReferralCode] = useState('');

  // OTP verification (signup)
  const [otp, setOtp] = useState('');

  // Forgot password flow
  const [resetEmail, setResetEmail] = useState('');
  const [resetOtp, setResetOtp] = useState('');
  const [newPassword, setNewPassword] = useState('');
  const [confirmNewPassword, setConfirmNewPassword] = useState('');

  const [showPassword, setShowPassword] = useState(false);
  const [error, setError] = useState('');
  const [info, setInfo] = useState('');
  const [loading, setLoading] = useState(false);

  // Pick up a referral code stashed by /signup?ref=CODE, if any
  useEffect(() => {
    const savedRef = localStorage.getItem('bmb_referral_code');
    if (savedRef) setReferralCode(savedRef);
  }, []);

  // Restore an in-progress OTP verification if the page reloaded — e.g. the
  // browser tab got suspended while the person switched to their email app
  // to grab the code. Without this, coming back drops them at the start of
  // signup instead of the "enter code" screen they were on.
  const PENDING_KEY = 'bmb_pending_verification';

  useEffect(() => {
    const saved = localStorage.getItem(PENDING_KEY);
    if (!saved) return;
    try {
      const pending = JSON.parse(saved);
      if (pending.kind === 'signup' && pending.email) {
        setEmail(pending.email);
        setFullName(pending.fullName || '');
        setUsername(pending.username || '');
        setSignupPassword(pending.signupPassword || '');
        setReferralCode(pending.referralCode || '');
        setMode('verify-otp');
        setInfo(`We've sent a 6-digit code to ${pending.email}. Enter it below to verify your account.`);
      } else if (pending.kind === 'reset' && pending.resetEmail) {
        setResetEmail(pending.resetEmail);
        setMode('reset-otp');
        setInfo(`We've sent a 6-digit code to ${pending.resetEmail}. Enter it below.`);
      }
    } catch {
      localStorage.removeItem(PENDING_KEY);
    }
  }, []);

  const resetMessages = () => {
    setError('');
    setInfo('');
  };

  // Step 1: Login with email OR username + password
  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    resetMessages();
    setLoading(true);

    let emailToUse = loginId.trim();

    // If it doesn't look like an email, resolve it to one via username lookup
    if (!emailToUse.includes('@')) {
      try {
        const res = await fetch('/api/auth-lookup', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ action: 'username-to-email', username: emailToUse }),
        });
        const data = await res.json();

        if (!res.ok || !data.email) {
          setError('Invalid username or password.');
          setLoading(false);
          return;
        }
        emailToUse = data.email;
      } catch {
        setError('Could not verify username right now. Try logging in with your email instead.');
        setLoading(false);
        return;
      }
    }

    const { error: signInError } = await supabase.auth.signInWithPassword({
      email: emailToUse,
      password,
    });

    setLoading(false);
    if (signInError) setError(signInError.message);
  };

  // Step 2: Sign up — collect details, then send an OTP to verify the email
  const handleSignup = async (e: React.FormEvent) => {
    e.preventDefault();
    resetMessages();

    if (signupPassword.length < 6) {
      setError('Password must be at least 6 characters.');
      return;
    }
    if (!username.trim()) {
      setError('Please choose a username.');
      return;
    }

    setLoading(true);

    // Check the username isn't already taken
    const { data: existing } = await supabase
      .from('profiles')
      .select('id')
      .eq('username', username.trim())
      .maybeSingle();

    if (existing) {
      setError('That username is already taken.');
      setLoading(false);
      return;
    }

    // Block signing up twice with the same email — send them to Login instead
    try {
      const checkRes = await fetch('/api/auth-lookup', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ action: 'check-email-exists', email: email.trim() }),
      });
      const checkData = await checkRes.json();

      if (checkRes.ok && checkData.exists) {
        setError('An account with this email already exists. Please log in instead.');
        setLoading(false);
        setLoginId(email.trim());
        setMode('login');
        return;
      }
    } catch {
      // If the check itself fails, fall through and let signInWithOtp handle it —
      // better to let a real user through than block everyone on a network hiccup.
    }

    // Send a 6-digit OTP to the email. shouldCreateUser lets this create the
    // account once the OTP is verified, with no password set yet.
    const { error: otpError } = await supabase.auth.signInWithOtp({
      email: email.trim(),
      options: { shouldCreateUser: true },
    });

    setLoading(false);

    if (otpError) {
      setError(otpError.message);
      return;
    }

    setInfo(`We've sent a 6-digit code to ${email}. Enter it below to verify your account.`);
    setMode('verify-otp');
    localStorage.setItem(PENDING_KEY, JSON.stringify({
      kind: 'signup',
      email: email.trim(),
      fullName,
      username: username.trim(),
      signupPassword,
      referralCode: referralCode.trim(),
    }));
  };

  // Step 3: Verify the OTP, then attach the chosen password + profile details
  const handleVerifyOtp = async (e: React.FormEvent) => {
    e.preventDefault();
    resetMessages();
    setLoading(true);

    const { data, error: verifyError } = await supabase.auth.verifyOtp({
      email: email.trim(),
      token: otp.trim(),
      type: 'email',
    });

    if (verifyError || !data.user) {
      setError(verifyError?.message || 'Invalid or expired code.');
      setLoading(false);
      return;
    }

    // Now that the account is verified and we have a session, set the
    // chosen password and save the profile details.
    const { error: passwordError } = await supabase.auth.updateUser({
      password: signupPassword,
    });

    if (passwordError) {
      setError(passwordError.message);
      setLoading(false);
      return;
    }

    await supabase.from('profiles').upsert({
      id: data.user.id,
      full_name: fullName,
      username: username.trim(),
      referred_by: referralCode.trim() || null,
      updated_at: new Date().toISOString(),
    });

    localStorage.removeItem('bmb_referral_code');
    localStorage.removeItem(PENDING_KEY);

    setLoading(false);
    setInfo('Account verified! You are now logged in.');
    // AuthContext will pick up the new session automatically and RequireAuth
    // will render the protected page — nothing else to do here.
  };

  const handleResendOtp = async () => {
    resetMessages();
    setLoading(true);
    const { error: otpError } = await supabase.auth.signInWithOtp({
      email: email.trim(),
      options: { shouldCreateUser: true },
    });
    setLoading(false);
    if (otpError) setError(otpError.message);
    else setInfo('A new code has been sent to your email.');
  };

  const handleOAuth = async (provider: 'google' | 'github') => {
    resetMessages();
    const { error: oauthError } = await supabase.auth.signInWithOAuth({
      provider,
      options: { redirectTo: window.location.origin },
    });
    if (oauthError) setError(oauthError.message);
  };

  const handleRequestPasswordReset = async (e: React.FormEvent) => {
    e.preventDefault();
    resetMessages();

    if (!resetEmail.trim()) {
      setError('Enter the email for your account.');
      return;
    }

    setLoading(true);
    // shouldCreateUser: false — this must be an existing account, not a new one
    const { error: otpError } = await supabase.auth.signInWithOtp({
      email: resetEmail.trim(),
      options: { shouldCreateUser: false },
    });
    setLoading(false);

    if (otpError) {
      setError(otpError.message);
      return;
    }

    setInfo(`We've sent a 6-digit code to ${resetEmail}. Enter it below.`);
    setMode('reset-otp');
    localStorage.setItem(PENDING_KEY, JSON.stringify({ kind: 'reset', resetEmail: resetEmail.trim() }));
  };

  const handleVerifyResetOtp = async (e: React.FormEvent) => {
    e.preventDefault();
    resetMessages();

    if (newPassword.length < 6) {
      setError('Password must be at least 6 characters.');
      return;
    }
    if (newPassword !== confirmNewPassword) {
      setError('Passwords do not match.');
      return;
    }

    setLoading(true);

    const { data, error: verifyError } = await supabase.auth.verifyOtp({
      email: resetEmail.trim(),
      token: resetOtp.trim(),
      type: 'email',
    });

    if (verifyError || !data.user) {
      setError(verifyError?.message || 'Invalid or expired code.');
      setLoading(false);
      return;
    }

    const { error: passwordError } = await supabase.auth.updateUser({ password: newPassword });

    if (passwordError) {
      setError(passwordError.message);
      setLoading(false);
      return;
    }

    // Sign out immediately — verifyOtp starts a session, but we want the
    // person to log in fresh with their new password, as requested.
    await supabase.auth.signOut();

    setLoading(false);
    setInfo('Password updated! You can now log in with your new password.');
    setLoginId(resetEmail);
    setResetEmail('');
    setResetOtp('');
    setNewPassword('');
    setConfirmNewPassword('');
    setMode('login');
    localStorage.removeItem(PENDING_KEY);
  };

  const handleResendResetOtp = async () => {
    resetMessages();
    setLoading(true);
    const { error: otpError } = await supabase.auth.signInWithOtp({
      email: resetEmail.trim(),
      options: { shouldCreateUser: false },
    });
    setLoading(false);
    if (otpError) setError(otpError.message);
    else setInfo('A new code has been sent to your email.');
  };

  const titles: Record<Mode, { title: string; subtitle: string }> = {
    login: { title: 'Bmb Tech Project Login', subtitle: 'Login to your account to continue' },
    signup: { title: 'Create Your Account', subtitle: 'Fill in your details to get started' },
    'verify-otp': { title: 'Verify Your Email', subtitle: 'Enter the code we sent to your email' },
    'forgot-password': { title: 'Reset Password', subtitle: 'Enter your account email to get a code' },
    'reset-otp': { title: 'Enter Code & New Password', subtitle: 'Check your email for the 6-digit code' },
  };

  return (
    <div className="min-h-screen bg-background text-foreground relative flex items-center justify-center px-4 py-10">
      <TechBackground />

      <div className="relative z-10 w-full max-w-sm">
        <div className="gradient-border p-6 md:p-8">
          {/* Header */}
          <div className="flex flex-col items-center text-center mb-6">
            <img
              src={profileImage}
              alt="Bmb Tech"
              className="w-16 h-16 rounded-2xl object-cover border-2 border-primary/50 mb-3"
            />
            <p className="text-success text-sm font-semibold mb-1">Tools . Bots . Web</p>
            <h1 className="text-2xl font-bold text-foreground">{titles[mode].title}</h1>
            <p className="text-sm text-muted-foreground mt-1">{titles[mode].subtitle}</p>
          </div>

          {error && (
            <div className="flex items-center gap-2 px-3 py-2.5 rounded-xl bg-destructive/10 border border-destructive/40 text-destructive text-xs mb-4">
              <AlertCircle className="w-4 h-4 shrink-0" />
              {error}
            </div>
          )}
          {info && (
            <div className="px-3 py-2.5 rounded-xl bg-success/10 border border-success/40 text-success text-xs mb-4">
              {info}
            </div>
          )}

          {/* LOGIN */}
          {mode === 'login' && (
            <>
              <div className="flex gap-3 mb-6">
                <button
                  onClick={() => handleOAuth('google')}
                  className="flex-1 flex items-center justify-center gap-2 py-3 rounded-xl border border-border/60 bg-background/30 text-sm font-medium text-foreground hover:bg-muted/40 transition-colors"
                >
                  <svg className="w-4 h-4" viewBox="0 0 24 24">
                    <path fill="#4285F4" d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"/>
                    <path fill="#34A853" d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"/>
                    <path fill="#FBBC05" d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l2.85-2.22.81-.62z"/>
                    <path fill="#EA4335" d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z"/>
                  </svg>
                  Google
                </button>
                <button
                  onClick={() => handleOAuth('github')}
                  className="flex-1 flex items-center justify-center gap-2 py-3 rounded-xl border border-border/60 bg-background/30 text-sm font-medium text-foreground hover:bg-muted/40 transition-colors"
                >
                  <svg className="w-4 h-4" fill="currentColor" viewBox="0 0 24 24">
                    <path d="M12 0c-6.626 0-12 5.373-12 12 0 5.302 3.438 9.8 8.207 11.387.599.111.793-.261.793-.577v-2.234c-3.338.726-4.033-1.416-4.033-1.416-.546-1.387-1.333-1.756-1.333-1.756-1.089-.745.083-.729.083-.729 1.205.084 1.839 1.237 1.839 1.237 1.07 1.834 2.807 1.304 3.492.997.107-.775.418-1.305.762-1.604-2.665-.305-5.467-1.334-5.467-5.931 0-1.311.469-2.381 1.236-3.221-.124-.303-.535-1.524.117-3.176 0 0 1.008-.322 3.301 1.23.957-.266 1.983-.399 3.003-.404 1.02.005 2.047.138 3.006.404 2.291-1.552 3.297-1.23 3.297-1.23.653 1.653.242 2.874.118 3.176.77.84 1.235 1.911 1.235 3.221 0 4.609-2.807 5.624-5.479 5.921.43.372.823 1.102.823 2.222v3.293c0 .319.192.694.801.576 4.765-1.589 8.199-6.086 8.199-11.386 0-6.627-5.373-12-12-12z"/>
                  </svg>
                  GitHub
                </button>
              </div>

              <div className="flex items-center gap-3 mb-6">
                <div className="flex-1 h-px bg-border/50" />
                <span className="text-xs text-muted-foreground">or continue with email</span>
                <div className="flex-1 h-px bg-border/50" />
              </div>

              <form onSubmit={handleLogin} className="space-y-4">
                <div>
                  <label className="text-xs font-semibold text-muted-foreground tracking-wide uppercase mb-1.5 block">
                    Username or Email
                  </label>
                  <input
                    type="text"
                    required
                    placeholder="Enter your username or email"
                    value={loginId}
                    onChange={(e) => setLoginId(e.target.value)}
                    className="w-full px-4 py-3 rounded-xl bg-background/50 border border-border/60 text-foreground text-sm placeholder:text-muted-foreground focus:outline-none focus:border-primary/60 transition-colors"
                  />
                </div>

                <div>
                  <label className="text-xs font-semibold text-muted-foreground tracking-wide uppercase mb-1.5 block">
                    Password
                  </label>
                  <div className="relative">
                    <input
                      type={showPassword ? 'text' : 'password'}
                      required
                      minLength={6}
                      placeholder="Enter your password"
                      value={password}
                      onChange={(e) => setPassword(e.target.value)}
                      className="w-full px-4 py-3 pr-11 rounded-xl bg-background/50 border border-border/60 text-foreground text-sm placeholder:text-muted-foreground focus:outline-none focus:border-primary/60 transition-colors"
                    />
                    <button
                      type="button"
                      onClick={() => setShowPassword(!showPassword)}
                      className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground"
                    >
                      {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                    </button>
                  </div>
                </div>

                <div className="text-right">
                  <button
                    type="button"
                    onClick={() => {
                      resetMessages();
                      setResetEmail(loginId.includes('@') ? loginId : '');
                      setMode('forgot-password');
                    }}
                    className="text-xs text-success hover:underline"
                  >
                    Forgot password?
                  </button>
                </div>

                <button
                  type="submit"
                  disabled={loading}
                  className="w-full py-3 rounded-xl bg-gradient-to-r from-primary to-secondary text-primary-foreground text-sm font-bold tracking-wide hover:opacity-90 transition-opacity disabled:opacity-60"
                >
                  {loading ? '...' : 'Sign In'}
                </button>
              </form>

              <p className="text-center text-sm text-muted-foreground mt-5">
                Don't have an account?{' '}
                <button
                  type="button"
                  onClick={() => { setMode('signup'); resetMessages(); }}
                  className="text-primary font-semibold hover:underline"
                >
                  Sign up
                </button>
              </p>

              <p className="text-center mt-3">
                <a href="/terms" className="text-xs text-muted-foreground hover:text-foreground underline underline-offset-2">
                  Terms of Service
                </a>
              </p>
            </>
          )}

          {/* SIGN UP */}
          {mode === 'signup' && (
            <form onSubmit={handleSignup} className="space-y-4">
              <div>
                <label className="text-xs font-semibold text-muted-foreground tracking-wide uppercase mb-1.5 block">
                  Full Name
                </label>
                <input
                  type="text"
                  required
                  placeholder="Your full name"
                  value={fullName}
                  onChange={(e) => setFullName(e.target.value)}
                  className="w-full px-4 py-3 rounded-xl bg-background/50 border border-border/60 text-foreground text-sm placeholder:text-muted-foreground focus:outline-none focus:border-primary/60 transition-colors"
                />
              </div>

              <div>
                <label className="text-xs font-semibold text-muted-foreground tracking-wide uppercase mb-1.5 block">
                  Username
                </label>
                <input
                  type="text"
                  required
                  minLength={3}
                  maxLength={20}
                  pattern="[a-zA-Z0-9_]+"
                  placeholder="Choose a username"
                  value={username}
                  onChange={(e) => setUsername(e.target.value)}
                  className="w-full px-4 py-3 rounded-xl bg-background/50 border border-border/60 text-foreground text-sm placeholder:text-muted-foreground focus:outline-none focus:border-primary/60 transition-colors"
                />
              </div>

              <div>
                <label className="text-xs font-semibold text-muted-foreground tracking-wide uppercase mb-1.5 block">
                  Email
                </label>
                <input
                  type="email"
                  required
                  placeholder="Enter your email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  className="w-full px-4 py-3 rounded-xl bg-background/50 border border-border/60 text-foreground text-sm placeholder:text-muted-foreground focus:outline-none focus:border-primary/60 transition-colors"
                />
              </div>

              <div>
                <label className="text-xs font-semibold text-muted-foreground tracking-wide uppercase mb-1.5 block">
                  Password
                </label>
                <div className="relative">
                  <input
                    type={showPassword ? 'text' : 'password'}
                    required
                    minLength={6}
                    placeholder="Choose a password"
                    value={signupPassword}
                    onChange={(e) => setSignupPassword(e.target.value)}
                    className="w-full px-4 py-3 pr-11 rounded-xl bg-background/50 border border-border/60 text-foreground text-sm placeholder:text-muted-foreground focus:outline-none focus:border-primary/60 transition-colors"
                  />
                  <button
                    type="button"
                    onClick={() => setShowPassword(!showPassword)}
                    className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground"
                  >
                    {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                  </button>
                </div>
              </div>

              <div>
                <label className="text-xs font-semibold text-muted-foreground tracking-wide uppercase mb-1.5 flex items-center gap-1.5">
                  <Gift className="w-3.5 h-3.5 text-secondary" />
                  Referral Code (Optional)
                </label>
                <input
                  type="text"
                  placeholder="e.g. bmbtech_539"
                  value={referralCode}
                  onChange={(e) => setReferralCode(e.target.value)}
                  className="w-full px-4 py-3 rounded-xl bg-background/50 border border-border/60 text-foreground text-sm placeholder:text-muted-foreground focus:outline-none focus:border-primary/60 transition-colors"
                />
              </div>

              <div className="flex gap-3 pt-1">
                <button
                  type="button"
                  onClick={() => { setMode('login'); resetMessages(); }}
                  className="flex-1 py-3 rounded-xl border-2 border-primary/60 text-primary text-sm font-semibold hover:bg-primary/10 transition-colors"
                >
                  Back to Login
                </button>
                <button
                  type="submit"
                  disabled={loading}
                  className="flex-1 py-3 rounded-xl bg-primary text-primary-foreground text-sm font-bold tracking-wide hover:opacity-90 transition-opacity disabled:opacity-60"
                >
                  {loading ? '...' : 'SIGN UP'}
                </button>
              </div>
            </form>
          )}

          {/* VERIFY OTP */}
          {mode === 'verify-otp' && (
            <form onSubmit={handleVerifyOtp} className="space-y-4">
              <div className="flex flex-col items-center text-center mb-2">
                <div className="w-12 h-12 rounded-full bg-primary/10 border border-primary/40 flex items-center justify-center mb-2">
                  <ShieldCheck className="w-5 h-5 text-primary" />
                </div>
                <p className="text-xs text-muted-foreground">Code sent to <span className="text-foreground font-medium">{email}</span></p>
              </div>

              <div>
                <label className="text-xs font-semibold text-muted-foreground tracking-wide uppercase mb-1.5 block">
                  6-Digit Code
                </label>
                <input
                  type="text"
                  required
                  inputMode="numeric"
                  maxLength={6}
                  placeholder="000000"
                  value={otp}
                  onChange={(e) => setOtp(e.target.value.replace(/\D/g, ''))}
                  className="w-full px-4 py-3 rounded-xl bg-background/50 border border-border/60 text-foreground text-center text-lg tracking-[0.5em] font-mono placeholder:text-muted-foreground focus:outline-none focus:border-primary/60 transition-colors"
                />
              </div>

              <button
                type="submit"
                disabled={loading || otp.length !== 6}
                className="w-full py-3 rounded-xl bg-gradient-to-r from-primary to-secondary text-primary-foreground text-sm font-bold tracking-wide hover:opacity-90 transition-opacity disabled:opacity-60"
              >
                {loading ? 'Verifying...' : 'Verify Account'}
              </button>

              <div className="flex items-center justify-between text-xs">
                <button type="button" onClick={() => { setMode('signup'); resetMessages(); localStorage.removeItem(PENDING_KEY); }} className="text-muted-foreground hover:text-foreground">
                  ← Back
                </button>
                <button type="button" onClick={handleResendOtp} disabled={loading} className="text-success hover:underline">
                  Resend code
                </button>
              </div>
            </form>
          )}

          {/* FORGOT PASSWORD — request a code */}
          {mode === 'forgot-password' && (
            <form onSubmit={handleRequestPasswordReset} className="space-y-4">
              <div>
                <label className="text-xs font-semibold text-muted-foreground tracking-wide uppercase mb-1.5 block">
                  Account Email
                </label>
                <input
                  type="email"
                  required
                  placeholder="Enter your account email"
                  value={resetEmail}
                  onChange={(e) => setResetEmail(e.target.value)}
                  className="w-full px-4 py-3 rounded-xl bg-background/50 border border-border/60 text-foreground text-sm placeholder:text-muted-foreground focus:outline-none focus:border-primary/60 transition-colors"
                />
              </div>

              <button
                type="submit"
                disabled={loading}
                className="w-full py-3 rounded-xl bg-gradient-to-r from-primary to-secondary text-primary-foreground text-sm font-bold tracking-wide hover:opacity-90 transition-opacity disabled:opacity-60"
              >
                {loading ? 'Sending...' : 'Send Code'}
              </button>

              <div className="text-center">
                <button
                  type="button"
                  onClick={() => { setMode('login'); resetMessages(); }}
                  className="text-xs text-muted-foreground hover:text-foreground"
                >
                  ← Back to Login
                </button>
              </div>
            </form>
          )}

          {/* FORGOT PASSWORD — enter code + new password */}
          {mode === 'reset-otp' && (
            <form onSubmit={handleVerifyResetOtp} className="space-y-4">
              <div className="flex flex-col items-center text-center mb-2">
                <div className="w-12 h-12 rounded-full bg-primary/10 border border-primary/40 flex items-center justify-center mb-2">
                  <ShieldCheck className="w-5 h-5 text-primary" />
                </div>
                <p className="text-xs text-muted-foreground">Code sent to <span className="text-foreground font-medium">{resetEmail}</span></p>
              </div>

              <div>
                <label className="text-xs font-semibold text-muted-foreground tracking-wide uppercase mb-1.5 block">
                  6-Digit Code
                </label>
                <input
                  type="text"
                  required
                  inputMode="numeric"
                  maxLength={6}
                  placeholder="000000"
                  value={resetOtp}
                  onChange={(e) => setResetOtp(e.target.value.replace(/\D/g, ''))}
                  className="w-full px-4 py-3 rounded-xl bg-background/50 border border-border/60 text-foreground text-center text-lg tracking-[0.5em] font-mono placeholder:text-muted-foreground focus:outline-none focus:border-primary/60 transition-colors"
                />
              </div>

              <div>
                <label className="text-xs font-semibold text-muted-foreground tracking-wide uppercase mb-1.5 block">
                  New Password
                </label>
                <div className="relative">
                  <input
                    type={showPassword ? 'text' : 'password'}
                    required
                    minLength={6}
                    placeholder="Enter new password"
                    value={newPassword}
                    onChange={(e) => setNewPassword(e.target.value)}
                    className="w-full px-4 py-3 pr-11 rounded-xl bg-background/50 border border-border/60 text-foreground text-sm placeholder:text-muted-foreground focus:outline-none focus:border-primary/60 transition-colors"
                  />
                  <button
                    type="button"
                    onClick={() => setShowPassword(!showPassword)}
                    className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground"
                  >
                    {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                  </button>
                </div>
              </div>

              <div>
                <label className="text-xs font-semibold text-muted-foreground tracking-wide uppercase mb-1.5 block">
                  Confirm New Password
                </label>
                <input
                  type={showPassword ? 'text' : 'password'}
                  required
                  minLength={6}
                  placeholder="Confirm new password"
                  value={confirmNewPassword}
                  onChange={(e) => setConfirmNewPassword(e.target.value)}
                  className="w-full px-4 py-3 rounded-xl bg-background/50 border border-border/60 text-foreground text-sm placeholder:text-muted-foreground focus:outline-none focus:border-primary/60 transition-colors"
                />
              </div>

              <button
                type="submit"
                disabled={loading || resetOtp.length !== 6}
                className="w-full py-3 rounded-xl bg-gradient-to-r from-primary to-secondary text-primary-foreground text-sm font-bold tracking-wide hover:opacity-90 transition-opacity disabled:opacity-60"
              >
                {loading ? 'Saving...' : 'Save New Password'}
              </button>

              <div className="flex items-center justify-between text-xs">
                <button type="button" onClick={() => { setMode('forgot-password'); resetMessages(); }} className="text-muted-foreground hover:text-foreground">
                  ← Back
                </button>
                <button type="button" onClick={handleResendResetOtp} disabled={loading} className="text-success hover:underline">
                  Resend code
                </button>
              </div>
            </form>
          )}
        </div>
      </div>
    </div>
  );
};

export default Login;
