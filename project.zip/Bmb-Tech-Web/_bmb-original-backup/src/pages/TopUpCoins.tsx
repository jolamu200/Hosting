import { useEffect, useState } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import {
  Coins, X, Minus, Plus, Smartphone, Copy, Check, MessageCircle,
  AlertTriangle, Loader2, Clock,
} from 'lucide-react';
import { supabase } from '@/lib/supabaseClient';
import { useAuth } from '@/context/AuthContext';
import TechBackground from '@/components/TechBackground';
import FloatingMenu from '@/components/FloatingMenu';
import BackButton from '@/components/BackButton';
import { getTopupCountry, CoinPackage } from '@/data/topupCountries';

// Where a manual (M-Pesa) payment should be sent, and how support can be reached.
const MANUAL_PAY = {
  provider: 'M-Pesa',
  number: '255767862457',
  accountName: 'SAILAS ANTIM MAMSERI',
  whatsapp: '255767862457',
};

const TopUpCoins = () => {
  const { countryCode } = useParams();
  const navigate = useNavigate();
  const { user } = useAuth();
  const country = getTopupCountry(countryCode || '');

  const [balance, setBalance] = useState(0);
  const [username, setUsername] = useState('');
  const [calcMode, setCalcMode] = useState<'coins' | 'money'>('coins');
  const [calcInput, setCalcInput] = useState('');

  const [selectedPackage, setSelectedPackage] = useState<CoinPackage | null>(null);
  const [showCustom, setShowCustom] = useState(false);
  const [showManual, setShowManual] = useState(false);
  const [copiedField, setCopiedField] = useState<string | null>(null);

  useEffect(() => {
    if (!user) return;
    supabase
      .from('profiles')
      .select('ph_balance, username')
      .eq('id', user.id)
      .single()
      .then(({ data }) => {
        setBalance(data?.ph_balance || 0);
        setUsername(data?.username || '');
      });
  }, [user]);

  if (!country) {
    return (
      <div className="min-h-screen bg-background text-foreground relative flex items-center justify-center">
        <TechBackground />
        <p className="relative z-10 text-muted-foreground text-sm">Unknown country.</p>
      </div>
    );
  }

  // ------- Coming soon (every country except Tanzania, for now) -------
  if (!country.active) {
    return (
      <div className="min-h-screen bg-background text-foreground relative">
        <TechBackground />
        <FloatingMenu />
        <div className="relative z-10 max-w-xl mx-auto px-4 pt-24 pb-16">
          <BackButton className="mb-4" fallback="/topup" />
          <div className="flex flex-col items-center text-center py-20 gradient-border px-6">
            <span className="text-5xl mb-4">{country.flagEmoji}</span>
            <Clock className="w-8 h-8 text-primary mb-3" />
            <h1 className="text-xl font-bold text-foreground mb-2">{country.name} — Coming Soon</h1>
            <p className="text-sm text-muted-foreground max-w-xs">
              Payments for {country.name} aren't live yet. We're working on it — check back soon,
              or select Tanzania to top up now.
            </p>
            <button
              onClick={() => navigate('/topup/tanzania')}
              className="mt-6 px-5 py-2.5 rounded-xl bg-gradient-to-r from-primary to-secondary text-primary-foreground text-sm font-semibold"
            >
              Go to Tanzania →
            </button>
          </div>
        </div>
      </div>
    );
  }

  const coinsFromCalc = calcMode === 'coins'
    ? Number(calcInput) || 0
    : Math.floor((Number(calcInput) || 0) / country.ratePerCoin);
  const moneyFromCalc = calcMode === 'money'
    ? Number(calcInput) || 0
    : (Number(calcInput) || 0) * country.ratePerCoin;

  const handleCopy = (field: string, value: string) => {
    navigator.clipboard.writeText(value).then(() => {
      setCopiedField(field);
      setTimeout(() => setCopiedField(null), 1500);
    });
  };

  return (
    <div className="min-h-screen bg-background text-foreground relative">
      <TechBackground />
      <FloatingMenu />

      <div className="relative z-10 max-w-xl mx-auto px-4 pt-24 pb-16">
        <BackButton className="mb-4" fallback="/topup" />

        <p className="text-xs font-mono tracking-widest text-primary mb-1 uppercase">{country.name}</p>
        <h1 className="text-2xl font-bold text-foreground mb-1">Top Up Coins</h1>
        <p className="text-sm text-muted-foreground mb-6">
          Pay with mobile money — Coins added instantly after confirmation
        </p>

        {/* Balance */}
        <div className="gradient-border p-4 mb-4 flex items-center gap-3">
          <Coins className="w-6 h-6 text-warning shrink-0" />
          <div>
            <p className="text-[11px] text-muted-foreground uppercase tracking-wide">Balance</p>
            <p className="text-xl font-bold text-foreground">{balance} Coins</p>
          </div>
        </div>

        {/* Calculator */}
        <div className="gradient-border p-4 mb-6">
          <p className="flex items-center gap-1.5 text-sm font-semibold text-foreground mb-3">
            <Coins className="w-4 h-4 text-primary" />
            Coin Calculator
          </p>
          <div className="flex items-center gap-1 p-1 rounded-full bg-background/50 border border-border/50 mb-3">
            <button
              onClick={() => { setCalcMode('coins'); setCalcInput(''); }}
              className={`flex-1 py-2 rounded-full text-xs font-semibold transition-colors ${
                calcMode === 'coins' ? 'bg-primary text-primary-foreground' : 'text-muted-foreground'
              }`}
            >
              Coins
            </button>
            <button
              onClick={() => { setCalcMode('money'); setCalcInput(''); }}
              className={`flex-1 py-2 rounded-full text-xs font-semibold transition-colors ${
                calcMode === 'money' ? 'bg-primary text-primary-foreground' : 'text-muted-foreground'
              }`}
            >
              {country.currency}
            </button>
          </div>
          <input
            type="number"
            value={calcInput}
            onChange={(e) => setCalcInput(e.target.value)}
            placeholder={calcMode === 'coins' ? 'e.g. 50' : 'e.g. 5000'}
            className="w-full px-4 py-3 rounded-xl bg-background/50 border border-border/60 text-foreground text-sm placeholder:text-muted-foreground focus:outline-none focus:border-primary/60 transition-colors mb-2"
          />
          {calcInput && (
            <p className="text-xs text-muted-foreground">
              {calcMode === 'coins'
                ? `≈ ${country.currency} ${moneyFromCalc.toLocaleString()}`
                : `≈ ${coinsFromCalc} Coins`}
            </p>
          )}
          <p className="text-center text-xs text-muted-foreground mt-2">{country.rateLabel}</p>
        </div>

        {/* Packages */}
        <div className="space-y-3 mb-6">
          {country.packages.map((pkg) => (
            <div
              key={pkg.id}
              className={`gradient-border p-4 flex items-center justify-between ${
                pkg.bestValue ? 'ring-1 ring-primary' : ''
              }`}
            >
              <div>
                {pkg.bestValue && (
                  <span className="inline-block mb-1.5 text-[10px] font-bold px-2 py-0.5 rounded-full bg-primary text-primary-foreground">
                    BEST VALUE
                  </span>
                )}
                <p className="text-2xl font-bold text-foreground">
                  {pkg.coins} <span className="text-sm font-normal text-muted-foreground">Coins</span>
                </p>
                <p className="text-xs text-muted-foreground">
                  ≈ {country.currency} {pkg.priceLocal.toLocaleString()}
                </p>
                {pkg.bonus ? (
                  <span className="inline-block mt-1 text-[10px] px-1.5 py-0.5 rounded bg-success/20 text-success">
                    Includes +{pkg.bonus} bonus
                  </span>
                ) : null}
              </div>
              <div className="text-right">
                <p className="text-sm font-mono text-foreground mb-2">
                  {country.currency} {pkg.priceLocal.toLocaleString()}
                </p>
                <button
                  onClick={() => setSelectedPackage(pkg)}
                  className="text-xs font-bold text-primary hover:underline"
                >
                  SELECT →
                </button>
              </div>
            </div>
          ))}
        </div>

        {/* Custom amount */}
        <div className="gradient-border p-4 mb-6">
          <p className="font-semibold text-foreground text-sm mb-1">Custom Amount</p>
          <p className="text-xs text-muted-foreground mb-2">Enter exactly how many Coins you need</p>
          <button onClick={() => setShowCustom(true)} className="text-xs font-bold text-primary hover:underline">
            CONFIGURE →
          </button>
        </div>

        {/* Manual payment */}
        <div className="gradient-border p-4">
          <p className="flex items-center gap-1.5 font-semibold text-foreground text-sm mb-1">
            <Smartphone className="w-4 h-4 text-warning" />
            Manual payment
          </p>
          <p className="text-xs text-muted-foreground mb-3">M-Pesa transfer + proof to support</p>
          <p className="text-xs text-muted-foreground mb-3">
            If automatic payment fails, pay via <strong className="text-foreground">M-Pesa</strong> and send your
            screenshot to support. Include your username or email.
          </p>
          <button
            onClick={() => setShowManual(true)}
            className="w-full py-3 rounded-xl border border-warning/40 text-warning text-sm font-semibold hover:bg-warning/10 transition-colors"
          >
            Pay Manually
          </button>
        </div>
      </div>

      {selectedPackage && (
        <CompletePaymentModal
          country={country}
          coins={selectedPackage.coins}
          amount={selectedPackage.priceLocal}
          packageLabel={selectedPackage.label}
          userEmail={user?.email || ''}
          onClose={() => setSelectedPackage(null)}
        />
      )}

      {showCustom && (
        <CustomAmountModal
          country={country}
          userEmail={user?.email || ''}
          onClose={() => setShowCustom(false)}
        />
      )}

      {showManual && (
        <ManualPayModal
          username={username}
          copiedField={copiedField}
          onCopy={handleCopy}
          onClose={() => setShowManual(false)}
        />
      )}
    </div>
  );
};

// ------------------------------------------------------------------
// "Complete Payment" — shown after picking a fixed package (image 5)
// ------------------------------------------------------------------
const CompletePaymentModal = ({
  country,
  coins,
  amount,
  packageLabel,
  userEmail,
  onClose,
}: {
  country: ReturnType<typeof getTopupCountry>;
  coins: number;
  amount: number;
  packageLabel: string;
  userEmail: string;
  onClose: () => void;
}) => {
  const { user } = useAuth();
  const [phone, setPhone] = useState('');
  const [firstName, setFirstName] = useState('');
  const [lastName, setLastName] = useState('');
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState('');

  const handlePay = async () => {
    if (!user) return;
    if (!phone.trim()) {
      setError('Enter your phone number.');
      return;
    }
    setSubmitting(true);
    setError('');

    try {
      const res = await fetch('/api/push-notifications?step=topup-initiate', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          userId: user.id,
          country: country?.code,
          coins,
          amount,
          currency: country?.currency,
          phone: phone.trim(),
          firstName: firstName.trim(),
          lastName: lastName.trim(),
          email: userEmail,
        }),
      });
      const data = await res.json();

      if (!res.ok) {
        setError(data.error || 'Could not start the payment. Please try again.');
        setSubmitting(false);
        return;
      }

      setSubmitting(false);
      alert(`A payment prompt has been sent to ${phone.trim()}. Approve it on your phone to receive your ${coins} Coins.`);
      onClose();
    } catch {
      setError('Network error — please try again.');
      setSubmitting(false);
    }
  };

  return (
    <div className="fixed inset-0 z-[70] flex items-end sm:items-center justify-center bg-background/80 backdrop-blur-sm px-4" onClick={onClose}>
      <div className="w-full max-w-sm max-h-[85vh] overflow-y-auto gradient-border p-5" onClick={(e) => e.stopPropagation()}>
        <div className="flex items-center justify-between mb-4">
          <p className="font-semibold text-foreground">Complete Payment</p>
          <button onClick={onClose} className="text-muted-foreground hover:text-foreground">
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="flex items-center justify-between p-3 rounded-xl bg-background/40 border border-border/40 mb-4">
          <div>
            <p className="text-sm font-semibold text-foreground">{packageLabel}</p>
            <p className="text-xs text-muted-foreground">≈ {country?.currency} {amount.toLocaleString()}</p>
          </div>
          <p className="text-sm font-bold text-primary">{coins} Coins</p>
        </div>

        <div className="flex items-start gap-2 px-3 py-2.5 rounded-xl bg-primary/10 border border-primary/30 text-xs text-foreground mb-4">
          <Smartphone className="w-4 h-4 shrink-0 mt-0.5 text-primary" />
          Enter your {country?.name} phone number. You'll receive a mobile money push prompt to approve.
        </div>

        {error && (
          <div className="flex items-center gap-2 px-3 py-2.5 rounded-xl bg-destructive/10 border border-destructive/40 text-destructive text-xs mb-3">
            <AlertTriangle className="w-4 h-4 shrink-0" />
            {error}
          </div>
        )}

        <div className="space-y-3">
          <div>
            <label className="text-xs font-semibold text-muted-foreground mb-1 block">Phone Number (255XXXXXXXXX)</label>
            <input
              type="tel"
              value={phone}
              onChange={(e) => setPhone(e.target.value)}
              placeholder="255712345678"
              className="w-full px-4 py-2.5 rounded-xl bg-background/50 border border-border/60 text-foreground text-sm placeholder:text-muted-foreground focus:outline-none focus:border-primary/60 transition-colors"
            />
          </div>
          <div className="grid grid-cols-2 gap-2">
            <div>
              <label className="text-xs font-semibold text-muted-foreground mb-1 block">First Name</label>
              <input
                type="text"
                value={firstName}
                onChange={(e) => setFirstName(e.target.value)}
                placeholder="John"
                className="w-full px-4 py-2.5 rounded-xl bg-background/50 border border-border/60 text-foreground text-sm placeholder:text-muted-foreground focus:outline-none focus:border-primary/60 transition-colors"
              />
            </div>
            <div>
              <label className="text-xs font-semibold text-muted-foreground mb-1 block">Last Name</label>
              <input
                type="text"
                value={lastName}
                onChange={(e) => setLastName(e.target.value)}
                placeholder="Doe"
                className="w-full px-4 py-2.5 rounded-xl bg-background/50 border border-border/60 text-foreground text-sm placeholder:text-muted-foreground focus:outline-none focus:border-primary/60 transition-colors"
              />
            </div>
          </div>
          <div>
            <label className="text-xs font-semibold text-muted-foreground mb-1 block">Email</label>
            <input
              type="email"
              value={userEmail}
              readOnly
              className="w-full px-4 py-2.5 rounded-xl bg-background/30 border border-border/60 text-muted-foreground text-sm"
            />
          </div>

          <button
            onClick={handlePay}
            disabled={submitting}
            className="w-full py-3 rounded-xl bg-gradient-to-r from-primary to-secondary text-primary-foreground text-sm font-bold disabled:opacity-60"
          >
            {submitting ? 'Processing...' : `Pay ${country?.currency} ${amount.toLocaleString()}`}
          </button>
        </div>
      </div>
    </div>
  );
};

// ------------------------------------------------------------------
// "Custom Amount" — pick an exact coin count (image 3)
// ------------------------------------------------------------------
const CustomAmountModal = ({
  country,
  userEmail,
  onClose,
}: {
  country: ReturnType<typeof getTopupCountry>;
  userEmail: string;
  onClose: () => void;
}) => {
  const { user } = useAuth();
  const [coins, setCoins] = useState(country?.minCoins || 3);
  const [phone, setPhone] = useState('');
  const [firstName, setFirstName] = useState('');
  const [lastName, setLastName] = useState('');
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState('');

  const minCoins = country?.minCoins || 3;
  const amount = coins * (country?.ratePerCoin || 0);

  const handlePay = async () => {
    if (!user) return;
    if (coins < minCoins) {
      setError(`Minimum ${minCoins} coins.`);
      return;
    }
    if (!phone.trim()) {
      setError('Enter your phone number.');
      return;
    }
    setSubmitting(true);
    setError('');

    try {
      const res = await fetch('/api/push-notifications?step=topup-initiate', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          userId: user.id,
          country: country?.code,
          coins,
          amount,
          currency: country?.currency,
          phone: phone.trim(),
          firstName: firstName.trim(),
          lastName: lastName.trim(),
          email: userEmail,
        }),
      });
      const data = await res.json();

      if (!res.ok) {
        setError(data.error || 'Could not start the payment. Please try again.');
        setSubmitting(false);
        return;
      }

      setSubmitting(false);
      alert(`A payment prompt has been sent to ${phone.trim()}. Approve it on your phone to receive your ${coins} Coins.`);
      onClose();
    } catch {
      setError('Network error — please try again.');
      setSubmitting(false);
    }
  };

  return (
    <div className="fixed inset-0 z-[70] flex items-end sm:items-center justify-center bg-background/80 backdrop-blur-sm px-4" onClick={onClose}>
      <div className="w-full max-w-sm max-h-[85vh] overflow-y-auto gradient-border p-5" onClick={(e) => e.stopPropagation()}>
        <div className="flex items-center justify-between mb-4">
          <p className="font-semibold text-foreground">Custom Amount</p>
          <button onClick={onClose} className="text-muted-foreground hover:text-foreground">
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="flex items-center justify-between p-3 rounded-xl bg-background/40 border border-border/40 mb-2">
          <p className="text-sm font-semibold text-foreground">{coins} Coins</p>
          <p className="text-sm font-bold text-primary">{country?.currency} {amount.toLocaleString()}</p>
        </div>

        <div className="flex items-center gap-2 mb-1">
          <button
            onClick={() => setCoins((c) => Math.max(minCoins, c - 1))}
            className="w-10 h-10 rounded-xl bg-background/50 border border-border/60 flex items-center justify-center text-foreground"
          >
            <Minus className="w-4 h-4" />
          </button>
          <input
            type="number"
            value={coins}
            onChange={(e) => setCoins(Math.max(0, Number(e.target.value)))}
            className="flex-1 px-4 py-2.5 rounded-xl bg-background/50 border border-border/60 text-foreground text-sm text-center focus:outline-none focus:border-primary/60 transition-colors"
          />
          <button
            onClick={() => setCoins((c) => c + 1)}
            className="w-10 h-10 rounded-xl bg-background/50 border border-border/60 flex items-center justify-center text-foreground"
          >
            <Plus className="w-4 h-4" />
          </button>
        </div>
        <p className="text-[11px] text-muted-foreground mb-4">
          Rate: {country?.currency} {country?.ratePerCoin} per Coin · Min {minCoins} Coins
        </p>

        {error && (
          <div className="flex items-center gap-2 px-3 py-2.5 rounded-xl bg-destructive/10 border border-destructive/40 text-destructive text-xs mb-3">
            <AlertTriangle className="w-4 h-4 shrink-0" />
            {error}
          </div>
        )}

        <div className="space-y-3">
          <div>
            <label className="text-xs font-semibold text-muted-foreground mb-1 block">Phone ({country?.name === 'Tanzania' ? '255XXXXXXXXX' : 'incl. country code'})</label>
            <input
              type="tel"
              value={phone}
              onChange={(e) => setPhone(e.target.value)}
              placeholder="255712345678"
              className="w-full px-4 py-2.5 rounded-xl bg-background/50 border border-border/60 text-foreground text-sm placeholder:text-muted-foreground focus:outline-none focus:border-primary/60 transition-colors"
            />
          </div>
          <div className="grid grid-cols-2 gap-2">
            <div>
              <label className="text-xs font-semibold text-muted-foreground mb-1 block">First Name</label>
              <input
                type="text"
                value={firstName}
                onChange={(e) => setFirstName(e.target.value)}
                placeholder="John"
                className="w-full px-4 py-2.5 rounded-xl bg-background/50 border border-border/60 text-foreground text-sm placeholder:text-muted-foreground focus:outline-none focus:border-primary/60 transition-colors"
              />
            </div>
            <div>
              <label className="text-xs font-semibold text-muted-foreground mb-1 block">Last Name</label>
              <input
                type="text"
                value={lastName}
                onChange={(e) => setLastName(e.target.value)}
                placeholder="Doe"
                className="w-full px-4 py-2.5 rounded-xl bg-background/50 border border-border/60 text-foreground text-sm placeholder:text-muted-foreground focus:outline-none focus:border-primary/60 transition-colors"
              />
            </div>
          </div>
          <div>
            <label className="text-xs font-semibold text-muted-foreground mb-1 block">Email</label>
            <input
              type="email"
              value={userEmail}
              readOnly
              className="w-full px-4 py-2.5 rounded-xl bg-background/30 border border-border/60 text-muted-foreground text-sm"
            />
          </div>

          <button
            onClick={handlePay}
            disabled={submitting}
            className="w-full py-3 rounded-xl bg-gradient-to-r from-primary to-secondary text-primary-foreground text-sm font-bold disabled:opacity-60"
          >
            {submitting ? 'Processing...' : `Pay ${country?.currency} ${amount.toLocaleString()}`}
          </button>
        </div>
      </div>
    </div>
  );
};

// ------------------------------------------------------------------
// "Pay Manually" — M-Pesa transfer instructions (image 4)
// ------------------------------------------------------------------
const ManualPayModal = ({
  username,
  copiedField,
  onCopy,
  onClose,
}: {
  username: string;
  copiedField: string | null;
  onCopy: (field: string, value: string) => void;
  onClose: () => void;
}) => {
  const identity = username ? `@${username}` : 'your account email';

  return (
    <div className="fixed inset-0 z-[70] flex items-end sm:items-center justify-center bg-background/80 backdrop-blur-sm px-4" onClick={onClose}>
      <div className="w-full max-w-sm max-h-[85vh] overflow-y-auto gradient-border p-5" onClick={(e) => e.stopPropagation()}>
        <div className="flex items-center justify-between mb-4">
          <p className="font-semibold text-foreground">Pay Manual</p>
          <button onClick={onClose} className="text-muted-foreground hover:text-foreground">
            <X className="w-5 h-5" />
          </button>
        </div>

        <p className="text-[11px] font-semibold text-muted-foreground uppercase tracking-wide mb-2">Step 1 · Send Payment</p>
        <p className="text-xs text-muted-foreground mb-3">
          Send payment via <strong className="text-foreground">{MANUAL_PAY.provider}</strong> to:
        </p>

        <div className="flex items-center justify-between p-3 rounded-xl bg-background/40 border border-border/40 mb-2">
          <div>
            <p className="text-[10px] text-muted-foreground uppercase tracking-wide">M-Pesa Number</p>
            <p className="font-bold text-foreground">{MANUAL_PAY.number}</p>
          </div>
          <button onClick={() => onCopy('number', MANUAL_PAY.number)} className="text-muted-foreground hover:text-foreground">
            {copiedField === 'number' ? <Check className="w-4 h-4 text-success" /> : <Copy className="w-4 h-4" />}
          </button>
        </div>

        <div className="flex items-center justify-between p-3 rounded-xl bg-background/40 border border-border/40 mb-4">
          <div>
            <p className="text-[10px] text-muted-foreground uppercase tracking-wide">Account Name</p>
            <p className="font-bold text-foreground">{MANUAL_PAY.accountName}</p>
          </div>
          <button onClick={() => onCopy('name', MANUAL_PAY.accountName)} className="text-muted-foreground hover:text-foreground">
            {copiedField === 'name' ? <Check className="w-4 h-4 text-success" /> : <Copy className="w-4 h-4" />}
          </button>
        </div>

        <p className="text-[11px] font-semibold text-muted-foreground uppercase tracking-wide mb-2">Step 2 · Send Payment Proof</p>
        <p className="text-xs text-muted-foreground mb-3">
          After paying, take a screenshot of your transaction and send it via WhatsApp:
        </p>

        <a
          href={`https://wa.me/${MANUAL_PAY.whatsapp}`}
          target="_blank"
          rel="noopener noreferrer"
          className="flex items-center gap-3 p-3 rounded-xl bg-background/40 border border-border/40 mb-4 hover:bg-muted/30 transition-colors"
        >
          <div className="w-9 h-9 rounded-full bg-success/15 flex items-center justify-center shrink-0">
            <MessageCircle className="w-4.5 h-4.5 text-success" />
          </div>
          <div className="min-w-0">
            <p className="text-sm font-semibold text-foreground">WhatsApp</p>
            <p className="text-xs text-muted-foreground">{MANUAL_PAY.whatsapp}</p>
          </div>
        </a>

        <div className="px-3 py-3 rounded-xl bg-warning/10 border border-warning/30 mb-4">
          <p className="flex items-center gap-1.5 text-xs font-bold text-warning mb-1.5">
            <AlertTriangle className="w-3.5 h-3.5" />
            INCLUDE YOUR IDENTITY IN THE PROOF
          </p>
          <p className="text-[11px] text-muted-foreground mb-2">
            Along with your payment screenshot, you <strong className="text-foreground">must</strong> include your
            Bmb Tech account identity so our support team can locate your account and credit your Coins without delay.
          </p>
          <p className="text-xs text-foreground">
            Your account identity: <span className="text-primary font-semibold">{identity}</span>
          </p>
          <p className="text-[10px] text-muted-foreground mt-1.5">
            Without this, our team cannot identify which account to credit — processing will be delayed.
          </p>
        </div>

        <button
          onClick={onClose}
          className="w-full py-3 rounded-xl bg-gradient-to-r from-primary to-secondary text-primary-foreground text-sm font-bold"
        >
          Got it
        </button>
      </div>
    </div>
  );
};

export default TopUpCoins;
